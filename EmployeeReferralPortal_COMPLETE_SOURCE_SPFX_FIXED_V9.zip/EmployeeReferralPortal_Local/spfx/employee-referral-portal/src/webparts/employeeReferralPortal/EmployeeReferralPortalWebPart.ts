import * as React from 'react';
import * as ReactDom from 'react-dom';
import { Version } from '@microsoft/sp-core-library';
import { BaseClientSideWebPart, IPropertyPaneConfiguration, PropertyPaneTextField } from '@microsoft/sp-webpart-base';
import { IEmployeeReferralPortalProps } from './components/IEmployeeReferralPortalProps';
import EmployeeReferralPortal from './components/EmployeeReferralPortal';

export interface IEmployeeReferralPortalWebPartProps { apiBaseUrl: string; }

export default class EmployeeReferralPortalWebPart extends BaseClientSideWebPart<IEmployeeReferralPortalWebPartProps> {
  public render(): void {
    const element: React.ReactElement<IEmployeeReferralPortalProps> = React.createElement(EmployeeReferralPortal, {
      context: this.context,
      apiBaseUrl: this.properties.apiBaseUrl || 'http://localhost:5000',
    });
    ReactDom.render(element, this.domElement);
  }
  protected onDispose(): void { ReactDom.unmountComponentAtNode(this.domElement); }
  protected get dataVersion(): Version { return Version.parse('2.0'); }
  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return { pages: [{ header: { description: 'Employee Referral Portal configuration' }, groups: [{ groupName: 'API', groupFields: [
      PropertyPaneTextField('apiBaseUrl', { label: 'API Base URL', description: 'Example: https://api.contoso.com' }),
    ] }] }] };
  }
}
