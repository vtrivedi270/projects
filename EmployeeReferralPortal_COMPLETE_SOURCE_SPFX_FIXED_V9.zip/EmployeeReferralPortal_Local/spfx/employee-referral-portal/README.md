# Employee Referral Portal - SPFx 1.23.2 (READY BUILD PACKAGE)

This SPFx project uses the official Heft-based SharePoint Framework toolchain for SPFx 1.23.2.

## Prerequisites

- Windows 10/11
- Node.js 22 LTS
- npm
- A SharePoint Online site for the hosted workbench/debug experience
- .NET 8 SDK if testing the local API

SPFx 1.23.2 is compatible with Node.js 22 and React 17.0.1.

## Run - only these npm commands

From this folder:

```powershell
npm install
npm run build
npm start
```

`npm run build` performs the Heft production build and creates:

```text
sharepoint/solution/employee-referral-portal.sppkg
```

`npm start` automatically trusts the local development certificate and starts the SPFx dev server.

## SharePoint workbench

SPFx does NOT have a local workbench. The project is configured for the hosted SharePoint workbench.

Set your tenant once in PowerShell:

```powershell
$env:SPFX_SERVE_TENANT_DOMAIN = "contoso.sharepoint.com"
```

Then run:

```powershell
npm start
```

The browser opens the hosted workbench. Add **Employee Referral Portal**.

## Local API

The local API is configured for:

```text
https://localhost:5001
```

Start it from the backend folder:

```powershell
dotnet run
```

Swagger:

```text
https://localhost:5001/swagger
```

The SPFx default `apiBaseUrl` points to `https://localhost:5001` so the HTTPS SPFx page does not call an HTTP API as mixed content.

## Important

Do not use the old Gulp commands. SPFx 1.22+ uses Heft.

Use:

```text
npm install
npm run build
npm start
```

The old `config/config.json` and `@microsoft/sp-build-web` build rig are intentionally removed. The project uses:

```text
@microsoft/spfx-web-build-rig@1.23.2
@microsoft/spfx-heft-plugins@1.23.2
@rushstack/heft@1.2.17
```
