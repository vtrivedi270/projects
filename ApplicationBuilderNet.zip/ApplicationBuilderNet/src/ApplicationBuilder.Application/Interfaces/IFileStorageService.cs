namespace ApplicationBuilder.Application.Interfaces;
public record StoredFile(string FileName,long Size,string? Url,string? ItemId,string? UniqueId);
public interface IFileStorageService { Task<StoredFile> UploadAsync(int applicationId,long requestId,string fileName,string contentType,Stream content,CancellationToken ct); }
