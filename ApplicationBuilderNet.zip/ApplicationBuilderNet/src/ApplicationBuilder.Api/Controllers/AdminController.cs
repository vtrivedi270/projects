using ApplicationBuilder.Domain.Entities; using ApplicationBuilder.Infrastructure.Data; using Microsoft.AspNetCore.Authorization; using Microsoft.AspNetCore.Mvc; using Microsoft.EntityFrameworkCore;
namespace ApplicationBuilder.Api.Controllers;
[ApiController,Route("api/admin"),Authorize(Roles="ADMIN,APPLICATION_ADMIN")]
public class AdminController(ApplicationDbContext db):ControllerBase
{
 [HttpGet("users")] public async Task<IActionResult> Users(CancellationToken ct)=>Ok(await db.AppUsers.AsNoTracking().OrderBy(x=>x.DisplayName).ToListAsync(ct));
 [HttpPost("users")] public async Task<IActionResult> CreateUser(AppUser x,CancellationToken ct){if(await db.AppUsers.AnyAsync(u=>u.UserId==x.UserId,ct))return Conflict("User exists");db.AppUsers.Add(x);await db.SaveChangesAsync(ct);return Ok(x);}
 [HttpPut("users/{id}")] public async Task<IActionResult> UpdateUser(string id,AppUser input,CancellationToken ct){var x=await db.AppUsers.FindAsync([id],ct);if(x is null)return NotFound();x.DisplayName=input.DisplayName;x.Email=input.Email;x.EmployeeCode=input.EmployeeCode;x.JobTitle=input.JobTitle;x.ManagerUserId=input.ManagerUserId;x.OrganizationUnitId=input.OrganizationUnitId;x.IsActive=input.IsActive;await db.SaveChangesAsync(ct);return Ok(x);}
 [HttpGet("roles")] public async Task<IActionResult> Roles(CancellationToken ct)=>Ok(await db.AppRoles.AsNoTracking().ToListAsync(ct));
 [HttpGet("permissions")] public async Task<IActionResult> Permissions(CancellationToken ct)=>Ok(await db.Permissions.AsNoTracking().ToListAsync(ct));
 [HttpPost("user-roles")] public async Task<IActionResult> AssignRole(UserRole x,CancellationToken ct){db.UserRoles.Add(x);await db.SaveChangesAsync(ct);return Ok(x);}
 [HttpGet("application-permissions/{appId:int}")] public async Task<IActionResult> ApplicationPermissions(int appId,CancellationToken ct)=>Ok(await db.ApplicationPermissions.AsNoTracking().Where(x=>x.ApplicationId==appId&&x.IsActive).ToListAsync(ct));
 [HttpPost("application-permissions")] public async Task<IActionResult> SaveApplicationPermission(ApplicationPermission x,CancellationToken ct){var old=await db.ApplicationPermissions.SingleOrDefaultAsync(y=>y.ApplicationId==x.ApplicationId&&y.RoleId==x.RoleId&&y.PermissionId==x.PermissionId,ct);if(old is null)db.ApplicationPermissions.Add(x);else{old.ScopeType=x.ScopeType;old.ScopeJson=x.ScopeJson;old.IsActive=x.IsActive;}await db.SaveChangesAsync(ct);return Ok(x);}
 [HttpGet("delegations")] public async Task<IActionResult> Delegations(CancellationToken ct)=>Ok(await db.Delegations.AsNoTracking().Where(x=>x.IsActive).OrderByDescending(x=>x.StartDate).ToListAsync(ct));
 [HttpPost("delegations")] public async Task<IActionResult> CreateDelegation(Delegation x,CancellationToken ct){x.CreatedBy=User.FindFirst("oid")?.Value??User.FindFirst("sub")?.Value??"admin";db.Delegations.Add(x);await db.SaveChangesAsync(ct);return Ok(x);}
 [HttpDelete("delegations/{id:long}")] public async Task<IActionResult> DeleteDelegation(long id,CancellationToken ct){var x=await db.Delegations.FindAsync([id],ct);if(x is null)return NotFound();x.IsActive=false;await db.SaveChangesAsync(ct);return NoContent();}
}
