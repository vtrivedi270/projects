using ApplicationBuilder.Domain.Entities; using ApplicationBuilder.Infrastructure.Data; using Microsoft.AspNetCore.Authorization; using Microsoft.AspNetCore.Mvc; using Microsoft.EntityFrameworkCore;
namespace ApplicationBuilder.Api.Controllers;
[ApiController,Route("api/reports"),Authorize]
public class ReportsController(ApplicationDbContext db):ControllerBase
{
 [HttpGet("application/{appId:int}")] public async Task<IActionResult> Get(int appId,CancellationToken ct)=>Ok(await db.Reports.AsNoTracking().Where(x=>x.ApplicationId==appId&&x.IsActive).OrderBy(x=>x.ReportName).ToListAsync(ct));
 [HttpPost] public async Task<IActionResult> Create(Report x,CancellationToken ct){x.CreatedBy=User.FindFirst("oid")?.Value??User.FindFirst("sub")?.Value??"anonymous";db.Reports.Add(x);await db.SaveChangesAsync(ct);return Ok(x);}
 [HttpPut("{id:int}")] public async Task<IActionResult> Update(int id,Report input,CancellationToken ct){var x=await db.Reports.FindAsync([id],ct);if(x is null)return NotFound();x.ReportName=input.ReportName;x.Description=input.Description;x.QueryJson=input.QueryJson;x.ConfigurationJson=input.ConfigurationJson;x.IsPublic=input.IsPublic;x.IsActive=input.IsActive;await db.SaveChangesAsync(ct);return Ok(x);}
}
