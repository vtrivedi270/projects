using ApplicationBuilder.Application.DTOs; using ApplicationBuilder.Application.Interfaces; using Microsoft.AspNetCore.Authorization; using Microsoft.AspNetCore.Mvc;
namespace ApplicationBuilder.Api.Controllers;
[ApiController,Route("api"),Authorize]
public class WorkflowsController(IWorkflowService service):ControllerBase
{
 string UserId=>User.FindFirst("oid")?.Value??User.FindFirst("sub")?.Value??"anonymous";
 [HttpGet("applications/{appId:int}/workflows")] public async Task<IActionResult> Get(int appId,CancellationToken ct)=>Ok(await service.GetByApplicationAsync(appId,ct));
 [HttpPost("applications/{appId:int}/workflows")] public async Task<IActionResult> Create(int appId,SaveWorkflowDto dto,CancellationToken ct)=>Ok(await service.CreateAsync(appId,dto,UserId,ct));
 [HttpPost("workflows/{id:int}/publish")] public async Task<IActionResult> Publish(int id,CancellationToken ct){await service.PublishAsync(id,UserId,ct);return NoContent();}
}
