using ApplicationBuilder.Application.DTOs; using ApplicationBuilder.Application.Interfaces; using Microsoft.AspNetCore.Authorization; using Microsoft.AspNetCore.Mvc;
namespace ApplicationBuilder.Api.Controllers;
[ApiController,Route("api/applications"),Authorize]
public class ApplicationsController(IApplicationService service):ControllerBase
{
 string UserId=>User.FindFirst("oid")?.Value??User.FindFirst("sub")?.Value??"anonymous";
 [HttpGet] public async Task<IActionResult> Get(CancellationToken ct)=>Ok(await service.GetAllAsync(ct));
 [HttpGet("{id:int}")] public async Task<IActionResult> Get(int id,CancellationToken ct){var x=await service.GetAsync(id,ct);return x is null?NotFound():Ok(x);}
 [HttpPost] public async Task<IActionResult> Create(SaveApplicationDto dto,CancellationToken ct)=>Ok(await service.CreateAsync(dto,UserId,ct));
 [HttpPut("{id:int}")] public async Task<IActionResult> Update(int id,SaveApplicationDto dto,CancellationToken ct){await service.UpdateAsync(id,dto,UserId,ct);return NoContent();}
 [HttpDelete("{id:int}")] public async Task<IActionResult> Delete(int id,CancellationToken ct){await service.DeleteAsync(id,ct);return NoContent();}
}
