using ApplicationBuilder.Application.DTOs; using ApplicationBuilder.Application.Interfaces; using Microsoft.AspNetCore.Authorization; using Microsoft.AspNetCore.Mvc;
namespace ApplicationBuilder.Api.Controllers;
[ApiController,Route("api"),Authorize]
public class FormsController(IFormService service):ControllerBase
{
 string UserId=>User.FindFirst("oid")?.Value??User.FindFirst("sub")?.Value??"anonymous";
 [HttpGet("forms/{id:int}")] public async Task<IActionResult> Get(int id,CancellationToken ct){var x=await service.GetAsync(id,ct);return x is null?NotFound():Ok(x);}
 [HttpPost("applications/{appId:int}/forms")] public async Task<IActionResult> Create(int appId,SaveFormDto dto,CancellationToken ct)=>Ok(await service.CreateAsync(appId,dto,UserId,ct));
 [HttpPut("forms/{id:int}")] public async Task<IActionResult> Update(int id,SaveFormDto dto,CancellationToken ct){await service.UpdateAsync(id,dto,UserId,ct);return NoContent();}
 [HttpPost("forms/{id:int}/publish")] public async Task<IActionResult> Publish(int id,CancellationToken ct){await service.PublishAsync(id,UserId,ct);return NoContent();}
}
