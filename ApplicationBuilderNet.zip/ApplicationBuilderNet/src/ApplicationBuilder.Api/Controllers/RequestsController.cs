using ApplicationBuilder.Application.DTOs; using ApplicationBuilder.Application.Interfaces; using Microsoft.AspNetCore.Authorization; using Microsoft.AspNetCore.Mvc;
namespace ApplicationBuilder.Api.Controllers;
[ApiController,Route("api"),Authorize]
public class RequestsController(IRequestService service):ControllerBase
{
 string UserId=>User.FindFirst("oid")?.Value??User.FindFirst("sub")?.Value??"anonymous";
 [HttpGet("applications/{appId:int}/requests")] public async Task<IActionResult> List(int appId,[FromQuery]bool approvals=false,[FromQuery]int page=1,[FromQuery]int pageSize=20,[FromQuery]string? search=null,CancellationToken ct=default){page=Math.Max(1,page);pageSize=Math.Clamp(pageSize,1,200);var x=await service.ListAsync(appId,UserId,approvals,page,pageSize,search,ct);return Ok(new{items=x.Items,total=x.Total,page,pageSize});}
 [HttpPost("applications/{appId:int}/requests")] public async Task<IActionResult> Create(int appId,SaveRequestDto dto,CancellationToken ct){var x=await service.CreateAsync(appId,dto,UserId,ct);return Ok(new{requestId=x.Id,requestNumber=x.Number});}
 [HttpGet("requests/{id:long}")] public async Task<IActionResult> Get(long id,CancellationToken ct){var x=await service.GetAsync(id,UserId,ct);return x is null?NotFound():Ok(x);}
 [HttpPut("requests/{id:long}")] public async Task<IActionResult> Update(long id,Dictionary<string,object?> data,CancellationToken ct){await service.UpdateAsync(id,data,UserId,ct);return NoContent();}
 [HttpDelete("requests/{id:long}")] public async Task<IActionResult> Delete(long id,CancellationToken ct){await service.DeleteAsync(id,UserId,ct);return NoContent();}
 [HttpPost("requests/{id:long}/submit")] public async Task<IActionResult> Submit(long id,CancellationToken ct){await service.SubmitAsync(id,UserId,ct);return NoContent();}
 [HttpPost("workflow-tasks/{taskId:long}/action")] public async Task<IActionResult> Act(long taskId,ActionDto dto,CancellationToken ct){await service.ActAsync(taskId,dto,UserId,ct);return NoContent();}
}
