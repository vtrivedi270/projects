using ApplicationBuilder.Api.Extensions;
var builder=WebApplication.CreateBuilder(args);
builder.Services.AddControllers().AddJsonOptions(o=>o.JsonSerializerOptions.PropertyNamingPolicy=System.Text.Json.JsonNamingPolicy.CamelCase);
builder.Services.AddPlatform(builder.Configuration);
builder.Services.AddHttpClient();
builder.Services.AddScoped<ApplicationBuilder.Application.Interfaces.IFileStorageService, ApplicationBuilder.Infrastructure.Services.SharePointFileStorageService>();
builder.Services.AddCors(o=>o.AddPolicy("spfx",p=>p.AllowAnyOrigin().AllowAnyHeader().AllowAnyMethod()));
var app=builder.Build();
if(app.Environment.IsDevelopment()){app.UseSwagger();app.UseSwaggerUI();}
app.UseHttpsRedirection();app.UseCors("spfx");app.UseAuthentication();app.UseAuthorization();app.MapControllers();app.MapGet("/health",()=>Results.Ok(new{status="ok",utc=DateTime.UtcNow,service="ApplicationBuilder.Api"}));app.Run();
