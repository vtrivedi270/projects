using ApplicationBuilder.Domain.Entities;
using Microsoft.EntityFrameworkCore;

namespace ApplicationBuilder.Infrastructure.Data;

public class ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : DbContext(options)
{
    public DbSet<Application> Applications => Set<Application>(); public DbSet<Form> Forms => Set<Form>(); public DbSet<FormSection> FormSections => Set<FormSection>(); public DbSet<FormField> FormFields => Set<FormField>(); public DbSet<FieldOption> FieldOptions => Set<FieldOption>();
    public DbSet<Workflow> Workflows => Set<Workflow>(); public DbSet<WorkflowStage> WorkflowStages => Set<WorkflowStage>(); public DbSet<WorkflowApprover> WorkflowApprovers => Set<WorkflowApprover>(); public DbSet<WorkflowTransition> WorkflowTransitions => Set<WorkflowTransition>();
    public DbSet<AppUser> AppUsers => Set<AppUser>(); public DbSet<AppRole> AppRoles => Set<AppRole>(); public DbSet<Permission> Permissions => Set<Permission>(); public DbSet<UserRole> UserRoles => Set<UserRole>(); public DbSet<RolePermission> RolePermissions => Set<RolePermission>(); public DbSet<OrganizationUnit> OrganizationUnits => Set<OrganizationUnit>(); public DbSet<ApplicationPermission> ApplicationPermissions => Set<ApplicationPermission>();
    public DbSet<Request> Requests => Set<Request>(); public DbSet<RequestValue> RequestValues => Set<RequestValue>(); public DbSet<WorkflowInstance> WorkflowInstances => Set<WorkflowInstance>(); public DbSet<WorkflowTask> WorkflowTasks => Set<WorkflowTask>(); public DbSet<WorkflowAction> WorkflowActions => Set<WorkflowAction>();
    public DbSet<Delegation> Delegations => Set<Delegation>(); public DbSet<SharePointLibrary> SharePointLibraries => Set<SharePointLibrary>(); public DbSet<Attachment> Attachments => Set<Attachment>(); public DbSet<RequestHistory> RequestHistories => Set<RequestHistory>(); public DbSet<AuditLog> AuditLogs => Set<AuditLog>(); public DbSet<Report> Reports => Set<Report>(); public DbSet<NotificationQueue> NotificationQueues => Set<NotificationQueue>();

    protected override void OnModelCreating(ModelBuilder b)
    {
        b.HasDefaultSchema("ab");
        b.Entity<Application>(e=>{e.ToTable("Application");e.HasKey(x=>x.ApplicationId);e.Property(x=>x.RowVersion).IsRowVersion();e.HasIndex(x=>x.ApplicationCode).IsUnique();});
        b.Entity<Form>(e=>{e.ToTable("Form");e.HasKey(x=>x.FormId);e.Property(x=>x.RowVersion).IsRowVersion();e.HasIndex(x=>new{x.ApplicationId,x.FormCode}).IsUnique();e.HasOne(x=>x.Application).WithMany(x=>x.Forms).HasForeignKey(x=>x.ApplicationId);});
        b.Entity<FormSection>(e=>{e.ToTable("FormSection");e.HasKey(x=>x.SectionId);e.HasIndex(x=>new{x.FormId,x.SectionKey}).IsUnique();e.HasOne(x=>x.Form).WithMany(x=>x.Sections).HasForeignKey(x=>x.FormId);});
        b.Entity<FormField>(e=>{e.ToTable("FormField");e.HasKey(x=>x.FieldId);e.HasIndex(x=>new{x.SectionId,x.FieldKey}).IsUnique();e.HasOne(x=>x.Section).WithMany(x=>x.Fields).HasForeignKey(x=>x.SectionId);});
        b.Entity<FieldOption>(e=>{e.ToTable("FieldOption");e.HasKey(x=>x.OptionId);e.HasOne(x=>x.Field).WithMany(x=>x.Options).HasForeignKey(x=>x.FieldId);});
        b.Entity<Workflow>(e=>{e.ToTable("Workflow");e.HasKey(x=>x.WorkflowId);e.Property(x=>x.RowVersion).IsRowVersion();e.HasOne(x=>x.Application).WithMany(x=>x.Workflows).HasForeignKey(x=>x.ApplicationId);});
        b.Entity<WorkflowStage>(e=>{e.ToTable("WorkflowStage");e.HasKey(x=>x.StageId);e.HasOne(x=>x.Workflow).WithMany(x=>x.Stages).HasForeignKey(x=>x.WorkflowId);});
        b.Entity<WorkflowApprover>(e=>{e.ToTable("WorkflowApprover");e.HasKey(x=>x.WorkflowApproverId);e.HasOne(x=>x.Stage).WithMany(x=>x.Approvers).HasForeignKey(x=>x.StageId);});
        b.Entity<WorkflowTransition>(e=>{e.ToTable("WorkflowTransition");e.HasKey(x=>x.TransitionId);e.HasOne(x=>x.Workflow).WithMany().HasForeignKey(x=>x.WorkflowId);});
        b.Entity<AppUser>(e=>{e.ToTable("AppUser");e.HasKey(x=>x.UserId);e.HasOne(x=>x.Manager).WithMany().HasForeignKey(x=>x.ManagerUserId).OnDelete(DeleteBehavior.Restrict);});
        b.Entity<AppRole>(e=>{e.ToTable("AppRole");e.HasKey(x=>x.RoleId);e.HasIndex(x=>x.RoleCode).IsUnique();}); b.Entity<Permission>(e=>{e.ToTable("Permission");e.HasKey(x=>x.PermissionId);e.HasIndex(x=>x.PermissionCode).IsUnique();});
        b.Entity<UserRole>(e=>{e.ToTable("UserRole");e.HasKey(x=>new{x.UserId,x.RoleId,x.ApplicationId});}); b.Entity<RolePermission>(e=>{e.ToTable("RolePermission");e.HasKey(x=>new{x.RoleId,x.PermissionId});});
        b.Entity<OrganizationUnit>(e=>{e.ToTable("OrganizationUnit");e.HasKey(x=>x.OrganizationUnitId);}); b.Entity<ApplicationPermission>(e=>{e.ToTable("ApplicationPermission");e.HasKey(x=>x.ApplicationPermissionId);});
        b.Entity<Request>(e=>{e.ToTable("Request");e.HasKey(x=>x.RequestId);e.Property(x=>x.RowVersion).IsRowVersion();e.HasIndex(x=>x.RequestNumber).IsUnique();}); b.Entity<RequestValue>(e=>{e.ToTable("RequestValue");e.HasKey(x=>x.RequestValueId);});
        b.Entity<WorkflowInstance>(e=>{e.ToTable("WorkflowInstance");e.HasKey(x=>x.WorkflowInstanceId);}); b.Entity<WorkflowTask>(e=>{e.ToTable("WorkflowTask");e.HasKey(x=>x.WorkflowTaskId);}); b.Entity<WorkflowAction>(e=>{e.ToTable("WorkflowAction");e.HasKey(x=>x.WorkflowActionId);});
        b.Entity<Delegation>(e=>{e.ToTable("Delegation");e.HasKey(x=>x.DelegationId);}); b.Entity<SharePointLibrary>(e=>{e.ToTable("SharePointLibrary");e.HasKey(x=>x.SharePointLibraryId);}); b.Entity<Attachment>(e=>{e.ToTable("Attachment");e.HasKey(x=>x.AttachmentId);});
        b.Entity<RequestHistory>(e=>{e.ToTable("RequestHistory");e.HasKey(x=>x.HistoryId);}); b.Entity<AuditLog>(e=>{e.ToTable("AuditLog");e.HasKey(x=>x.AuditId);}); b.Entity<Report>(e=>{e.ToTable("Report");e.HasKey(x=>x.ReportId);}); b.Entity<NotificationQueue>(e=>{e.ToTable("NotificationQueue");e.HasKey(x=>x.NotificationQueueId);});
    }
}
