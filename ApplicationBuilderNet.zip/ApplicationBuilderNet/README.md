# Application Builder Platform - .NET 8 Backend

This package is the backend foundation for the metadata-driven Application Builder described in the specification.

## Included

- .NET 8 Web API
- EF Core 8 + SQL Server
- Entra ID / JWT bearer authentication
- Application management
- Dynamic Form Builder metadata APIs
- Dynamic form sections/fields/options
- Workflow Builder metadata APIs
- Workflow runtime: submit, task assignment, approve, reject, return
- Reporting Manager resolution from AppUser.ManagerUserId
- Role/permission/application-permission administration
- User administration
- Delegation administration
- Request CRUD
- My Requests / My Approvals filtering
- Request history
- SharePoint attachment upload using Microsoft Graph application permissions
- Report metadata APIs
- Notification worker skeleton
- Swagger
- SQL database script copied as `database.sql`

## Architecture

```text
SPFx React Shell
      |
      | Bearer token from Microsoft Entra ID
      v
ApplicationBuilder.Api (.NET 8)
      |
      +-- Application Service
      +-- Form Service
      +-- Request Service
      +-- Workflow Service
      +-- SharePoint File Service
      |
      v
ApplicationDbContext / SQL Server
      |
      +-- Metadata tables
      +-- Request tables
      +-- Workflow runtime
      +-- Security
      +-- Audit/history
      |
      +--> SharePoint Document Libraries
```

## Projects

- `ApplicationBuilder.Api` - HTTP API
- `ApplicationBuilder.Application` - DTOs and service contracts
- `ApplicationBuilder.Domain` - domain entities
- `ApplicationBuilder.Infrastructure` - EF Core, services, SharePoint Graph integration
- `ApplicationBuilder.Worker` - notification/background processing

## Prerequisites

- .NET 8 SDK
- SQL Server 2019/2022 or Azure SQL
- Microsoft Entra ID app registration for the API
- Microsoft Graph application permissions for SharePoint file upload, with admin consent

## Database setup

1. Create database `ApplicationBuilder`.
2. Run `database.sql` in SQL Server Management Studio or Azure Data Studio.
3. Update the connection string in `src/ApplicationBuilder.Api/appsettings.json`.

The SQL script is the source of truth for the schema and seed data.

## Entra ID

Configure:

```json
"AzureAd": {
  "TenantId": "...",
  "ClientId": "API APP CLIENT ID",
  "ClientSecret": "...",
  "Audience": "api://API APP CLIENT ID"
}
```

For production, put the client secret in Azure Key Vault / environment variables instead of source-controlled appsettings.

The API expects a bearer token. The SPFx client should request an access token for the API and send:

```http
Authorization: Bearer <access-token>
```

## Run

```bash
dotnet restore ApplicationBuilder.sln
dotnet build ApplicationBuilder.sln
dotnet run --project src/ApplicationBuilder.Api/ApplicationBuilder.Api.csproj
```

Swagger:

```text
https://localhost:7043/swagger
```

Health:

```text
https://localhost:7043/health
```

Worker:

```bash
dotnet run --project src/ApplicationBuilder.Worker/ApplicationBuilder.Worker.csproj
```

## Core API endpoints

### Applications

```text
GET    /api/applications
GET    /api/applications/{id}
POST   /api/applications
PUT    /api/applications/{id}
DELETE /api/applications/{id}
```

### Forms

```text
GET    /api/forms/{id}
POST   /api/applications/{appId}/forms
PUT    /api/forms/{id}
POST   /api/forms/{id}/publish
```

The form JSON supports Ant Design controls through `ControlType`, for example:

```text
text
textarea
number
decimal
currency
date
datetime
time
select
multiselect
radio
checkbox
switch
autocomplete
userpicker
employeePicker
departmentpicker
lookup
cascadingSelect
richtext
file
table
repeater
parentChildGrid
formula
label
heading
```

### Requests

```text
GET    /api/applications/{appId}/requests?approvals=false
GET    /api/applications/{appId}/requests?approvals=true
POST   /api/applications/{appId}/requests
GET    /api/requests/{id}
PUT    /api/requests/{id}
DELETE /api/requests/{id}
POST   /api/requests/{id}/submit
```

### Workflow

```text
GET    /api/applications/{appId}/workflows
POST   /api/applications/{appId}/workflows
POST   /api/workflows/{id}/publish
POST   /api/workflow-tasks/{taskId}/action
```

Action body:

```json
{
  "actionCode": "APPROVE",
  "comments": "Approved"
}
```

Supported runtime actions:

- APPROVE
- REJECT
- RETURN

## SharePoint

Each application can have one configured SharePoint library in `ab.SharePointLibrary`.

The API stores only attachment metadata in SQL. Actual files are uploaded to SharePoint through Microsoft Graph.

Endpoint:

```text
POST /api/requests/{requestId}/attachments
Content-Type: multipart/form-data
```

The backend currently uploads to:

```text
Requests/{requestId}/{fileName}
```

## Security

Authentication is JWT/Entra ID based. Authorization must be enforced on the API; UI hiding is not considered security.

System roles seeded by SQL:

- ADMIN
- APPLICATION_ADMIN
- HR
- DIVISION_HEAD
- DEPARTMENT_HEAD
- REPORTING_MANAGER
- EMPLOYEE
- AUDITOR
- INTERVIEWER

The admin controller uses Entra role claims (`ADMIN`, `APPLICATION_ADMIN`) for the administrative endpoints. In a production deployment, map Entra app roles or replace this with the database permission policy/authorization handler.

## Versioning rule

Do not mutate a published form/workflow definition when existing requests depend on it. Publish a new version for future requests.

## Important production hardening

Before production:

1. Replace wildcard CORS with the exact SharePoint tenant/domain.
2. Store secrets in Key Vault/environment configuration.
3. Add database-backed permission authorization policies for every command/query.
4. Add antivirus/file-type/size validation for uploads.
5. Add Graph retry/throttling handling.
6. Add structured logging and Application Insights.
7. Add rate limiting.
8. Add optimistic concurrency handling around requests and workflow tasks.
9. Add transactional workflow transition handling for parallel approvals.
10. Add an outbox pattern for guaranteed email/Teams notifications.
11. Add report query validation; never execute arbitrary SQL supplied by an administrator without a strict allow-list/query builder.

## Important note about this generated package

The SQL schema is included and the API source is organized to be directly extended into the full production platform. The environment used to generate this archive does not have the .NET SDK installed, so `dotnet build` could not be executed here. Run `dotnet restore` and `dotnet build` on a machine with .NET 8 SDK before deployment.
