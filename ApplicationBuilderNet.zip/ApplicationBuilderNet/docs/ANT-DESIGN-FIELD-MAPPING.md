# React / Ant Design mapping

The API does not render controls itself. It returns metadata. The React dynamic renderer maps `controlType` to Ant Design components.

| ControlType | Ant Design component |
|---|---|
| text | Input |
| textarea | Input.TextArea |
| number | InputNumber |
| decimal | InputNumber |
| currency | InputNumber |
| date | DatePicker |
| datetime | DatePicker showTime |
| time | TimePicker |
| select | Select |
| multiselect | Select mode=multiple |
| radio | Radio.Group |
| checkbox | Checkbox |
| switch | Switch |
| autocomplete | AutoComplete |
| userpicker | Select / custom Entra picker |
| employeePicker | Select / custom Entra picker |
| departmentpicker | Select / metadata lookup |
| lookup | Select / API lookup |
| cascadingSelect | Cascading Select / Cascader |
| richtext | Rich text editor wrapper |
| file | Upload |
| table | Table + Form.List |
| repeater | Form.List |
| parentChildGrid | Table + modal Form |
| formula | read-only computed Form.Item |
| label | Typography.Text |
| heading | Typography.Title |
