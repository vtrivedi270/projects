# API Endpoint Map

## Shell / Dashboard
- GET `/health`
- GET `/api/dashboard`
- GET `/api/dashboard/summary`

## Applications
- GET/POST `/api/applications`
- GET/PUT/DELETE `/api/applications/{id}`

## Forms
- GET `/api/forms/{id}`
- POST `/api/applications/{appId}/forms`
- PUT `/api/forms/{id}`
- POST `/api/forms/{id}/publish`

## Workflow
- GET/POST `/api/applications/{appId}/workflows`
- POST `/api/workflows/{id}/publish`
- POST `/api/workflow-tasks/{taskId}/action`

## Requests
- GET `/api/applications/{appId}/requests?approvals=false`
- GET `/api/applications/{appId}/requests?approvals=true`
- POST `/api/applications/{appId}/requests`
- GET `/api/requests/{id}`
- PUT `/api/requests/{id}`
- DELETE `/api/requests/{id}`
- POST `/api/requests/{id}/submit`

## Attachments
- POST `/api/requests/{requestId}/attachments`
- GET `/api/requests/{requestId}/attachments`
- DELETE `/api/requests/{requestId}/attachments/{id}`

## Admin
- GET/POST/PUT `/api/admin/users`
- GET `/api/admin/roles`
- GET `/api/admin/permissions`
- POST `/api/admin/user-roles`
- GET/POST `/api/admin/application-permissions/{appId}`
- GET/POST/DELETE `/api/admin/delegations`

## Reports
- GET `/api/reports/application/{appId}`
- POST/PUT `/api/reports`
