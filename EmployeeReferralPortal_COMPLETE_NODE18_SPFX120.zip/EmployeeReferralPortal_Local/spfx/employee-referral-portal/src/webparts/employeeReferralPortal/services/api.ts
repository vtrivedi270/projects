import { WebPartContext } from '@microsoft/sp-webpart-base';

export interface Job { id:number; jobTitle:string; department:string; location?:string; positions:number; dueDate:string; description?:string; requirements?:string; status:string; createdAt:string; approvals?: JobApproval[]; }
export interface JobApproval { id:number; approvalLevel:string; status:string; comments?:string; approvedAt?:string; }
export interface Referral { id:number; jobId:number; candidateName:string; candidateEmail:string; candidatePhone?:string; experienceYears?:number; resumeFileName?:string; resumePath?:string; whyGoodFit?:string; status:string; createdAt:string; interviews?:Interview[]; finalApprovals?:FinalApproval[]; }
export interface Interview { id:number; referralId:number; roundNo:number; interviewType:string; scheduledAt?:string; interviewerUserId?:number; status:string; calendarEventId?:string; onlineMeetingUrl?:string; feedback?:Feedback; }
export interface Feedback { id:number; overallRating?:number; technicalSkills?:number; communicationSkills?:number; problemSolving?:number; strengths?:string; improvementAreas?:string; comments?:string; submittedAt?:string; }
export interface FinalApproval { id:number; approvalLevel:string; status:string; comments?:string; actionAt?:string; }
export interface Me { id:number; fullName:string; email:string; role:string; department?:string; objectId?:string; tokenRoles:string[]; }
export interface Interviewer { id:number; fullName:string; email:string; role:string; }

export class ReferralApi {
  constructor(private context: WebPartContext, private baseUrl: string) {}
  private headers(extra:Record<string,string>={}) { return { 'Content-Type':'application/json', 'X-Dev-User': this.context.pageContext.user.email || 'vishal@local.test', 'X-Dev-Name': this.context.pageContext.user.displayName || 'Vishal Trivedi', ...extra }; }
  private async request<T>(path:string, init:RequestInit = {}):Promise<T> {
    const response = await fetch(`${this.baseUrl.replace(/\/$/,'')}${path}`, { ...init, headers: { ...this.headers(), ...(init.headers||{}) } });
    if (!response.ok) throw new Error(`${response.status}: ${await response.text()}`);
    return response.status===204 ? undefined as T : response.json();
  }
  getJobs(search=''):Promise<Job[]> { return this.request<Job[]>(`/api/jobs${search?`?search=${encodeURIComponent(search)}`:''}`); }
  createJob(body:unknown):Promise<Job>{return this.request<Job>('/api/jobs',{method:'POST',body:JSON.stringify(body)});}
  approveJob(id:number,status:'Approved'|'Rejected',comments?:string):Promise<Job>{return this.request<Job>(`/api/jobs/${id}/approval`,{method:'POST',body:JSON.stringify({status,comments})});}
  getMyReferrals():Promise<Referral[]>{return this.request<Referral[]>('/api/referrals/my');}
  getAllReferrals():Promise<Referral[]>{return this.request<Referral[]>('/api/referrals');}
  getAssignedReferrals():Promise<Referral[]>{return this.request<Referral[]>('/api/referrals/assigned');}
  getReferral(id:number):Promise<Referral>{return this.request<Referral>(`/api/referrals/${id}`);}
  createReferral(body:unknown):Promise<Referral>{return this.request<Referral>('/api/referrals',{method:'POST',body:JSON.stringify(body)});}
  scheduleInterview(id:number,body:unknown):Promise<Interview>{return this.request<Interview>(`/api/referrals/${id}/interviews`,{method:'POST',body:JSON.stringify(body)});}
  submitFeedback(interviewId:number,body:unknown):Promise<Feedback>{return this.request<Feedback>(`/api/referrals/interviews/${interviewId}/feedback`,{method:'POST',body:JSON.stringify(body)});}
  finalApproval(id:number,level:'DivisionHead'|'HRHead',status:'Approved'|'Rejected',comments?:string):Promise<Referral>{return this.request<Referral>(`/api/referrals/${id}/final-approval/${level}`,{method:'POST',body:JSON.stringify({status,comments})});}
  updateStatus(id:number,status:string):Promise<Referral>{return this.request<Referral>(`/api/referrals/${id}/status`,{method:'PUT',body:JSON.stringify({status})});}
  dashboard():Promise<{openJobs:number;pendingJobs:number;referrals:number;interviews:number;hired:number}>{return this.request('/api/dashboard');}
  getInterviewers():Promise<Interviewer[]>{return this.request<Interviewer[]>('/api/users/interviewers');}
  me():Promise<Me>{return this.request<Me>('/api/auth/me');}
  async uploadResumeToReferral(referralId:number,file:File):Promise<any>{return this.uploadResume(referralId,file);}
  async uploadResume(referralId:number,file:File):Promise<any>{
    const fd=new FormData(); fd.append('file',file,file.name);
    const response=await fetch(`${this.baseUrl.replace(/\/$/,'')}/api/referrals/${referralId}/resume`,{method:'POST',headers:{'X-Dev-User':this.context.pageContext.user.email||'vishal@local.test','X-Dev-Name':this.context.pageContext.user.displayName||'Vishal Trivedi'},body:fd});
    if(!response.ok) throw new Error(`${response.status}: ${await response.text()}`); return response.json();
  }
}