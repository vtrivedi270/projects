# SPFx Local Mode

No Entra ID/API permission request is included in this build. The web part sends the current SharePoint context user as `X-Dev-User` to the local API.

This is for local development/UAT only. Do not use this header-based authentication in production.
