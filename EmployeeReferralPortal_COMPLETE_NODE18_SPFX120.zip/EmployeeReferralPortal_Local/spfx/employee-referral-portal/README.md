# Employee Referral Portal — SPFx 1.20 + Node 18

This SPFx project intentionally uses the Microsoft-supported SPFx 1.20 toolchain for Node.js 18: legacy Gulp build, React 17.0.1 and TypeScript 4.7.

## Prerequisites
- Windows 10/11
- Node.js 18.20.x (use NVM for Windows if possible)
- npm
- SharePoint Online tenant for the SPFx workbench
- .NET 8 SDK for the API
- SQL Server / LocalDB

## SPFx — first run
```powershell
cd spfx\employee-referral-portal
nvm use 18.20.8
npm install
npm run build
npm start
```

For the hosted SharePoint workbench, set the tenant domain before `npm start`:
```powershell
$env:SPFX_SERVE_TENANT_DOMAIN = "yourtenant.sharepoint.com"
npm start
```
Then open the hosted workbench URL shown by Gulp and add **Employee Referral Portal**.

## API
```powershell
cd backend\EmployeeReferral.Api
dotnet run
```
API defaults:
- https://localhost:5001
- http://localhost:5000
- Swagger: https://localhost:5001/swagger

If Windows asks you to trust the .NET development certificate:
```powershell
dotnet dev-certs https --trust
```

## Build output
After `npm run build`, the deployable SharePoint package is:
`sharepoint/solution/employee-referral-portal.sppkg`

## Important
The SPFx 1.20 + Node 18 combination is deliberate. Do not install SPFx 1.22/1.23 packages into this project while using Node 18; Microsoft lists SPFx 1.20 with Node 18 and SPFx 1.22+ with Node 22.
