# Employee Referral Portal — Complete Solution (Node.js 18)

This package is prepared around **Node.js 18.20.8** for the SPFx project.

## Microsoft compatibility choice
The SPFx web part is pinned to **SPFx 1.20.0**, React **17.0.1**, and TypeScript **4.7.4**. Microsoft lists SPFx 1.20.0 with Node.js 18, while newer SPFx 1.22+ releases require Node.js 22. Do not mix those toolchains.

## 1. Select Node 18
```powershell
cd EmployeeReferralPortal_Local
nvm install 18.20.8
nvm use 18.20.8
node -v
npm -v
```

## 2. SPFx
```powershell
cd spfx\employee-referral-portal
npm install
npm run build
npm start
```

For a SharePoint hosted workbench:
```powershell
$env:SPFX_SERVE_TENANT_DOMAIN = "yourtenant.sharepoint.com"
npm start
```

The deployable package will be created at:
`sharepoint\solution\employee-referral-portal.sppkg`

## 3. .NET 8 API
Open a second PowerShell window:
```powershell
cd backend\EmployeeReferral.Api
dotnet dev-certs https --trust
dotnet run
```

API:
- https://localhost:5001
- Swagger: https://localhost:5001/swagger

## 4. SQL Server
Run the scripts in `database` in this order:
1. 01_schema.sql
2. 02_seed.sql
3. 03_email_notifications.sql
4. 04_production_upgrade.sql
5. 05_rbac.sql

## 5. Standalone React frontend
The `frontend` folder can be run independently for browser/UAT testing. It does not replace the SPFx package; it is included as a standalone UI option.

## Important
The archive contains source/configuration, not `node_modules` and not a prebuilt `.sppkg`. Run `npm install` then `npm run build` to generate the SharePoint package on your machine.
