IF DB_ID('EmployeeReferralPortalLocal') IS NULL CREATE DATABASE EmployeeReferralPortalLocal;
GO
USE EmployeeReferralPortalLocal;
GO

IF OBJECT_ID('dbo.Users','U') IS NULL CREATE TABLE dbo.Users(
 Id INT IDENTITY PRIMARY KEY, FullName NVARCHAR(150) NOT NULL, Email NVARCHAR(320) NOT NULL UNIQUE,
 Role NVARCHAR(50) NOT NULL DEFAULT 'Employee', Department NVARCHAR(100), EntraObjectId NVARCHAR(100), IsActive BIT NOT NULL DEFAULT 1
);
IF OBJECT_ID('dbo.Jobs','U') IS NULL CREATE TABLE dbo.Jobs(
 Id INT IDENTITY PRIMARY KEY, JobTitle NVARCHAR(200) NOT NULL, Department NVARCHAR(100) NOT NULL, Location NVARCHAR(150),
 Positions INT NOT NULL, DueDate DATETIME2 NOT NULL, Description NVARCHAR(MAX), Requirements NVARCHAR(MAX), CreatedByUserId INT NOT NULL,
 Status NVARCHAR(80) NOT NULL, CreatedAt DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(), OpenedAt DATETIME2 NULL,
 CONSTRAINT FK_Jobs_Users FOREIGN KEY(CreatedByUserId) REFERENCES dbo.Users(Id)
);
IF OBJECT_ID('dbo.JobApprovals','U') IS NULL CREATE TABLE dbo.JobApprovals(
 Id INT IDENTITY PRIMARY KEY, JobId INT NOT NULL, ApprovalLevel NVARCHAR(50) NOT NULL, ApproverUserId INT NULL,
 Status NVARCHAR(30) NOT NULL DEFAULT 'Pending', Comments NVARCHAR(1000), ApprovedAt DATETIME2 NULL,
 CONSTRAINT FK_JobApprovals_Jobs FOREIGN KEY(JobId) REFERENCES dbo.Jobs(Id), CONSTRAINT FK_JobApprovals_Users FOREIGN KEY(ApproverUserId) REFERENCES dbo.Users(Id)
);
IF OBJECT_ID('dbo.Referrals','U') IS NULL CREATE TABLE dbo.Referrals(
 Id INT IDENTITY PRIMARY KEY, JobId INT NOT NULL, ReferrerUserId INT NOT NULL, CandidateName NVARCHAR(200) NOT NULL,
 CandidateEmail NVARCHAR(320) NOT NULL, CandidatePhone NVARCHAR(50), ExperienceYears DECIMAL(5,2), ResumeFileName NVARCHAR(500),
 ResumePath NVARCHAR(1000), WhyGoodFit NVARCHAR(MAX), Status NVARCHAR(80) NOT NULL DEFAULT 'Submitted', CreatedAt DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(), UpdatedAt DATETIME2 NULL,
 CONSTRAINT FK_Referrals_Jobs FOREIGN KEY(JobId) REFERENCES dbo.Jobs(Id), CONSTRAINT FK_Referrals_Users FOREIGN KEY(ReferrerUserId) REFERENCES dbo.Users(Id)
);
IF OBJECT_ID('dbo.Interviews','U') IS NULL CREATE TABLE dbo.Interviews(
 Id INT IDENTITY PRIMARY KEY, ReferralId INT NOT NULL, RoundNo INT NOT NULL, InterviewType NVARCHAR(100) NOT NULL,
 ScheduledAt DATETIME2 NULL, InterviewerUserId INT NULL, Status NVARCHAR(50) NOT NULL DEFAULT 'Pending',
 CONSTRAINT UQ_Interview_Round UNIQUE(ReferralId,RoundNo), CONSTRAINT FK_Interviews_Referrals FOREIGN KEY(ReferralId) REFERENCES dbo.Referrals(Id), CONSTRAINT FK_Interviews_Users FOREIGN KEY(InterviewerUserId) REFERENCES dbo.Users(Id)
);
IF OBJECT_ID('dbo.InterviewFeedback','U') IS NULL CREATE TABLE dbo.InterviewFeedback(
 Id INT IDENTITY PRIMARY KEY, InterviewId INT NOT NULL UNIQUE, OverallRating INT, TechnicalSkills INT, CommunicationSkills INT, ProblemSolving INT,
 Strengths NVARCHAR(MAX), ImprovementAreas NVARCHAR(MAX), Comments NVARCHAR(MAX), SubmittedByUserId INT NULL, SubmittedAt DATETIME2 NULL,
 CONSTRAINT FK_Feedback_Interviews FOREIGN KEY(InterviewId) REFERENCES dbo.Interviews(Id), CONSTRAINT FK_Feedback_Users FOREIGN KEY(SubmittedByUserId) REFERENCES dbo.Users(Id)
);
IF OBJECT_ID('dbo.FinalApprovals','U') IS NULL CREATE TABLE dbo.FinalApprovals(
 Id INT IDENTITY PRIMARY KEY, ReferralId INT NOT NULL, ApprovalLevel NVARCHAR(50) NOT NULL, ApproverUserId INT NULL,
 Status NVARCHAR(30) NOT NULL DEFAULT 'Pending', Comments NVARCHAR(1000), ActionAt DATETIME2 NULL,
 CONSTRAINT UQ_FinalApproval UNIQUE(ReferralId,ApprovalLevel), CONSTRAINT FK_FinalApproval_Referral FOREIGN KEY(ReferralId) REFERENCES dbo.Referrals(Id), CONSTRAINT FK_FinalApproval_User FOREIGN KEY(ApproverUserId) REFERENCES dbo.Users(Id)
);
IF OBJECT_ID('dbo.AuditLogs','U') IS NULL CREATE TABLE dbo.AuditLogs(
 Id BIGINT IDENTITY PRIMARY KEY, EntityType NVARCHAR(50) NOT NULL, EntityId INT NOT NULL, Action NVARCHAR(100) NOT NULL,
 Details NVARCHAR(MAX), UserId INT NULL, CreatedAt DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(), CONSTRAINT FK_Audit_User FOREIGN KEY(UserId) REFERENCES dbo.Users(Id)
);
GO
