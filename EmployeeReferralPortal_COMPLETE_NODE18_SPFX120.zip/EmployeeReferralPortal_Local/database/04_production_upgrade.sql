USE EmployeeReferralPortal;
GO
IF COL_LENGTH('dbo.Interviews','CalendarEventId') IS NULL ALTER TABLE dbo.Interviews ADD CalendarEventId NVARCHAR(500) NULL;
IF COL_LENGTH('dbo.Interviews','OnlineMeetingUrl') IS NULL ALTER TABLE dbo.Interviews ADD OnlineMeetingUrl NVARCHAR(2000) NULL;
GO
