USE EmployeeReferralPortalLocal;
GO
IF OBJECT_ID('dbo.RolePermissions','U') IS NULL
CREATE TABLE dbo.RolePermissions(
 Id INT IDENTITY PRIMARY KEY,
 Role NVARCHAR(50) NOT NULL,
 Permission NVARCHAR(100) NOT NULL,
 IsAllowed BIT NOT NULL DEFAULT 1,
 CONSTRAINT UQ_RolePermission UNIQUE(Role,Permission)
);
GO
DECLARE @json NVARCHAR(MAX)=N'[
{"Role":"Manager","Permission":"Job.Create"},{"Role":"Manager","Permission":"Job.Edit"},{"Role":"Manager","Permission":"Job.Delete"},
{"Role":"DeptHead","Permission":"Job.Approve"},
{"Role":"DivHead","Permission":"Job.Approve"},{"Role":"DivHead","Permission":"Referral.ViewAll"},{"Role":"DivHead","Permission":"Referral.FinalApprove"},
{"Role":"HR","Permission":"Referral.ViewAll"},{"Role":"HR","Permission":"Referral.Edit"},{"Role":"HR","Permission":"Interview.Schedule"},{"Role":"HR","Permission":"Interview.Feedback"},{"Role":"HR","Permission":"Resume.Upload"},{"Role":"HR","Permission":"Resume.View"},{"Role":"HR","Permission":"Referral.StatusUpdate"},
{"Role":"HRHead","Permission":"Referral.ViewAll"},{"Role":"HRHead","Permission":"Interview.Schedule"},{"Role":"HRHead","Permission":"Interview.Feedback"},{"Role":"HRHead","Permission":"Resume.Upload"},{"Role":"HRHead","Permission":"Resume.View"},{"Role":"HRHead","Permission":"Referral.FinalApprove"},{"Role":"HRHead","Permission":"Referral.StatusUpdate"},
{"Role":"Interviewer","Permission":"Interview.Feedback"},{"Role":"Interviewer","Permission":"Resume.View"},
{"Role":"Employee","Permission":"Referral.Create"},{"Role":"Employee","Permission":"Referral.Edit"},{"Role":"Employee","Permission":"Referral.Delete"},{"Role":"Employee","Permission":"Resume.Upload"},{"Role":"Employee","Permission":"Resume.View"}
]';
INSERT dbo.RolePermissions(Role,Permission,IsAllowed)
SELECT Role,Permission,1 FROM OPENJSON(@json) WITH(Role NVARCHAR(50) '$.Role',Permission NVARCHAR(100) '$.Permission') j
WHERE NOT EXISTS(SELECT 1 FROM dbo.RolePermissions r WHERE r.Role=j.Role AND r.Permission=j.Permission);
GO
