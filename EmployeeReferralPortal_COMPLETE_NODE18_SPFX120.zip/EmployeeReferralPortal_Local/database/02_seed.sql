USE EmployeeReferralPortalLocal;
GO
INSERT INTO dbo.Users(FullName,Email,Role,Department) VALUES
('Vishal Trivedi','vishal@contoso.com','Manager','IT'),
('Priya Shah','priya@contoso.com','DeptHead','IT'),
('Rahul Mehta','rahul@contoso.com','DivHead','IT'),
('Neha Patel','neha@contoso.com','HRHead','HR'),
('HR Recruiter','hr@contoso.com','HR','HR'),
('Technical Interviewer','interviewer@contoso.com','Interviewer','IT'),
('Demo Employee','employee@contoso.com','Employee','IT');

INSERT INTO dbo.Jobs(JobTitle,Department,Location,Positions,DueDate,Description,Requirements,CreatedByUserId,Status,OpenedAt)
SELECT 'Senior .NET Developer','IT','Ahmedabad',2,'2026-09-30','Build enterprise APIs and integrations.','.NET 8, C#, SQL Server, REST, React',Id,'Open',SYSUTCDATETIME() FROM dbo.Users WHERE Email='vishal@contoso.com';
INSERT INTO dbo.Jobs(JobTitle,Department,Location,Positions,DueDate,Description,Requirements,CreatedByUserId,Status,OpenedAt)
SELECT 'React Developer','IT','Ahmedabad',3,'2026-09-25','Develop modern SPFx and React applications.','React, TypeScript, SPFx, Fluent UI',Id,'Open',SYSUTCDATETIME() FROM dbo.Users WHERE Email='vishal@contoso.com';
GO
