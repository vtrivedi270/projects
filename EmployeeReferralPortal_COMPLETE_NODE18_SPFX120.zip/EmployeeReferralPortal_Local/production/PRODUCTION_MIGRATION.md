# Employee Referral Portal - Production Migration

This package contains the complete source for:
- React standalone frontend
- SharePoint Framework (SPFx) React web part
- .NET 8 Web API
- SQL Server schema/seed/upgrade scripts
- Local development services

## Production architecture

SPFx React -> .NET 8 API -> SQL Server
                    |-> Microsoft Entra ID authentication
                    |-> Microsoft Graph Mail / Calendar / Teams
                    |-> SharePoint document library for resumes

The local implementation deliberately replaces cloud dependencies with local services so the application can be developed and UAT-tested without a tenant.

## Production replacement points

1. `Services/LocalDevAuthentication.cs`
   Replace the local development authentication handler with Microsoft Entra/JWT bearer authentication.

2. `Services/LocalNotificationService.cs`
   Replace with Microsoft Graph `sendMail` implementation.

3. `Services/LocalCalendarService.cs`
   Replace with Microsoft Graph calendar/online-meeting implementation.

4. `Services/LocalFileService.cs`
   Replace with SharePoint/Graph document-library upload/download implementation.

5. `appsettings.json`
   Move production secrets to environment variables / Azure Key Vault. Do not commit secrets.

6. SPFx `services/api.ts`
   Replace local `fetch` authentication headers with `AadHttpClient`/secured API access and configure API permission requests for the production tenant.

## SQL deployment

Run `database/01_schema.sql`, then `02_seed.sql` only for non-production/demo data. Apply `03_email_notifications.sql` and `04_production_upgrade.sql` as required.

For production, create a dedicated SQL login/managed identity, least-privilege permissions, backups, monitoring, and migration process.

## Production checklist

- Entra app registration and API scope
- SPFx API permission approval
- HTTPS API endpoint
- SQL Server/Managed SQL database
- SharePoint resume library
- Graph Mail.Send
- Graph Calendars.ReadWrite / OnlineMeetings.ReadWrite as applicable
- Key Vault / secret management
- CORS restricted to approved origins
- File antivirus scanning and size/type validation
- Structured logging and Application Insights
- CI/CD build, test, security scan and deployment
- Database migrations and backup/restore procedure
- Disable all local-dev authentication headers before production
