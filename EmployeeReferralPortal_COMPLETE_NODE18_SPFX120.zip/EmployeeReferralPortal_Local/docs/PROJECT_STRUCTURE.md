# Project structure

- `backend/EmployeeReferral.Api/` - .NET 8 Web API, EF Core models, controllers and services
- `frontend/` - standalone React/Vite local UAT application
- `spfx/employee-referral-portal/` - SPFx React web part source and package configuration
- `database/` - SQL Server schema, seed and upgrade scripts
- `production/` - production configuration templates and migration checklist
- `LOCAL_TEST_USERS.md` - local role/user switching
- `README_LOCAL.md` - local setup
