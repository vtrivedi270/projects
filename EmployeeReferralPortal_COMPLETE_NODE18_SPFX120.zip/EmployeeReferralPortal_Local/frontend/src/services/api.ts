import axios from 'axios';

export const api = axios.create({ baseURL: import.meta.env.VITE_API_URL || 'http://localhost:5000/api' });
api.interceptors.request.use(config => {
  config.headers['X-Dev-User'] = localStorage.getItem('erp.dev.email') || 'employee@local.test';
  config.headers['X-Dev-Name'] = localStorage.getItem('erp.dev.name') || 'Demo Employee';
  config.headers['X-Dev-Role'] = localStorage.getItem('erp.dev.role') || 'Employee';
  return config;
});
