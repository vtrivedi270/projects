# Build status

The SPFx project has been converted from the previous SPFx 1.23/Heft configuration to a clean **SPFx 1.20 / Node 18 / Gulp** configuration.

The environment used to prepare this archive could not complete `npm install` because external npm registry access timed out. Therefore this archive is **source/configuration complete but not claimed as an end-to-end compiled build**.

On Windows, use Node 18.20.8 and run `npm install` followed by `npm run build`. If npm reports an error, use the first error line as the diagnostic; do not mix SPFx 1.23 packages into this project.
