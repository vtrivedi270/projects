$ErrorActionPreference = 'Stop'
Write-Host "Checking Node.js..." -ForegroundColor Cyan
node --version
npm --version
if (-not ((node --version) -match '^v18\.')) {
  throw "Node.js 18 is required for this solution. Run: nvm use 18.20.8"
}
Write-Host "Node.js 18 detected." -ForegroundColor Green
Write-Host "Checking SPFx package pin..." -ForegroundColor Cyan
$pkg = Get-Content .\spfx\employee-referral-portal\package.json -Raw | ConvertFrom-Json
if ($pkg.dependencies.'@microsoft/sp-core-library' -ne '1.20.0') { throw 'SPFx must be 1.20.0' }
if ($pkg.dependencies.react -ne '17.0.1') { throw 'React must be 17.0.1' }
if ($pkg.devDependencies.typescript -ne '4.7.4') { throw 'TypeScript must be 4.7.4' }
Write-Host "SPFx 1.20 / React 17 / TypeScript 4.7 configuration is correct." -ForegroundColor Green
