# Production Readiness Matrix

## Included
- SPFx React source
- Standalone React UAT source
- .NET 8 Web API source
- SQL schema and seed scripts
- Job CRUD
- Referral CRUD
- Interview scheduling/feedback workflow
- 3-round interview flow
- Job approval workflow
- Final approval workflow
- Resume local storage abstraction
- Notification abstraction
- Calendar abstraction
- Audit logs
- Central RolePermission matrix
- Permission API (`GET /api/permissions/mine`, admin matrix endpoints)
- Local role switcher

## Environment-specific replacement
- Entra ID authentication
- Microsoft Graph email
- Microsoft Graph Teams/Calendar
- SharePoint resume storage
- Production SQL authentication
- HTTPS/CORS/secrets

Do not expose the local authentication mode in production.
