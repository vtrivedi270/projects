# Employee Referral Portal - Local V6 (CRUD)

This V6 is a local-only functional build. It removes Entra ID, Graph and SharePoint runtime dependencies.

## Functional CRUD
- Jobs: Create, Edit, Delete, View, approval workflow and SQL persistence.
- Referrals: Create, Edit, Delete, View, resume upload/download and SQL persistence.
- Job approval: DeptHead -> DivHead -> HRHead -> Open.
- Referral workflow APIs: interview scheduling, feedback, Division Head approval, HR Head approval.
- Local notifications: HTML email files under API `local-mailbox`.
- Local meetings: generated localhost meeting URLs.
- Role switcher: change local test user from the UI without changing M365 login.

## Run API
1. Install .NET 8 SDK and SQL Server LocalDB.
2. `cd backend/EmployeeReferral.Api`
3. `dotnet restore`
4. `dotnet run`
5. API: http://localhost:5000 and Swagger: http://localhost:5000/swagger

## Run browser UI
1. `cd frontend`
2. `npm install`
3. `npm run dev`
4. Open the Vite URL shown in the terminal.

The UI role selector lets you test Employee, Manager, DeptHead, DivHead, HR, HRHead, Interviewer and Admin.

## SPFx package
The SPFx source is in `spfx/employee-referral-portal`. The `.sppkg` can be built on a Windows machine with the matching SPFx toolchain. A SharePoint tenant is not required merely to compile the package, but SharePoint is required to host the SPFx webpart.
