namespace EmployeeReferral.Api.Models;

public class User
{
    public int Id { get; set; }
    public string FullName { get; set; } = "";
    public string Email { get; set; } = "";
    public string Role { get; set; } = "Employee";
    public string? Department { get; set; }
    public string? EntraObjectId { get; set; }
    public bool IsActive { get; set; } = true;
}

public class Job
{
    public int Id { get; set; }
    public string JobTitle { get; set; } = "";
    public string Department { get; set; } = "";
    public string? Location { get; set; }
    public int Positions { get; set; }
    public DateTime DueDate { get; set; }
    public string? Description { get; set; }
    public string? Requirements { get; set; }
    public int CreatedByUserId { get; set; }
    public string Status { get; set; } = "Draft";
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? OpenedAt { get; set; }
    public List<JobApproval> Approvals { get; set; } = [];
}

public class JobApproval
{
    public int Id { get; set; }
    public int JobId { get; set; }
    public Job? Job { get; set; }
    public string ApprovalLevel { get; set; } = "";
    public int? ApproverUserId { get; set; }
    public string Status { get; set; } = "Pending";
    public string? Comments { get; set; }
    public DateTime? ApprovedAt { get; set; }
}

public class Referral
{
    public int Id { get; set; }
    public int JobId { get; set; }
    public int ReferrerUserId { get; set; }
    public string CandidateName { get; set; } = "";
    public string CandidateEmail { get; set; } = "";
    public string? CandidatePhone { get; set; }
    public decimal? ExperienceYears { get; set; }
    public string? ResumeFileName { get; set; }
    public string? ResumePath { get; set; }
    public string? WhyGoodFit { get; set; }
    public string Status { get; set; } = "Submitted";
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }
    public List<Interview> Interviews { get; set; } = [];
    public List<FinalApproval> FinalApprovals { get; set; } = [];
}

public class Interview
{
    public int Id { get; set; }
    public int ReferralId { get; set; }
    public Referral? Referral { get; set; }
    public int RoundNo { get; set; }
    public string InterviewType { get; set; } = "Technical";
    public DateTime? ScheduledAt { get; set; }
    public int? InterviewerUserId { get; set; }
    public string Status { get; set; } = "Pending";
    public string? CalendarEventId { get; set; }
    public string? OnlineMeetingUrl { get; set; }
    public InterviewFeedback? Feedback { get; set; }
}

public class InterviewFeedback
{
    public int Id { get; set; }
    public int InterviewId { get; set; }
    public Interview? Interview { get; set; }
    public int? OverallRating { get; set; }
    public int? TechnicalSkills { get; set; }
    public int? CommunicationSkills { get; set; }
    public int? ProblemSolving { get; set; }
    public string? Strengths { get; set; }
    public string? ImprovementAreas { get; set; }
    public string? Comments { get; set; }
    public int? SubmittedByUserId { get; set; }
    public DateTime? SubmittedAt { get; set; }
}

public class FinalApproval
{
    public int Id { get; set; }
    public int ReferralId { get; set; }
    public Referral? Referral { get; set; }
    public string ApprovalLevel { get; set; } = "";
    public int? ApproverUserId { get; set; }
    public string Status { get; set; } = "Pending";
    public string? Comments { get; set; }
    public DateTime? ActionAt { get; set; }
}

public class AuditLog
{
    public long Id { get; set; }
    public string EntityType { get; set; } = "";
    public int EntityId { get; set; }
    public string Action { get; set; } = "";
    public string? Details { get; set; }
    public int? UserId { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}


public class NotificationLog
{
    public long Id { get; set; }
    public string EventType { get; set; } = "";
    public string? EntityType { get; set; }
    public int? EntityId { get; set; }
    public string Recipients { get; set; } = "";
    public string Subject { get; set; } = "";
    public string Status { get; set; } = "Sent";
    public string? ErrorMessage { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}

public class RolePermission
{
    public int Id { get; set; }
    public string Role { get; set; } = "";
    public string Permission { get; set; } = "";
    public bool IsAllowed { get; set; } = true;
}
