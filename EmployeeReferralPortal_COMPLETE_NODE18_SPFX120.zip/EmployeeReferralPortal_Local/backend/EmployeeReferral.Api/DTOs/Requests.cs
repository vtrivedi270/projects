namespace EmployeeReferral.Api.DTOs;

public record CreateJobRequest(string JobTitle,string Department,string? Location,int Positions,DateTime DueDate,string? Description,string? Requirements);
public record UpdateJobRequest(string JobTitle,string Department,string? Location,int Positions,DateTime DueDate,string? Description,string? Requirements);
public record ApprovalRequest(string Status,string? Comments);
public record CreateReferralRequest(int JobId,string CandidateName,string CandidateEmail,string? CandidatePhone,decimal? ExperienceYears,string? ResumeFileName,string? ResumePath,string? WhyGoodFit);
public record ScheduleInterviewRequest(int RoundNo,string InterviewType,DateTime ScheduledAt,int? InterviewerUserId);
public record FeedbackRequest(int OverallRating,int TechnicalSkills,int CommunicationSkills,int ProblemSolving,string? Strengths,string? ImprovementAreas,string? Comments);
public record StatusRequest(string Status);
public record UpdateReferralRequest(string CandidateName,string CandidateEmail,string? CandidatePhone,decimal? ExperienceYears,string? ResumeFileName,string? WhyGoodFit);
public record FinalApprovalRequest(string Status,string? Comments);
