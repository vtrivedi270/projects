using EmployeeReferral.Api.Data;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace EmployeeReferral.Api.Controllers;
[ApiController,Route("api/dashboard"),Authorize]
public class DashboardController(AppDbContext db) : ControllerBase
{
    [HttpGet]
    public async Task<IActionResult> Get(){return Ok(new{
        openJobs=await db.Jobs.CountAsync(x=>x.Status=="Open"),
        pendingJobs=await db.Jobs.CountAsync(x=>x.Status.StartsWith("Pending")),
        referrals=await db.Referrals.CountAsync(),
        interviews=await db.Interviews.CountAsync(x=>x.Status=="Scheduled"),
        hired=await db.Referrals.CountAsync(x=>x.Status=="Hired")
    });}
}
