using EmployeeReferral.Api.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace EmployeeReferral.Api.Controllers;

[ApiController, Route("api/auth"), Authorize]
public class AuthController(ICurrentUserService currentUser) : ControllerBase
{
    [HttpGet("me")]
    public async Task<IActionResult> Me()
    {
        var u = await currentUser.GetOrCreateAsync();
        return Ok(new { u.Id, u.FullName, u.Email, u.Role, u.Department, objectId = currentUser.ObjectId, tokenRoles = currentUser.TokenRoles });
    }
}
