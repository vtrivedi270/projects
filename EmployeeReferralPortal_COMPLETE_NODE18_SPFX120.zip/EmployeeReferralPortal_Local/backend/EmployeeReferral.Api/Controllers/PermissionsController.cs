using EmployeeReferral.Api.Data;
using EmployeeReferral.Api.Models;
using EmployeeReferral.Api.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace EmployeeReferral.Api.Controllers;

[ApiController, Route("api/permissions"), Authorize]
public class PermissionsController(AppDbContext db, ICurrentUserService currentUser, IPermissionService permissions) : ControllerBase
{
    [HttpGet("mine")]
    public async Task<IActionResult> Mine(CancellationToken ct) => Ok(await permissions.GetMineAsync(ct));

    [HttpGet("matrix")]
    public async Task<IActionResult> Matrix(CancellationToken ct)
    {
        if(!await currentUser.IsInRoleAsync("Admin",ct)) return Forbid();
        return Ok(await db.RolePermissions.AsNoTracking().OrderBy(x=>x.Role).ThenBy(x=>x.Permission).ToListAsync(ct));
    }

    [HttpPut("matrix/{id:int}")]
    public async Task<IActionResult> Update(int id,[FromBody] bool allowed,CancellationToken ct)
    {
        if(!await currentUser.IsInRoleAsync("Admin",ct)) return Forbid();
        var x=await db.RolePermissions.FindAsync([id],ct); if(x is null) return NotFound();
        x.IsAllowed=allowed; await db.SaveChangesAsync(ct); return Ok(x);
    }
}
