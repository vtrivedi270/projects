using EmployeeReferral.Api.Data;
using EmployeeReferral.Api.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace EmployeeReferral.Api.Controllers;
[ApiController,Route("api/users"),Authorize]
public class UsersController(AppDbContext db, ICurrentUserService currentUser, IPermissionService permissions) : ControllerBase
{
    [HttpGet("interviewers")]
    public async Task<IActionResult> Interviewers()
    {
        if(!await currentUser.IsInRoleAsync("HR")&&!await currentUser.IsInRoleAsync("HRHead")&&!await permissions.HasAsync(Permissions.UserManage)) return Forbid();
        return Ok(await db.Users.AsNoTracking().Where(x=>x.IsActive && (x.Role=="Interviewer" || x.Role=="HR" || x.Role=="HRHead")).OrderBy(x=>x.FullName).Select(x=>new{x.Id,x.FullName,x.Email,x.Role}).ToListAsync());
    }
}
