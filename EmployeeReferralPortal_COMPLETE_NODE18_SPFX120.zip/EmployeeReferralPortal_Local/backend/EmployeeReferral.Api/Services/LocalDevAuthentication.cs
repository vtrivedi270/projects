using System.Security.Claims;
using System.Text.Encodings.Web;
using Microsoft.AspNetCore.Authentication;
using Microsoft.Extensions.Options;

namespace EmployeeReferral.Api.Services;

public sealed class LocalDevAuthenticationOptions : AuthenticationSchemeOptions { }

public sealed class LocalDevAuthenticationHandler(
    IOptionsMonitor<LocalDevAuthenticationOptions> options,
    ILoggerFactory logger,
    UrlEncoder encoder) : AuthenticationHandler<LocalDevAuthenticationOptions>(options, logger, encoder)
{
    protected override Task<AuthenticateResult> HandleAuthenticateAsync()
    {
        var email = Request.Headers["X-Dev-User"].FirstOrDefault() ?? "vishal@local.test";
        var name = Request.Headers["X-Dev-Name"].FirstOrDefault() ?? "Vishal Trivedi";
        var role = Request.Headers["X-Dev-Role"].FirstOrDefault() ?? "Employee";
        var claims = new[]
        {
            new Claim(ClaimTypes.Name, name),
            new Claim(ClaimTypes.Email, email),
            new Claim(ClaimTypes.Role, role),
            new Claim("preferred_username", email)
        };
        var identity = new ClaimsIdentity(claims, Scheme.Name);
        return Task.FromResult(AuthenticateResult.Success(new AuthenticationTicket(new ClaimsPrincipal(identity), Scheme.Name)));
    }
}
