using System.Security.Claims;
using EmployeeReferral.Api.Data;
using EmployeeReferral.Api.Models;
using Microsoft.EntityFrameworkCore;

namespace EmployeeReferral.Api.Services;

public interface ICurrentUserService
{
    string Email { get; }
    string DisplayName { get; }
    string? ObjectId { get; }
    IReadOnlyCollection<string> TokenRoles { get; }
    Task<User> GetOrCreateAsync(CancellationToken cancellationToken = default);
    Task<bool> IsInRoleAsync(string role, CancellationToken cancellationToken = default);
}

public sealed class CurrentUserService(IHttpContextAccessor accessor, AppDbContext db) : ICurrentUserService
{
    private ClaimsPrincipal Principal => accessor.HttpContext?.User ?? throw new UnauthorizedAccessException();
    public string Email => Principal.FindFirstValue(ClaimTypes.Email) ?? "vishal@local.test";
    public string DisplayName => Principal.FindFirstValue(ClaimTypes.Name) ?? Email;
    public string? ObjectId => null;
    public IReadOnlyCollection<string> TokenRoles => Principal.FindAll(ClaimTypes.Role).Select(x => x.Value).ToArray();

    public async Task<User> GetOrCreateAsync(CancellationToken cancellationToken = default)
    {
        var role = TokenRoles.FirstOrDefault() ?? "Employee";
        var user = await db.Users.FirstOrDefaultAsync(x => x.Email == Email, cancellationToken);
        if (user is null)
        {
            user = new User { FullName = DisplayName, Email = Email, Role = role, IsActive = true };
            db.Users.Add(user);
        }
        else
        {
            user.FullName = DisplayName;
            user.Role = role;
        }
        await db.SaveChangesAsync(cancellationToken);
        return user;
    }

    public async Task<bool> IsInRoleAsync(string role, CancellationToken cancellationToken = default)
        => TokenRoles.Any(x => x.Equals(role, StringComparison.OrdinalIgnoreCase)) ||
           (await db.Users.AsNoTracking().FirstOrDefaultAsync(x => x.Email == Email, cancellationToken))?.Role.Equals(role, StringComparison.OrdinalIgnoreCase) == true;
}
