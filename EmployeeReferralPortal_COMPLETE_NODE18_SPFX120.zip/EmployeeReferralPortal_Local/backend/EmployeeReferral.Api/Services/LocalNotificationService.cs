using EmployeeReferral.Api.Data;
using EmployeeReferral.Api.Models;
using Microsoft.EntityFrameworkCore;

namespace EmployeeReferral.Api.Services;

public sealed record NotificationRecipient(string Email, string Name);
public interface INotificationService
{
    Task SendAsync(string eventType, IEnumerable<NotificationRecipient> recipients, string subject, string htmlBody, string? entityType = null, int? entityId = null, CancellationToken ct = default);
}

public sealed class LocalNotificationService(AppDbContext db) : INotificationService
{
    public async Task SendAsync(string eventType, IEnumerable<NotificationRecipient> recipients, string subject, string htmlBody, string? entityType = null, int? entityId = null, CancellationToken ct = default)
    {
        var list = recipients.Where(x => !string.IsNullOrWhiteSpace(x.Email)).ToList();
        db.NotificationLogs.Add(new NotificationLog
        {
            EventType = eventType,
            EntityType = entityType,
            EntityId = entityId,
            Recipients = string.Join(';', list.Select(x => x.Email)),
            Subject = subject,
            Status = "LocalQueued",
            ErrorMessage = "Local mode: email is recorded in SQL NotificationLogs and not sent externally."
        });
        await db.SaveChangesAsync(ct);
        var dir = Path.Combine(AppContext.BaseDirectory, "local-mailbox");
        Directory.CreateDirectory(dir);
        var file = Path.Combine(dir, $"{DateTime.UtcNow:yyyyMMddHHmmssfff}_{Guid.NewGuid():N}.html");
        await File.WriteAllTextAsync(file, $"<h2>{System.Net.WebUtility.HtmlEncode(subject)}</h2><p><b>To:</b> {System.Net.WebUtility.HtmlEncode(string.Join(", ", list.Select(x => x.Email)))}</p>{htmlBody}", ct);
    }
}
