using EmployeeReferral.Api.Data;
using Microsoft.EntityFrameworkCore;

namespace EmployeeReferral.Api.Services;

public static class Permissions
{
    public const string JobCreate="Job.Create", JobEdit="Job.Edit", JobDelete="Job.Delete", JobApprove="Job.Approve";
    public const string ReferralCreate="Referral.Create", ReferralViewAll="Referral.ViewAll", ReferralEdit="Referral.Edit", ReferralDelete="Referral.Delete", ReferralStatus="Referral.StatusUpdate";
    public const string InterviewSchedule="Interview.Schedule", InterviewFeedback="Interview.Feedback", ReferralFinalApprove="Referral.FinalApprove";
    public const string ResumeUpload="Resume.Upload", ResumeView="Resume.View";
    public const string UserManage="User.Manage", RoleManage="Role.Manage", AuditView="Audit.View";
}

public interface IPermissionService
{
    Task<bool> HasAsync(string permission, CancellationToken ct=default);
    Task<IReadOnlyList<string>> GetMineAsync(CancellationToken ct=default);
}

public sealed class PermissionService(ICurrentUserService currentUser, AppDbContext db) : IPermissionService
{
    public async Task<bool> HasAsync(string permission, CancellationToken ct=default)
    {
        var user=await currentUser.GetOrCreateAsync(ct);
        if (!user.IsActive) return false;
        if (user.Role.Equals("Admin", StringComparison.OrdinalIgnoreCase)) return true;
        return await db.RolePermissions.AsNoTracking().AnyAsync(x=>x.Role==user.Role && x.Permission==permission && x.IsAllowed,ct);
    }
    public async Task<IReadOnlyList<string>> GetMineAsync(CancellationToken ct=default)
    {
        var user=await currentUser.GetOrCreateAsync(ct);
        if(user.Role.Equals("Admin",StringComparison.OrdinalIgnoreCase)) return new[] { "*" };
        return await db.RolePermissions.AsNoTracking().Where(x=>x.Role==user.Role && x.IsAllowed).OrderBy(x=>x.Permission).Select(x=>x.Permission).ToListAsync(ct);
    }
}
