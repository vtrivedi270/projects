# SPFx V9 - Run First

The previous V8 SPFx package had an incorrect Heft configuration. This package replaces it with the correct SPFx 1.23.2 Heft structure.

## Exact commands

```powershell
cd spfx\employee-referral-portal
npm install
npm run build
$env:SPFX_SERVE_TENANT_DOMAIN = "YOURTENANT.sharepoint.com"
npm start
```

If you only want to verify compilation/package creation, stop after `npm run build`.

## Expected package

```text
spfx\employee-referral-portal\sharepoint\solution\employee-referral-portal.sppkg
```

## Why V8 failed

The old package mixed the SPFx 1.22+ Heft toolchain with the legacy `@microsoft/sp-build-web` configuration and was missing the required root `tsconfig.json` and Heft TypeScript configuration. Microsoft documents that SPFx 1.22+ uses Heft and the `@microsoft/spfx-web-build-rig`, with a minimal `tsconfig.json`, `config/rig.json`, and `config/typescript.json`.

This V9 package corrects those files.
