/* ============================================================
   Application Hub — SQL Server schema
   Metadata-driven engine: all 50 applications share this schema
   and are distinguished by configuration rows, not per-app tables.
   ============================================================ */

CREATE TABLE Roles (
    Id              INT IDENTITY PRIMARY KEY,
    Name            NVARCHAR(100)   NOT NULL,
    ParentRoleId    INT             NULL REFERENCES Roles(Id),
    Level           DECIMAL(4,1)    NOT NULL,          -- 1..6 in the fixed chain; decimals for custom roles
    IsCustom        BIT             NOT NULL DEFAULT 0,
    IsFlat          BIT             NOT NULL DEFAULT 0, -- standalone role, not in the linear chain
    CreatedOn       DATETIME2       NOT NULL DEFAULT SYSUTCDATETIME()
);

CREATE TABLE Users (
    Id              INT IDENTITY PRIMARY KEY,
    AzureAdObjectId UNIQUEIDENTIFIER NULL,
    FullName        NVARCHAR(150)   NOT NULL,
    Email           NVARCHAR(200)   NOT NULL UNIQUE,
    RoleId          INT             NOT NULL REFERENCES Roles(Id),
    ManagerId       INT             NULL REFERENCES Users(Id),
    DepartmentId    INT             NULL,
    DivisionId      INT             NULL,
    IsActive        BIT             NOT NULL DEFAULT 1
);

CREATE TABLE Applications (
    Id                      INT IDENTITY PRIMARY KEY,
    Name                    NVARCHAR(150)   NOT NULL,
    Category                NVARCHAR(50)    NOT NULL,   -- HR / Finance / IT / Admin
    IconKey                 NVARCHAR(50)    NOT NULL DEFAULT 'file',
    SharePointLibraryName   NVARCHAR(150)   NOT NULL,   -- dedicated attachment library per app
    CurrentFormVersion      INT             NOT NULL DEFAULT 1,
    CurrentWorkflowVersion  INT             NOT NULL DEFAULT 1,
    IsActive                BIT             NOT NULL DEFAULT 1,
    CreatedOn               DATETIME2       NOT NULL DEFAULT SYSUTCDATETIME(),
    CreatedById             INT             NULL REFERENCES Users(Id)
);

CREATE TABLE FormDefinitions (
    Id              INT IDENTITY PRIMARY KEY,
    ApplicationId   INT         NOT NULL REFERENCES Applications(Id),
    Version         INT         NOT NULL,
    IsActive        BIT         NOT NULL DEFAULT 1,
    CreatedOn       DATETIME2   NOT NULL DEFAULT SYSUTCDATETIME(),
    CONSTRAINT UQ_Form_App_Version UNIQUE (ApplicationId, Version)
);

CREATE TABLE FormFields (
    Id                  INT IDENTITY PRIMARY KEY,
    FormDefinitionId    INT             NOT NULL REFERENCES FormDefinitions(Id),
    ControlType         NVARCHAR(30)    NOT NULL,   -- Text, TextArea, Dropdown, Date, Checkbox, Radio, Number, FileUpload, UserPicker, Toggle, Table, Divider
    Label               NVARCHAR(150)   NOT NULL,
    BindTo              NVARCHAR(100)   NULL,        -- e.g. CurrentUser.FullName, or a custom field key
    IsRequired          BIT             NOT NULL DEFAULT 0,
    IsReadOnly          BIT             NOT NULL DEFAULT 0,
    VisibleToRoles      NVARCHAR(300)   NULL,        -- comma separated role names, NULL = all
    ColumnWidth         NVARCHAR(10)    NOT NULL DEFAULT 'Half',  -- Half / Full
    SortOrder           INT             NOT NULL,
    OptionsJson         NVARCHAR(MAX)   NULL         -- Dropdown/Radio: JSON array of options
);

CREATE TABLE WorkflowDefinitions (
    Id              INT IDENTITY PRIMARY KEY,
    ApplicationId   INT         NOT NULL REFERENCES Applications(Id),
    Version         INT         NOT NULL,
    IsActive        BIT         NOT NULL DEFAULT 1,
    CreatedOn       DATETIME2   NOT NULL DEFAULT SYSUTCDATETIME(),
    CONSTRAINT UQ_Workflow_App_Version UNIQUE (ApplicationId, Version)
);

CREATE TABLE WorkflowStages (
    Id                      INT IDENTITY PRIMARY KEY,
    WorkflowDefinitionId    INT             NOT NULL REFERENCES WorkflowDefinitions(Id),
    SortOrder               INT             NOT NULL,
    StageName                NVARCHAR(150)   NOT NULL,
    ApproverRoleId            INT             NOT NULL REFERENCES Roles(Id),
    CompletionRule            NVARCHAR(20)    NOT NULL DEFAULT 'AnyOne',  -- All / AnyOne / Majority
    SlaHours                  INT             NULL,
    AllowAmend                BIT             NOT NULL DEFAULT 0,
    AmendTargetStageId         INT             NULL REFERENCES WorkflowStages(Id),
    ParallelGroup              INT             NULL      -- stages sharing a group number run in parallel
);

CREATE TABLE Requests (
    Id                      INT IDENTITY PRIMARY KEY,
    ApplicationId           INT             NOT NULL REFERENCES Applications(Id),
    RequestNumber           NVARCHAR(30)    NOT NULL UNIQUE,   -- e.g. LR-2026-00842
    RequesterId             INT             NOT NULL REFERENCES Users(Id),
    WorkflowDefinitionId    INT             NOT NULL REFERENCES WorkflowDefinitions(Id),
    FormDefinitionId        INT             NOT NULL REFERENCES FormDefinitions(Id),
    FormDataJson            NVARCHAR(MAX)   NOT NULL,   -- captured field values
    Status                  NVARCHAR(20)    NOT NULL DEFAULT 'InProgress', -- Draft/InProgress/Approved/Rejected/Returned
    CurrentStageId          INT             NULL REFERENCES WorkflowStages(Id),
    CreatedOn               DATETIME2       NOT NULL DEFAULT SYSUTCDATETIME(),
    ModifiedOn              DATETIME2       NULL
);

CREATE TABLE RequestApprovals (
    Id               INT             IDENTITY PRIMARY KEY,
    RequestId        INT             NOT NULL REFERENCES Requests(Id),
    StageId          INT             NOT NULL REFERENCES WorkflowStages(Id),
    ApproverId       INT             NOT NULL REFERENCES Users(Id),
    Action           NVARCHAR(20)    NOT NULL,   -- Approved / Rejected / Returned
    Comment          NVARCHAR(500)   NULL,
    ActionedOn       DATETIME2       NOT NULL DEFAULT SYSUTCDATETIME(),
    OnBehalfOfUserId INT             NULL REFERENCES Users(Id)   -- set when acted via Delegation
);

CREATE TABLE Attachments (
    Id              INT IDENTITY PRIMARY KEY,
    RequestId       INT             NOT NULL REFERENCES Requests(Id),
    FileName        NVARCHAR(260)   NOT NULL,
    SharePointUrl   NVARCHAR(1000)  NOT NULL,
    SizeBytes       BIGINT          NOT NULL,
    UploadedById    INT             NOT NULL REFERENCES Users(Id),
    UploadedOn      DATETIME2       NOT NULL DEFAULT SYSUTCDATETIME()
);

CREATE TABLE RequestHistory (
    Id              INT IDENTITY PRIMARY KEY,
    RequestId       INT             NOT NULL REFERENCES Requests(Id),
    Action          NVARCHAR(200)   NOT NULL,
    Details         NVARCHAR(1000)  NULL,
    PerformedById   INT             NOT NULL REFERENCES Users(Id),
    PerformedOn     DATETIME2       NOT NULL DEFAULT SYSUTCDATETIME()
);

CREATE TABLE Delegations (
    Id                  INT IDENTITY PRIMARY KEY,
    DelegatorId         INT             NOT NULL REFERENCES Users(Id),
    DelegateId          INT             NOT NULL REFERENCES Users(Id),
    ApplicationIdsCsv   NVARCHAR(500)   NOT NULL,  -- 'ALL' or comma separated Application.Id list
    DelegationType      NVARCHAR(20)    NOT NULL,   -- TimeBound / Permanent
    StartDate           DATE            NULL,
    EndDate             DATE            NULL,
    IsActive            BIT             NOT NULL DEFAULT 1,
    CreatedOn           DATETIME2       NOT NULL DEFAULT SYSUTCDATETIME()
);

CREATE TABLE Permissions (
    Id              INT IDENTITY PRIMARY KEY,
    RoleId          INT             NOT NULL REFERENCES Roles(Id),
    ApplicationId   INT             NOT NULL REFERENCES Applications(Id),
    CanCreate       BIT             NOT NULL DEFAULT 0,
    CanRead         BIT             NOT NULL DEFAULT 0,
    CanUpdate       BIT             NOT NULL DEFAULT 0,
    CanDelete       BIT             NOT NULL DEFAULT 0,
    CanApprove      BIT             NOT NULL DEFAULT 0,
    DataScope       NVARCHAR(20)    NOT NULL DEFAULT 'Own',  -- Own/Team/Department/Division/All
    CONSTRAINT UQ_Permissions UNIQUE (RoleId, ApplicationId)
);

CREATE TABLE MakerCheckerQueue (
    Id              INT IDENTITY PRIMARY KEY,
    EntityName      NVARCHAR(100)   NOT NULL,
    EntityId        INT             NULL,
    ChangeJson      NVARCHAR(MAX)   NOT NULL,
    RequestedById   INT             NOT NULL REFERENCES Users(Id),
    Status          NVARCHAR(20)    NOT NULL DEFAULT 'Pending',  -- Pending/Approved/Rejected
    ReviewedById    INT             NULL REFERENCES Users(Id),
    CreatedOn       DATETIME2       NOT NULL DEFAULT SYSUTCDATETIME(),
    ReviewedOn      DATETIME2       NULL
);

CREATE INDEX IX_Requests_App_Status ON Requests(ApplicationId, Status);
CREATE INDEX IX_Requests_Requester ON Requests(RequesterId);
CREATE INDEX IX_RequestApprovals_Request ON RequestApprovals(RequestId);
CREATE INDEX IX_Attachments_Request ON Attachments(RequestId);
CREATE INDEX IX_RequestHistory_Request ON RequestHistory(RequestId);

/* ================= Seed data ================= */

INSERT INTO Roles (Name, ParentRoleId, Level, IsCustom, IsFlat) VALUES
 ('Super Admin', NULL, 1, 0, 0),
 ('Admin',       NULL, 2, 0, 0),
 ('Division Head', NULL, 3, 0, 0),
 ('Department Head', NULL, 4, 0, 0),
 ('Reporting Manager', NULL, 5, 0, 0),
 ('Employee', NULL, 6, 0, 0),
 ('Finance Controller', NULL, 3.5, 1, 0),
 ('IT Asset Custodian', NULL, 4.5, 1, 1),
 ('Auditor (read-only)', NULL, 4.5, 1, 1);

INSERT INTO Users (FullName, Email, RoleId, ManagerId) VALUES
 ('Vishal P.', 'vishal@spenterprise.com', 1, NULL),
 ('Anil Shah', 'anil.shah@spenterprise.com', 5, NULL),
 ('Priya Sharma', 'priya.sharma@spenterprise.com', 6, 2),
 ('Rahul Mehta', 'rahul.mehta@spenterprise.com', 6, 2);

INSERT INTO Applications (Name, Category, IconKey, SharePointLibraryName) VALUES
 ('Leave Request', 'HR', 'calendar', 'LeaveRequestAttachments'),
 ('Expense Reimbursement', 'Finance', 'file', 'ExpenseReimbursementAttachments'),
 ('Asset Request', 'IT', 'layers', 'AssetRequestAttachments');
 -- The remaining 47 applications are created the same way via App Builder → Manage Applications;
 -- no schema change is needed per app.

DECLARE @LeaveAppId INT = (SELECT Id FROM Applications WHERE Name = 'Leave Request');

INSERT INTO FormDefinitions (ApplicationId, Version, IsActive) VALUES (@LeaveAppId, 1, 1);
DECLARE @LeaveFormId INT = SCOPE_IDENTITY();

INSERT INTO FormFields (FormDefinitionId, ControlType, Label, BindTo, IsRequired, IsReadOnly, ColumnWidth, SortOrder, OptionsJson) VALUES
 (@LeaveFormId, 'Text',       'Employee Name',    'CurrentUser.FullName', 1, 1, 'Half', 1, NULL),
 (@LeaveFormId, 'Dropdown',   'Leave Type',       'LeaveType',             1, 0, 'Half', 2, '["Privilege Leave","Sick Leave","Casual Leave","Work From Home"]'),
 (@LeaveFormId, 'Date',       'From Date',        'FromDate',              1, 0, 'Half', 3, NULL),
 (@LeaveFormId, 'Date',       'To Date',          'ToDate',                1, 0, 'Half', 4, NULL),
 (@LeaveFormId, 'Radio',      'Half Day',         'HalfDay',               0, 0, 'Full', 5, '["No","First Half","Second Half"]'),
 (@LeaveFormId, 'TextArea',   'Reason for Leave', 'Reason',                1, 0, 'Full', 6, NULL),
 (@LeaveFormId, 'UserPicker', 'Delegate Work To', 'DelegateUserId',        0, 0, 'Half', 7, NULL);

INSERT INTO WorkflowDefinitions (ApplicationId, Version, IsActive) VALUES (@LeaveAppId, 1, 1);
DECLARE @LeaveWfId INT = SCOPE_IDENTITY();

INSERT INTO WorkflowStages (WorkflowDefinitionId, SortOrder, StageName, ApproverRoleId, CompletionRule, SlaHours, AllowAmend) VALUES
 (@LeaveWfId, 1, 'Reporting Manager Approval', 5, 'AnyOne', 48, 1),
 (@LeaveWfId, 2, 'Department Head Review',     4, 'AnyOne', 48, 1),
 (@LeaveWfId, 3, 'HR Compliance Check',        2, 'All',    24, 0);

INSERT INTO Permissions (RoleId, ApplicationId, CanCreate, CanRead, CanUpdate, CanDelete, CanApprove, DataScope) VALUES
 (6, @LeaveAppId, 1, 1, 1, 0, 0, 'Own'),
 (5, @LeaveAppId, 0, 1, 0, 0, 1, 'Team'),
 (4, @LeaveAppId, 0, 1, 0, 0, 1, 'Department');
