using ApplicationHub.Application.Applications.Commands;
using ApplicationHub.Application.Applications.Queries;
using MediatR;
using Microsoft.AspNetCore.Mvc;

namespace ApplicationHub.Api.Controllers;

[ApiController]
[Route("api/applications")]
public class ApplicationsController : ControllerBase
{
    private readonly ISender _mediator;
    public ApplicationsController(ISender mediator) => _mediator = mediator;

    /// GET /api/applications — Main Dashboard tile grid, with per-tile pending-approval badge
    [HttpGet]
    public async Task<IActionResult> GetAll([FromQuery] int currentUserId) =>
        Ok(await _mediator.Send(new GetApplicationsQuery(currentUserId)));

    [HttpGet("{id:int}")]
    public async Task<IActionResult> GetById(int id) =>
        Ok(await _mediator.Send(new GetApplicationByIdQuery(id)));

    /// POST /api/applications — Admin ▸ Manage Applications ▸ New Application
    [HttpPost]
    public async Task<IActionResult> Create([FromBody] CreateApplicationCommand cmd) =>
        Ok(await _mediator.Send(cmd));

    /// POST /api/applications/{id}/clone — Admin ▸ Manage Applications ▸ Clone
    [HttpPost("{id:int}/clone")]
    public async Task<IActionResult> Clone(int id, [FromBody] string newName) =>
        Ok(await _mediator.Send(new CloneApplicationCommand(id, newName)));
}
