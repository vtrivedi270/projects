using ApplicationHub.Application.Attachments.Commands;
using MediatR;
using Microsoft.AspNetCore.Mvc;

namespace ApplicationHub.Api.Controllers;

[ApiController]
[Route("api/requests/{requestId:int}/attachments")]
public class AttachmentsController : ControllerBase
{
    private readonly ISender _mediator;
    public AttachmentsController(ISender mediator) => _mediator = mediator;

    /// POST — multipart upload, stored to the application's dedicated SharePoint library
    [HttpPost]
    [RequestSizeLimit(25_000_000)]
    public async Task<IActionResult> Upload(int requestId, [FromForm] int uploadedById, [FromForm] IFormFile file)
    {
        await using var stream = file.OpenReadStream();
        var id = await _mediator.Send(new UploadAttachmentCommand(requestId, uploadedById, file.FileName, stream));
        return Ok(new { attachmentId = id });
    }
}
