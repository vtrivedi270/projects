using ApplicationHub.Application.Requests.Commands;
using ApplicationHub.Application.Requests.Queries;
using ApplicationHub.Domain.Enums;
using MediatR;
using Microsoft.AspNetCore.Mvc;

namespace ApplicationHub.Api.Controllers;

[ApiController]
[Route("api/requests")]
public class RequestsController : ControllerBase
{
    private readonly ISender _mediator;
    public RequestsController(ISender mediator) => _mediator = mediator;

    /// POST /api/requests — submit a new request against an application's active form + workflow
    [HttpPost]
    public async Task<IActionResult> Submit([FromBody] SubmitRequestCommand cmd) =>
        Ok(await _mediator.Send(cmd));

    /// GET /api/requests/mine — "My Requests" tab
    [HttpGet("mine")]
    public async Task<IActionResult> Mine([FromQuery] int userId, [FromQuery] int? applicationId,
        [FromQuery] int page = 1, [FromQuery] int pageSize = 20) =>
        Ok(await _mediator.Send(new GetMyRequestsQuery(userId, applicationId, page, pageSize)));

    /// GET /api/requests/pending-my-approval — "My Approvals" tab
    [HttpGet("pending-my-approval")]
    public async Task<IActionResult> PendingMyApproval([FromQuery] int userId, [FromQuery] decimal roleLevel,
        [FromQuery] int? applicationId, [FromQuery] int page = 1, [FromQuery] int pageSize = 20) =>
        Ok(await _mediator.Send(new GetMyApprovalsQuery(userId, roleLevel, Array.Empty<int>(), applicationId, page, pageSize)));

    /// GET /api/requests?applicationId= — "All Requests" tab (data-scope filtering applied upstream)
    [HttpGet]
    public async Task<IActionResult> All([FromQuery] int applicationId, [FromQuery] int page = 1, [FromQuery] int pageSize = 20) =>
        Ok(await _mediator.Send(new GetAllRequestsQuery(applicationId, Array.Empty<int>(), page, pageSize)));

    /// GET /api/requests/{id} — record detail: Entry Form / Attachment / History / Workflow tabs
    [HttpGet("{id:int}")]
    public async Task<IActionResult> Detail(int id) =>
        Ok(await _mediator.Send(new GetRequestDetailQuery(id)));

    /// POST /api/requests/{id}/approve | reject | return
    [HttpPost("{id:int}/approve")]
    public Task<IActionResult> Approve(int id, [FromBody] ActOnRequestBody body) =>
        Act(id, ApprovalAction.Approved, body);

    [HttpPost("{id:int}/reject")]
    public Task<IActionResult> Reject(int id, [FromBody] ActOnRequestBody body) =>
        Act(id, ApprovalAction.Rejected, body);

    [HttpPost("{id:int}/return")]
    public Task<IActionResult> Return(int id, [FromBody] ActOnRequestBody body) =>
        Act(id, ApprovalAction.Returned, body);

    private async Task<IActionResult> Act(int id, ApprovalAction action, ActOnRequestBody body)
    {
        await _mediator.Send(new ActOnRequestCommand(id, body.ApproverId, action, body.Comment, body.OnBehalfOfUserId));
        return NoContent();
    }
}

public record ActOnRequestBody(int ApproverId, string? Comment, int? OnBehalfOfUserId);
