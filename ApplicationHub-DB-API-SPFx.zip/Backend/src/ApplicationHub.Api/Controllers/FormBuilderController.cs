using ApplicationHub.Application.Common.Models;
using ApplicationHub.Application.FormBuilder.Commands;
using ApplicationHub.Application.FormBuilder.Queries;
using MediatR;
using Microsoft.AspNetCore.Mvc;

namespace ApplicationHub.Api.Controllers;

[ApiController]
[Route("api/applications/{applicationId:int}/form")]
public class FormBuilderController : ControllerBase
{
    private readonly ISender _mediator;
    public FormBuilderController(ISender mediator) => _mediator = mediator;

    /// GET — loads the current form definition into the Form Builder canvas / into FormRenderer
    [HttpGet]
    public async Task<IActionResult> Get(int applicationId) =>
        Ok(await _mediator.Send(new GetFormDefinitionQuery(applicationId)));

    /// PUT — Admin ▸ Form Builder ▸ Save Form (creates a new immutable version)
    [HttpPut]
    public async Task<IActionResult> Save(int applicationId, [FromBody] IReadOnlyList<FormFieldDto> fields) =>
        Ok(await _mediator.Send(new SaveFormDefinitionCommand(applicationId, fields)));
}
