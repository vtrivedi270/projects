using ApplicationHub.Application.Common.Models;
using ApplicationHub.Application.Reports.Queries;
using MediatR;
using Microsoft.AspNetCore.Mvc;

namespace ApplicationHub.Api.Controllers;

[ApiController]
[Route("api/reports")]
public class ReportsController : ControllerBase
{
    private readonly ISender _mediator;
    public ReportsController(ISender mediator) => _mediator = mediator;

    [HttpPost("generate")]
    public async Task<IActionResult> Generate([FromBody] ReportRequestDto filter) =>
        Ok(await _mediator.Send(new GenerateReportQuery(filter)));
}
