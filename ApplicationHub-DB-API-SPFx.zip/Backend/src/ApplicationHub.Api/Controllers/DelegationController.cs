using ApplicationHub.Application.Delegation.Commands;
using ApplicationHub.Application.Delegation.Queries;
using MediatR;
using Microsoft.AspNetCore.Mvc;

namespace ApplicationHub.Api.Controllers;

[ApiController]
[Route("api/delegations")]
public class DelegationController : ControllerBase
{
    private readonly ISender _mediator;
    public DelegationController(ISender mediator) => _mediator = mediator;

    [HttpGet]
    public async Task<IActionResult> GetAll() => Ok(await _mediator.Send(new GetDelegationsQuery()));

    [HttpPost]
    public async Task<IActionResult> Create([FromBody] CreateDelegationCommand cmd) =>
        Ok(await _mediator.Send(cmd));
}
