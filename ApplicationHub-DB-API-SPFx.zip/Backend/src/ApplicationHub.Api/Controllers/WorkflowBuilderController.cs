using ApplicationHub.Application.Common.Models;
using ApplicationHub.Application.WorkflowBuilder.Commands;
using ApplicationHub.Application.WorkflowBuilder.Queries;
using MediatR;
using Microsoft.AspNetCore.Mvc;

namespace ApplicationHub.Api.Controllers;

[ApiController]
[Route("api/applications/{applicationId:int}/workflow")]
public class WorkflowBuilderController : ControllerBase
{
    private readonly ISender _mediator;
    public WorkflowBuilderController(ISender mediator) => _mediator = mediator;

    /// GET — loads the active workflow into the Workflow Builder canvas / progress tracker
    [HttpGet]
    public async Task<IActionResult> Get(int applicationId) =>
        Ok(await _mediator.Send(new GetWorkflowDefinitionQuery(applicationId)));

    /// PUT — Admin ▸ Workflow Builder ▸ Publish Version
    [HttpPut]
    public async Task<IActionResult> Save(int applicationId, [FromBody] IReadOnlyList<WorkflowStageDto> stages) =>
        Ok(await _mediator.Send(new SaveWorkflowDefinitionCommand(applicationId, stages)));
}
