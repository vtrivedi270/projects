using ApplicationHub.Application.Common.Models;
using ApplicationHub.Application.Roles.Commands;
using ApplicationHub.Application.Roles.Queries;
using MediatR;
using Microsoft.AspNetCore.Mvc;

namespace ApplicationHub.Api.Controllers;

[ApiController]
[Route("api/roles")]
public class RolesController : ControllerBase
{
    private readonly ISender _mediator;
    public RolesController(ISender mediator) => _mediator = mediator;

    /// GET — the Division Head → Department Head → Reporting Manager → Employee hierarchy, plus custom roles
    [HttpGet]
    public async Task<IActionResult> GetHierarchy() => Ok(await _mediator.Send(new GetRoleHierarchyQuery()));

    /// PUT /api/roles/{roleId}/permissions — save the module permission matrix for one role
    [HttpPut("{roleId:int}/permissions")]
    public async Task<IActionResult> SavePermissions(int roleId, [FromBody] IReadOnlyList<PermissionMatrixRowDto> rows)
    {
        await _mediator.Send(new UpsertPermissionMatrixCommand(roleId, rows));
        return NoContent();
    }
}
