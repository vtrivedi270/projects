using ApplicationHub.Application.Common.Interfaces;
using ApplicationHub.Infrastructure.Persistence;
using MediatR;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

builder.Services.AddDbContext<ApplicationHubDbContext>(opt =>
    opt.UseSqlServer(builder.Configuration.GetConnectionString("ApplicationHub")));
builder.Services.AddScoped<IApplicationHubDbContext>(sp => sp.GetRequiredService<ApplicationHubDbContext>());

builder.Services.AddMediatR(cfg =>
    cfg.RegisterServicesFromAssembly(typeof(ApplicationHub.Application.Common.Models.ApplicationDto).Assembly));

// Registered in Infrastructure: ICurrentUserService (Azure AD claims), ISharePointAttachmentService (Graph),
// INotificationService (Email + Teams) — see Infrastructure/DependencyInjection.cs in the full solution.

builder.Services.AddCors(o => o.AddPolicy("SharePoint", p => p
    .WithOrigins(builder.Configuration["SharePointOrigin"] ?? "https://*.sharepoint.com")
    .SetIsOriginAllowedToAllowWildcardSubdomains()
    .AllowAnyHeader().AllowAnyMethod()));

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();
app.UseCors("SharePoint");
app.UseAuthentication();
app.UseAuthorization();
app.MapControllers();
app.Run();
