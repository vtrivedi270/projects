namespace ApplicationHub.Domain.Enums;

public enum ControlType
{
    Text, TextArea, Dropdown, Date, Checkbox, Radio, Number, FileUpload, UserPicker, Toggle, Table, Divider
}

public enum ColumnWidth { Half, Full }

public enum CompletionRule { All, AnyOne, Majority }

public enum RequestStatus { Draft, InProgress, Approved, Rejected, Returned }

public enum ApprovalAction { Approved, Rejected, Returned }

public enum DelegationType { TimeBound, Permanent }

public enum DataScope { Own, Team, Department, Division, All }

public enum MakerCheckerStatus { Pending, Approved, Rejected }
