namespace ApplicationHub.Domain.Entities;

public class WorkflowDefinition : Common.BaseEntity
{
    public int ApplicationId { get; set; }
    public Application Application { get; set; } = default!;
    public int Version { get; set; }
    public bool IsActive { get; set; } = true;

    public ICollection<WorkflowStage> Stages { get; set; } = new List<WorkflowStage>();
}
