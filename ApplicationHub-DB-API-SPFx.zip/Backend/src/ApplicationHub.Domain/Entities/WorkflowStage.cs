using ApplicationHub.Domain.Enums;

namespace ApplicationHub.Domain.Entities;

public class WorkflowStage : Common.BaseEntity
{
    public int WorkflowDefinitionId { get; set; }
    public WorkflowDefinition WorkflowDefinition { get; set; } = default!;
    public int SortOrder { get; set; }
    public string StageName { get; set; } = default!;
    public int ApproverRoleId { get; set; }
    public Role ApproverRole { get; set; } = default!;
    public CompletionRule CompletionRule { get; set; } = CompletionRule.AnyOne;
    public int? SlaHours { get; set; }
    public bool AllowAmend { get; set; }
    public int? AmendTargetStageId { get; set; }
    public int? ParallelGroup { get; set; }        // stages sharing a group number run concurrently
}
