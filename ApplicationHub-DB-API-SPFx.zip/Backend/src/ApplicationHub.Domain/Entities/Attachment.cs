namespace ApplicationHub.Domain.Entities;

public class Attachment : Common.BaseEntity
{
    public int RequestId { get; set; }
    public Request Request { get; set; } = default!;
    public string FileName { get; set; } = default!;
    public string SharePointUrl { get; set; } = default!;   // library named per Application.SharePointLibraryName
    public long SizeBytes { get; set; }
    public int UploadedById { get; set; }
    public User UploadedBy { get; set; } = default!;
    public DateTime UploadedOn { get; set; } = DateTime.UtcNow;
}
