namespace ApplicationHub.Domain.Entities;

public class User : Common.BaseEntity
{
    public Guid? AzureAdObjectId { get; set; }
    public string FullName { get; set; } = default!;
    public string Email { get; set; } = default!;
    public int RoleId { get; set; }
    public Role Role { get; set; } = default!;
    public int? ManagerId { get; set; }
    public User? Manager { get; set; }
    public int? DepartmentId { get; set; }
    public int? DivisionId { get; set; }
    public bool IsActive { get; set; } = true;
}
