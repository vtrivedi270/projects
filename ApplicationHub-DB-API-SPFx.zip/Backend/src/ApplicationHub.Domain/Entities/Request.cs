using ApplicationHub.Domain.Enums;

namespace ApplicationHub.Domain.Entities;

public class Request : Common.BaseEntity
{
    public int ApplicationId { get; set; }
    public Application Application { get; set; } = default!;
    public string RequestNumber { get; set; } = default!;   // e.g. LR-2026-00842
    public int RequesterId { get; set; }
    public User Requester { get; set; } = default!;
    public int WorkflowDefinitionId { get; set; }
    public WorkflowDefinition WorkflowDefinition { get; set; } = default!;
    public int FormDefinitionId { get; set; }
    public FormDefinition FormDefinition { get; set; } = default!;
    public string FormDataJson { get; set; } = "{}";
    public RequestStatus Status { get; set; } = RequestStatus.InProgress;
    public int? CurrentStageId { get; set; }
    public WorkflowStage? CurrentStage { get; set; }

    public ICollection<RequestApproval> Approvals { get; set; } = new List<RequestApproval>();
    public ICollection<Attachment> Attachments { get; set; } = new List<Attachment>();
    public ICollection<RequestHistory> History { get; set; } = new List<RequestHistory>();
}
