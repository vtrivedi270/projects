using ApplicationHub.Domain.Enums;

namespace ApplicationHub.Domain.Entities;

public class FormField : Common.BaseEntity
{
    public int FormDefinitionId { get; set; }
    public FormDefinition FormDefinition { get; set; } = default!;
    public ControlType ControlType { get; set; }
    public string Label { get; set; } = default!;
    public string? BindTo { get; set; }
    public bool IsRequired { get; set; }
    public bool IsReadOnly { get; set; }
    public string? VisibleToRoles { get; set; }   // comma separated role names; null = all
    public ColumnWidth ColumnWidth { get; set; } = ColumnWidth.Half;
    public int SortOrder { get; set; }
    public string? OptionsJson { get; set; }       // Dropdown / Radio option list
}
