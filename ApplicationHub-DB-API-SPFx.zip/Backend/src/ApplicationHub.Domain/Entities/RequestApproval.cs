using ApplicationHub.Domain.Enums;

namespace ApplicationHub.Domain.Entities;

public class RequestApproval : Common.BaseEntity
{
    public int RequestId { get; set; }
    public Request Request { get; set; } = default!;
    public int StageId { get; set; }
    public WorkflowStage Stage { get; set; } = default!;
    public int ApproverId { get; set; }
    public User Approver { get; set; } = default!;
    public ApprovalAction Action { get; set; }
    public string? Comment { get; set; }
    public DateTime ActionedOn { get; set; } = DateTime.UtcNow;
    public int? OnBehalfOfUserId { get; set; }     // set when actioned via Delegation
}
