namespace ApplicationHub.Domain.Entities;

public class FormDefinition : Common.BaseEntity
{
    public int ApplicationId { get; set; }
    public Application Application { get; set; } = default!;
    public int Version { get; set; }
    public bool IsActive { get; set; } = true;

    public ICollection<FormField> Fields { get; set; } = new List<FormField>();
}
