namespace ApplicationHub.Domain.Entities;

/// <summary>
/// One row per configured application (of the 50). Everything specific to an
/// app — its fields and its workflow — lives in FormDefinition / WorkflowDefinition,
/// so adding application #51 never requires a schema or code change.
/// </summary>
public class Application : Common.BaseEntity
{
    public string Name { get; set; } = default!;
    public string Category { get; set; } = default!;
    public string IconKey { get; set; } = "file";
    public string SharePointLibraryName { get; set; } = default!;
    public int CurrentFormVersion { get; set; } = 1;
    public int CurrentWorkflowVersion { get; set; } = 1;
    public bool IsActive { get; set; } = true;

    public ICollection<FormDefinition> FormDefinitions { get; set; } = new List<FormDefinition>();
    public ICollection<WorkflowDefinition> WorkflowDefinitions { get; set; } = new List<WorkflowDefinition>();
    public ICollection<Permission> Permissions { get; set; } = new List<Permission>();
}
