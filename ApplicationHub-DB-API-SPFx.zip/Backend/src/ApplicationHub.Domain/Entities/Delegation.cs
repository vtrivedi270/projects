using ApplicationHub.Domain.Enums;

namespace ApplicationHub.Domain.Entities;

public class Delegation : Common.BaseEntity
{
    public int DelegatorId { get; set; }
    public User Delegator { get; set; } = default!;
    public int DelegateId { get; set; }
    public User Delegate { get; set; } = default!;
    public string ApplicationIdsCsv { get; set; } = "ALL";   // 'ALL' or comma-separated Application.Id
    public DelegationType DelegationType { get; set; }
    public DateOnly? StartDate { get; set; }
    public DateOnly? EndDate { get; set; }
    public bool IsActive { get; set; } = true;
}
