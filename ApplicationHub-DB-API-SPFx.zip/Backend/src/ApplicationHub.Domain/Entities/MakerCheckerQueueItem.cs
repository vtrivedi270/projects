using ApplicationHub.Domain.Enums;

namespace ApplicationHub.Domain.Entities;

public class MakerCheckerQueueItem : Common.BaseEntity
{
    public string EntityName { get; set; } = default!;
    public int? EntityId { get; set; }
    public string ChangeJson { get; set; } = default!;
    public int RequestedById { get; set; }
    public User RequestedBy { get; set; } = default!;
    public MakerCheckerStatus Status { get; set; } = MakerCheckerStatus.Pending;
    public int? ReviewedById { get; set; }
    public DateTime? ReviewedOn { get; set; }
}
