namespace ApplicationHub.Domain.Entities;

/// <summary>
/// Fixed chain: Super Admin(1) -> Admin(2) -> Division Head(3) -> Department Head(4)
/// -> Reporting Manager(5) -> Employee(6). Custom roles use a decimal Level (e.g. 3.5)
/// to slot into the chain, or IsFlat = true to sit outside it entirely.
/// </summary>
public class Role : Common.BaseEntity
{
    public string Name { get; set; } = default!;
    public int? ParentRoleId { get; set; }
    public Role? ParentRole { get; set; }
    public decimal Level { get; set; }
    public bool IsCustom { get; set; }
    public bool IsFlat { get; set; }

    public ICollection<Permission> Permissions { get; set; } = new List<Permission>();
}
