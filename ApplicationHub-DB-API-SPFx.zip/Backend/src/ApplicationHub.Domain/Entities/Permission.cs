using ApplicationHub.Domain.Enums;

namespace ApplicationHub.Domain.Entities;

public class Permission : Common.BaseEntity
{
    public int RoleId { get; set; }
    public Role Role { get; set; } = default!;
    public int ApplicationId { get; set; }
    public Application Application { get; set; } = default!;
    public bool CanCreate { get; set; }
    public bool CanRead { get; set; }
    public bool CanUpdate { get; set; }
    public bool CanDelete { get; set; }
    public bool CanApprove { get; set; }
    public DataScope DataScope { get; set; } = DataScope.Own;
}
