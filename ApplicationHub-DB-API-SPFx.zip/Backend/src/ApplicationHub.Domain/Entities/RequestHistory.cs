namespace ApplicationHub.Domain.Entities;

public class RequestHistory : Common.BaseEntity
{
    public int RequestId { get; set; }
    public Request Request { get; set; } = default!;
    public string Action { get; set; } = default!;
    public string? Details { get; set; }
    public int PerformedById { get; set; }
    public User PerformedBy { get; set; } = default!;
    public DateTime PerformedOn { get; set; } = DateTime.UtcNow;
}
