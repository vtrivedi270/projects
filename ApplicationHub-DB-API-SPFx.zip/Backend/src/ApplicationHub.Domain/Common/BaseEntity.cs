namespace ApplicationHub.Domain.Common;

public abstract class BaseEntity
{
    public int Id { get; set; }
    public DateTime CreatedOn { get; set; } = DateTime.UtcNow;
    public int? CreatedById { get; set; }
    public DateTime? ModifiedOn { get; set; }
    public int? ModifiedById { get; set; }
}
