using ApplicationHub.Application.Common.Interfaces;
using ApplicationHub.Domain.Enums;
using MediatR;

namespace ApplicationHub.Application.Delegation.Commands;

public record CreateDelegationCommand(int DelegatorId, int DelegateId, string ApplicationIdsCsv,
    DelegationType Type, DateOnly? StartDate, DateOnly? EndDate) : IRequest<int>;

public class CreateDelegationCommandHandler : IRequestHandler<CreateDelegationCommand, int>
{
    private readonly IApplicationHubDbContext _db;
    public CreateDelegationCommandHandler(IApplicationHubDbContext db) => _db = db;

    public async Task<int> Handle(CreateDelegationCommand cmd, CancellationToken ct)
    {
        var entity = new Domain.Entities.Delegation
        {
            DelegatorId = cmd.DelegatorId, DelegateId = cmd.DelegateId,
            ApplicationIdsCsv = cmd.ApplicationIdsCsv, DelegationType = cmd.Type,
            StartDate = cmd.StartDate, EndDate = cmd.EndDate, IsActive = true
        };
        _db.Delegations.Add(entity);
        await _db.SaveChangesAsync(ct);
        return entity.Id;
    }
}
