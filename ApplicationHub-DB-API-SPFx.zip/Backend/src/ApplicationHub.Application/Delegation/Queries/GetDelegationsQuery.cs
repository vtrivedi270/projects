using ApplicationHub.Application.Common.Interfaces;
using ApplicationHub.Application.Common.Models;
using Microsoft.EntityFrameworkCore;
using MediatR;

namespace ApplicationHub.Application.Delegation.Queries;

public record GetDelegationsQuery : IRequest<IReadOnlyList<DelegationDto>>;

public class GetDelegationsQueryHandler : IRequestHandler<GetDelegationsQuery, IReadOnlyList<DelegationDto>>
{
    private readonly IApplicationHubDbContext _db;
    public GetDelegationsQueryHandler(IApplicationHubDbContext db) => _db = db;

    public async Task<IReadOnlyList<DelegationDto>> Handle(GetDelegationsQuery q, CancellationToken ct)
    {
        return await _db.Delegations.Include(d => d.Delegator).Include(d => d.Delegate)
            .OrderByDescending(d => d.CreatedOn)
            .Select(d => new DelegationDto(d.Id, d.Delegator.FullName, d.Delegate.FullName,
                d.ApplicationIdsCsv == "ALL" ? "All applications" : d.ApplicationIdsCsv,
                d.DelegationType.ToString(), d.StartDate, d.EndDate, d.IsActive))
            .ToListAsync(ct);
    }
}
