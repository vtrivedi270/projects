namespace ApplicationHub.Application.Common.Interfaces;

public interface INotificationService
{
    Task SendEmailAsync(int userId, string subject, string body, CancellationToken ct = default);
    Task SendTeamsMessageAsync(int userId, string message, CancellationToken ct = default);
}
