using ApplicationHub.Domain.Entities;
using Microsoft.EntityFrameworkCore;

namespace ApplicationHub.Application.Common.Interfaces;

public interface IApplicationHubDbContext
{
    DbSet<Application> Applications { get; }
    DbSet<FormDefinition> FormDefinitions { get; }
    DbSet<FormField> FormFields { get; }
    DbSet<WorkflowDefinition> WorkflowDefinitions { get; }
    DbSet<WorkflowStage> WorkflowStages { get; }
    DbSet<Request> Requests { get; }
    DbSet<RequestApproval> RequestApprovals { get; }
    DbSet<Attachment> Attachments { get; }
    DbSet<RequestHistory> RequestHistory { get; }
    DbSet<Delegation> Delegations { get; }
    DbSet<Role> Roles { get; }
    DbSet<Permission> Permissions { get; }
    DbSet<User> Users { get; }
    DbSet<MakerCheckerQueueItem> MakerCheckerQueue { get; }

    Task<int> SaveChangesAsync(CancellationToken cancellationToken = default);
}
