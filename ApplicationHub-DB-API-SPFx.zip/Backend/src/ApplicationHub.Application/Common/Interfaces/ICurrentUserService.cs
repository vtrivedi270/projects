namespace ApplicationHub.Application.Common.Interfaces;

/// <summary>Resolved from the SPFx caller's Azure AD context on every API request.</summary>
public interface ICurrentUserService
{
    int UserId { get; }
    string Email { get; }
    decimal RoleLevel { get; }
    IReadOnlyList<int> ActiveDelegatedFromUserIds { get; }   // users who delegated to this caller, currently active
}
