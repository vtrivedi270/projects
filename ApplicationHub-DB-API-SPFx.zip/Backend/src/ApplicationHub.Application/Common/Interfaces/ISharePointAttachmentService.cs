namespace ApplicationHub.Application.Common.Interfaces;

/// <summary>Wraps Microsoft Graph calls to the per-application SharePoint document library.</summary>
public interface ISharePointAttachmentService
{
    Task<string> UploadAsync(string libraryName, string fileName, Stream content, CancellationToken ct = default);
    Task DeleteAsync(string libraryName, string sharePointUrl, CancellationToken ct = default);
}
