namespace ApplicationHub.Application.Common.Models;

public record ApplicationDto(int Id, string Name, string Category, string IconKey, bool IsActive, int PendingApprovalCount);

public record FormFieldDto(int Id, string ControlType, string Label, string? BindTo, bool IsRequired,
    bool IsReadOnly, string? VisibleToRoles, string ColumnWidth, int SortOrder, string? OptionsJson);

public record FormDefinitionDto(int ApplicationId, int Version, IReadOnlyList<FormFieldDto> Fields);

public record WorkflowStageDto(int Id, int SortOrder, string StageName, string ApproverRole,
    string CompletionRule, int? SlaHours, bool AllowAmend, int? AmendTargetStageId, int? ParallelGroup);

public record WorkflowDefinitionDto(int ApplicationId, int Version, IReadOnlyList<WorkflowStageDto> Stages);

public record RequestListItemDto(int Id, string RequestNumber, string ApplicationName, string RequesterName,
    DateTime CreatedOn, string Status, string? CurrentStageName);

public record RequestDetailDto(int Id, string RequestNumber, string ApplicationName, string Status,
    string FormDataJson, FormDefinitionDto Form, IReadOnlyList<WorkflowStepStatusDto> WorkflowSteps,
    IReadOnlyList<AttachmentDto> Attachments, IReadOnlyList<HistoryItemDto> History);

public record WorkflowStepStatusDto(string StageName, string ApproverRoleOrUser, string Status, DateTime? ActionedOn);

public record AttachmentDto(int Id, string FileName, string SharePointUrl, long SizeBytes, string UploadedByName, DateTime UploadedOn);

public record HistoryItemDto(string Action, string? Details, string PerformedByName, DateTime PerformedOn);

public record DelegationDto(int Id, string DelegatorName, string DelegateName, string ApplicationScope,
    string DelegationType, DateOnly? StartDate, DateOnly? EndDate, bool IsActive);

public record RoleDto(int Id, string Name, decimal Level, bool IsCustom, bool IsFlat);

public record PermissionMatrixRowDto(int ApplicationId, string ApplicationName, bool CanCreate, bool CanRead,
    bool CanUpdate, bool CanDelete, bool CanApprove, string DataScope);

public record ReportRequestDto(int? ApplicationId, DateOnly From, DateOnly To, string[] Metrics, string ExportAs);
