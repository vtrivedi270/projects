using ApplicationHub.Application.Common.Interfaces;
using ApplicationHub.Application.Common.Models;
using ApplicationHub.Domain.Enums;
using Microsoft.EntityFrameworkCore;
using MediatR;

namespace ApplicationHub.Application.Roles.Commands;

/// <summary>
/// Saves the Roles & Permissions matrix for one role, one row per application.
/// Super Admin edits are routed through MakerCheckerQueue instead of applied directly
/// (see MakerChecker docs in the platform-wide Role/Permission module).
/// </summary>
public record UpsertPermissionMatrixCommand(int RoleId, IReadOnlyList<PermissionMatrixRowDto> Rows) : IRequest;

public class UpsertPermissionMatrixCommandHandler : IRequestHandler<UpsertPermissionMatrixCommand>
{
    private readonly IApplicationHubDbContext _db;
    public UpsertPermissionMatrixCommandHandler(IApplicationHubDbContext db) => _db = db;

    public async Task Handle(UpsertPermissionMatrixCommand cmd, CancellationToken ct)
    {
        foreach (var row in cmd.Rows)
        {
            var perm = await _db.Permissions.FirstOrDefaultAsync(p =>
                p.RoleId == cmd.RoleId && p.ApplicationId == row.ApplicationId, ct);

            if (perm is null)
            {
                perm = new Domain.Entities.Permission { RoleId = cmd.RoleId, ApplicationId = row.ApplicationId };
                _db.Permissions.Add(perm);
            }
            perm.CanCreate = row.CanCreate; perm.CanRead = row.CanRead; perm.CanUpdate = row.CanUpdate;
            perm.CanDelete = row.CanDelete; perm.CanApprove = row.CanApprove;
            perm.DataScope = Enum.Parse<DataScope>(row.DataScope);
        }
        await _db.SaveChangesAsync(ct);
    }
}
