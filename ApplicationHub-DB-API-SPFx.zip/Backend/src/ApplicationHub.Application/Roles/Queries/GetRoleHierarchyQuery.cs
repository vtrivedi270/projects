using ApplicationHub.Application.Common.Interfaces;
using ApplicationHub.Application.Common.Models;
using Microsoft.EntityFrameworkCore;
using MediatR;

namespace ApplicationHub.Application.Roles.Queries;

public record GetRoleHierarchyQuery : IRequest<IReadOnlyList<RoleDto>>;

public class GetRoleHierarchyQueryHandler : IRequestHandler<GetRoleHierarchyQuery, IReadOnlyList<RoleDto>>
{
    private readonly IApplicationHubDbContext _db;
    public GetRoleHierarchyQueryHandler(IApplicationHubDbContext db) => _db = db;

    public async Task<IReadOnlyList<RoleDto>> Handle(GetRoleHierarchyQuery q, CancellationToken ct) =>
        await _db.Roles.OrderBy(r => r.Level)
            .Select(r => new RoleDto(r.Id, r.Name, r.Level, r.IsCustom, r.IsFlat))
            .ToListAsync(ct);
}
