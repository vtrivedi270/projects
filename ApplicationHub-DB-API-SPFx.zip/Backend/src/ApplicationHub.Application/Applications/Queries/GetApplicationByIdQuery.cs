using ApplicationHub.Application.Common.Interfaces;
using ApplicationHub.Application.Common.Models;
using Microsoft.EntityFrameworkCore;
using MediatR;

namespace ApplicationHub.Application.Applications.Queries;

public record GetApplicationByIdQuery(int ApplicationId) : IRequest<ApplicationDto?>;

public class GetApplicationByIdQueryHandler : IRequestHandler<GetApplicationByIdQuery, ApplicationDto?>
{
    private readonly IApplicationHubDbContext _db;
    public GetApplicationByIdQueryHandler(IApplicationHubDbContext db) => _db = db;

    public async Task<ApplicationDto?> Handle(GetApplicationByIdQuery request, CancellationToken ct)
    {
        var app = await _db.Applications.FirstOrDefaultAsync(a => a.Id == request.ApplicationId, ct);
        return app is null ? null : new ApplicationDto(app.Id, app.Name, app.Category, app.IconKey, app.IsActive, 0);
    }
}
