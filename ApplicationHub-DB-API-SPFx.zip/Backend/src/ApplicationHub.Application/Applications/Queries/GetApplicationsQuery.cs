using ApplicationHub.Application.Common.Interfaces;
using ApplicationHub.Application.Common.Models;
using ApplicationHub.Domain.Enums;
using Microsoft.EntityFrameworkCore;
using MediatR;

namespace ApplicationHub.Application.Applications.Queries;

/// <summary>Powers the Main Dashboard app-tile grid, including each tile's pending-approval badge.</summary>
public record GetApplicationsQuery(int CurrentUserId) : IRequest<IReadOnlyList<ApplicationDto>>;

public class GetApplicationsQueryHandler : IRequestHandler<GetApplicationsQuery, IReadOnlyList<ApplicationDto>>
{
    private readonly IApplicationHubDbContext _db;
    public GetApplicationsQueryHandler(IApplicationHubDbContext db) => _db = db;

    public async Task<IReadOnlyList<ApplicationDto>> Handle(GetApplicationsQuery request, CancellationToken ct)
    {
        var user = await _db.Users.FirstAsync(u => u.Id == request.CurrentUserId, ct);

        var apps = await _db.Applications.Where(a => a.IsActive).OrderBy(a => a.Name).ToListAsync(ct);

        var result = new List<ApplicationDto>();
        foreach (var app in apps)
        {
            var pending = await _db.Requests
                .Where(r => r.ApplicationId == app.Id && r.Status == RequestStatus.InProgress
                    && r.CurrentStage != null && r.CurrentStage.ApproverRoleId == user.RoleId)
                .CountAsync(ct);

            result.Add(new ApplicationDto(app.Id, app.Name, app.Category, app.IconKey, app.IsActive, pending));
        }
        return result;
    }
}
