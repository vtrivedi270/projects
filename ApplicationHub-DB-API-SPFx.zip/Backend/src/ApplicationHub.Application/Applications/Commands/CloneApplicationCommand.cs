using ApplicationHub.Application.Common.Interfaces;
using Microsoft.EntityFrameworkCore;
using MediatR;

namespace ApplicationHub.Application.Applications.Commands;

/// <summary>Deep-copies both the current FormDefinition and WorkflowDefinition into a new Application.</summary>
public record CloneApplicationCommand(int SourceApplicationId, string NewName) : IRequest<int>;

public class CloneApplicationCommandHandler : IRequestHandler<CloneApplicationCommand, int>
{
    private readonly IApplicationHubDbContext _db;
    public CloneApplicationCommandHandler(IApplicationHubDbContext db) => _db = db;

    public async Task<int> Handle(CloneApplicationCommand request, CancellationToken ct)
    {
        var source = await _db.Applications
            .Include(a => a.FormDefinitions).ThenInclude(f => f.Fields)
            .Include(a => a.WorkflowDefinitions).ThenInclude(w => w.Stages)
            .FirstAsync(a => a.Id == request.SourceApplicationId, ct);

        var clone = new Domain.Entities.Application
        {
            Name = request.NewName,
            Category = source.Category,
            IconKey = source.IconKey,
            SharePointLibraryName = request.NewName.Replace(" ", "") + "Attachments",
            IsActive = true
        };
        _db.Applications.Add(clone);
        await _db.SaveChangesAsync(ct);   // need clone.Id before attaching child definitions

        var activeForm = source.FormDefinitions.First(f => f.IsActive);
        var newForm = new Domain.Entities.FormDefinition { ApplicationId = clone.Id, Version = 1, IsActive = true };
        foreach (var field in activeForm.Fields)
        {
            newForm.Fields.Add(new Domain.Entities.FormField
            {
                ControlType = field.ControlType, Label = field.Label, BindTo = field.BindTo,
                IsRequired = field.IsRequired, IsReadOnly = field.IsReadOnly,
                VisibleToRoles = field.VisibleToRoles, ColumnWidth = field.ColumnWidth,
                SortOrder = field.SortOrder, OptionsJson = field.OptionsJson
            });
        }
        _db.FormDefinitions.Add(newForm);

        var activeWf = source.WorkflowDefinitions.First(w => w.IsActive);
        var newWf = new Domain.Entities.WorkflowDefinition { ApplicationId = clone.Id, Version = 1, IsActive = true };
        foreach (var stage in activeWf.Stages.OrderBy(s => s.SortOrder))
        {
            newWf.Stages.Add(new Domain.Entities.WorkflowStage
            {
                SortOrder = stage.SortOrder, StageName = stage.StageName, ApproverRoleId = stage.ApproverRoleId,
                CompletionRule = stage.CompletionRule, SlaHours = stage.SlaHours,
                AllowAmend = stage.AllowAmend, ParallelGroup = stage.ParallelGroup
            });
        }
        _db.WorkflowDefinitions.Add(newWf);

        await _db.SaveChangesAsync(ct);
        return clone.Id;
    }
}
