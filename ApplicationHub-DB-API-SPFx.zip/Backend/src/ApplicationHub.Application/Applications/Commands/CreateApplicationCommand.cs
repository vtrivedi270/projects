using ApplicationHub.Application.Common.Interfaces;
using ApplicationHub.Domain.Entities;
using MediatR;

namespace ApplicationHub.Application.Applications.Commands;

public record CreateApplicationCommand(string Name, string Category, string IconKey) : IRequest<int>;

public class CreateApplicationCommandHandler : IRequestHandler<CreateApplicationCommand, int>
{
    private readonly IApplicationHubDbContext _db;
    public CreateApplicationCommandHandler(IApplicationHubDbContext db) => _db = db;

    public async Task<int> Handle(CreateApplicationCommand request, CancellationToken ct)
    {
        var app = new Domain.Entities.Application
        {
            Name = request.Name,
            Category = request.Category,
            IconKey = request.IconKey,
            SharePointLibraryName = request.Name.Replace(" ", "") + "Attachments",
            IsActive = true
        };
        _db.Applications.Add(app);
        await _db.SaveChangesAsync(ct);
        return app.Id;
    }
}
