using ApplicationHub.Application.Common.Interfaces;
using ApplicationHub.Application.Common.Models;
using ApplicationHub.Domain.Enums;
using Microsoft.EntityFrameworkCore;
using MediatR;

namespace ApplicationHub.Application.Reports.Queries;

public record ReportRowDto(string ApplicationName, int Volume, double AvgApprovalHours, int SlaBreaches);

/// <summary>Backs Admin ▸ Reports: volume, average turnaround, and SLA breaches per application,
/// for the date range and metrics chosen in the report builder.</summary>
public record GenerateReportQuery(ReportRequestDto Filter) : IRequest<IReadOnlyList<ReportRowDto>>;

public class GenerateReportQueryHandler : IRequestHandler<GenerateReportQuery, IReadOnlyList<ReportRowDto>>
{
    private readonly IApplicationHubDbContext _db;
    public GenerateReportQueryHandler(IApplicationHubDbContext db) => _db = db;

    public async Task<IReadOnlyList<ReportRowDto>> Handle(GenerateReportQuery q, CancellationToken ct)
    {
        var from = q.Filter.From.ToDateTime(TimeOnly.MinValue);
        var to = q.Filter.To.ToDateTime(TimeOnly.MaxValue);

        var requests = _db.Requests.Include(r => r.Application)
            .Where(r => r.CreatedOn >= from && r.CreatedOn <= to);
        if (q.Filter.ApplicationId.HasValue) requests = requests.Where(r => r.ApplicationId == q.Filter.ApplicationId);

        var grouped = await requests
            .GroupBy(r => r.Application.Name)
            .Select(g => new
            {
                AppName = g.Key,
                Volume = g.Count(),
                AvgHours = g.Where(r => r.ModifiedOn != null)
                    .Select(r => EF.Functions.DateDiffHour(r.CreatedOn, r.ModifiedOn!.Value)).Average(),
                Breaches = g.Count(r => r.Status == RequestStatus.InProgress
                    && EF.Functions.DateDiffHour(r.CreatedOn, DateTime.UtcNow) > 48)
            })
            .ToListAsync(ct);

        return grouped.Select(g => new ReportRowDto(g.AppName, g.Volume, g.AvgHours ?? 0, g.Breaches)).ToList();
    }
}
