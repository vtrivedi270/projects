using ApplicationHub.Application.Common.Interfaces;
using ApplicationHub.Application.Common.Models;
using ApplicationHub.Domain.Enums;
using Microsoft.EntityFrameworkCore;
using MediatR;

namespace ApplicationHub.Application.WorkflowBuilder.Commands;

/// <summary>
/// Saves the Workflow Builder canvas as a new, immutable WorkflowDefinition version.
/// In-flight requests keep referencing their original WorkflowDefinitionId — new versions
/// only apply to requests submitted after activation.
/// </summary>
public record SaveWorkflowDefinitionCommand(int ApplicationId, IReadOnlyList<WorkflowStageDto> Stages) : IRequest<int>;

public class SaveWorkflowDefinitionCommandHandler : IRequestHandler<SaveWorkflowDefinitionCommand, int>
{
    private readonly IApplicationHubDbContext _db;
    public SaveWorkflowDefinitionCommandHandler(IApplicationHubDbContext db) => _db = db;

    public async Task<int> Handle(SaveWorkflowDefinitionCommand request, CancellationToken ct)
    {
        var app = await _db.Applications.FirstAsync(a => a.Id == request.ApplicationId, ct);

        var existing = await _db.WorkflowDefinitions
            .Where(w => w.ApplicationId == app.Id).OrderByDescending(w => w.Version)
            .FirstOrDefaultAsync(ct);
        var nextVersion = (existing?.Version ?? 0) + 1;
        if (existing is not null) existing.IsActive = false;

        var roleIdByName = await _db.Roles.ToDictionaryAsync(r => r.Name, r => r.Id, ct);

        var def = new Domain.Entities.WorkflowDefinition { ApplicationId = app.Id, Version = nextVersion, IsActive = true };
        var stageIdMap = new Dictionary<int, Domain.Entities.WorkflowStage>();  // client-side id -> saved entity, for amend-target wiring

        foreach (var s in request.Stages.OrderBy(s => s.SortOrder))
        {
            var stage = new Domain.Entities.WorkflowStage
            {
                SortOrder = s.SortOrder,
                StageName = s.StageName,
                ApproverRoleId = roleIdByName.TryGetValue(s.ApproverRole, out var rid) ? rid : roleIdByName["Employee"],
                CompletionRule = Enum.Parse<CompletionRule>(s.CompletionRule),
                SlaHours = s.SlaHours,
                AllowAmend = s.AllowAmend,
                ParallelGroup = s.ParallelGroup
            };
            def.Stages.Add(stage);
            stageIdMap[s.Id] = stage;
        }
        _db.WorkflowDefinitions.Add(def);
        app.CurrentWorkflowVersion = nextVersion;
        await _db.SaveChangesAsync(ct);   // stages now have real Ids

        // second pass: wire amend-target references now that Ids exist
        foreach (var s in request.Stages.Where(s => s.AmendTargetStageId.HasValue))
        {
            if (stageIdMap.TryGetValue(s.Id, out var stage) && stageIdMap.TryGetValue(s.AmendTargetStageId!.Value, out var target))
                stage.AmendTargetStageId = target.Id;
        }
        await _db.SaveChangesAsync(ct);

        return def.Id;
    }
}
