using ApplicationHub.Application.Common.Interfaces;
using ApplicationHub.Application.Common.Models;
using Microsoft.EntityFrameworkCore;
using MediatR;

namespace ApplicationHub.Application.WorkflowBuilder.Queries;

public record GetWorkflowDefinitionQuery(int ApplicationId) : IRequest<WorkflowDefinitionDto>;

public class GetWorkflowDefinitionQueryHandler : IRequestHandler<GetWorkflowDefinitionQuery, WorkflowDefinitionDto>
{
    private readonly IApplicationHubDbContext _db;
    public GetWorkflowDefinitionQueryHandler(IApplicationHubDbContext db) => _db = db;

    public async Task<WorkflowDefinitionDto> Handle(GetWorkflowDefinitionQuery request, CancellationToken ct)
    {
        var def = await _db.WorkflowDefinitions
            .Include(w => w.Stages).ThenInclude(s => s.ApproverRole)
            .Where(w => w.ApplicationId == request.ApplicationId && w.IsActive)
            .FirstAsync(ct);

        var stages = def.Stages.OrderBy(s => s.SortOrder).Select(s => new WorkflowStageDto(
            s.Id, s.SortOrder, s.StageName, s.ApproverRole.Name, s.CompletionRule.ToString(),
            s.SlaHours, s.AllowAmend, s.AmendTargetStageId, s.ParallelGroup)).ToList();

        return new WorkflowDefinitionDto(def.ApplicationId, def.Version, stages);
    }
}
