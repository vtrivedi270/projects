using ApplicationHub.Application.Common.Interfaces;
using ApplicationHub.Application.Common.Models;
using ApplicationHub.Domain.Enums;
using Microsoft.EntityFrameworkCore;
using MediatR;

namespace ApplicationHub.Application.FormBuilder.Commands;

/// <summary>
/// Saves the Form Builder canvas for an application as a new, immutable FormDefinition
/// version and activates it. Requests already in flight keep referencing their original
/// FormDefinitionId, so amending a form never changes historical data.
/// </summary>
public record SaveFormDefinitionCommand(int ApplicationId, IReadOnlyList<FormFieldDto> Fields) : IRequest<int>;

public class SaveFormDefinitionCommandHandler : IRequestHandler<SaveFormDefinitionCommand, int>
{
    private readonly IApplicationHubDbContext _db;
    public SaveFormDefinitionCommandHandler(IApplicationHubDbContext db) => _db = db;

    public async Task<int> Handle(SaveFormDefinitionCommand request, CancellationToken ct)
    {
        var app = await _db.Applications.FirstAsync(a => a.Id == request.ApplicationId, ct);

        var existing = await _db.FormDefinitions
            .Where(f => f.ApplicationId == app.Id).OrderByDescending(f => f.Version)
            .FirstOrDefaultAsync(ct);
        var nextVersion = (existing?.Version ?? 0) + 1;

        if (existing is not null) existing.IsActive = false;

        var def = new Domain.Entities.FormDefinition { ApplicationId = app.Id, Version = nextVersion, IsActive = true };
        foreach (var f in request.Fields.OrderBy(f => f.SortOrder))
        {
            def.Fields.Add(new Domain.Entities.FormField
            {
                ControlType = Enum.Parse<ControlType>(f.ControlType),
                Label = f.Label, BindTo = f.BindTo, IsRequired = f.IsRequired, IsReadOnly = f.IsReadOnly,
                VisibleToRoles = f.VisibleToRoles,
                ColumnWidth = Enum.Parse<ColumnWidth>(f.ColumnWidth),
                SortOrder = f.SortOrder, OptionsJson = f.OptionsJson
            });
        }
        _db.FormDefinitions.Add(def);
        app.CurrentFormVersion = nextVersion;

        await _db.SaveChangesAsync(ct);
        return def.Id;
    }
}
