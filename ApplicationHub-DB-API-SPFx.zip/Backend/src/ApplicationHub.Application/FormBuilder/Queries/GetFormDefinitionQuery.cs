using ApplicationHub.Application.Common.Interfaces;
using ApplicationHub.Application.Common.Models;
using Microsoft.EntityFrameworkCore;
using MediatR;

namespace ApplicationHub.Application.FormBuilder.Queries;

public record GetFormDefinitionQuery(int ApplicationId) : IRequest<FormDefinitionDto>;

public class GetFormDefinitionQueryHandler : IRequestHandler<GetFormDefinitionQuery, FormDefinitionDto>
{
    private readonly IApplicationHubDbContext _db;
    public GetFormDefinitionQueryHandler(IApplicationHubDbContext db) => _db = db;

    public async Task<FormDefinitionDto> Handle(GetFormDefinitionQuery request, CancellationToken ct)
    {
        var def = await _db.FormDefinitions
            .Include(f => f.Fields)
            .Where(f => f.ApplicationId == request.ApplicationId && f.IsActive)
            .FirstAsync(ct);

        var fields = def.Fields.OrderBy(f => f.SortOrder).Select(f => new FormFieldDto(
            f.Id, f.ControlType.ToString(), f.Label, f.BindTo, f.IsRequired, f.IsReadOnly,
            f.VisibleToRoles, f.ColumnWidth.ToString(), f.SortOrder, f.OptionsJson)).ToList();

        return new FormDefinitionDto(def.ApplicationId, def.Version, fields);
    }
}
