using ApplicationHub.Application.Common.Interfaces;
using ApplicationHub.Domain.Enums;
using Microsoft.EntityFrameworkCore;
using MediatR;

namespace ApplicationHub.Application.Requests.Commands;

/// <summary>Single handler for Approve / Reject / Return — mirrors the one workflow-engine
/// codepath that advances, closes, or rewinds a request, matching CompletionRule.</summary>
public record ActOnRequestCommand(int RequestId, int ApproverId, ApprovalAction Action, string? Comment,
    int? OnBehalfOfUserId) : IRequest;

public class ActOnRequestCommandHandler : IRequestHandler<ActOnRequestCommand>
{
    private readonly IApplicationHubDbContext _db;
    private readonly INotificationService _notify;
    public ActOnRequestCommandHandler(IApplicationHubDbContext db, INotificationService notify)
    { _db = db; _notify = notify; }

    public async Task Handle(ActOnRequestCommand cmd, CancellationToken ct)
    {
        var req = await _db.Requests
            .Include(r => r.WorkflowDefinition).ThenInclude(w => w.Stages)
            .Include(r => r.Approvals)
            .FirstAsync(r => r.Id == cmd.RequestId, ct);

        var stage = req.WorkflowDefinition.Stages.First(s => s.Id == req.CurrentStageId);

        _db.RequestApprovals.Add(new Domain.Entities.RequestApproval
        {
            RequestId = req.Id, StageId = stage.Id, ApproverId = cmd.ApproverId,
            Action = cmd.Action, Comment = cmd.Comment, OnBehalfOfUserId = cmd.OnBehalfOfUserId
        });
        req.History.Add(new Domain.Entities.RequestHistory
        {
            Action = cmd.Action.ToString(), Details = cmd.Comment, PerformedById = cmd.ApproverId
        });

        if (cmd.Action == ApprovalAction.Rejected)
        {
            req.Status = RequestStatus.Rejected;
        }
        else if (cmd.Action == ApprovalAction.Returned)
        {
            req.Status = RequestStatus.Returned;
            req.CurrentStageId = stage.AmendTargetStageId ?? req.WorkflowDefinition.Stages.OrderBy(s => s.SortOrder).First().Id;
        }
        else // Approved — evaluate this stage's completion rule before advancing
        {
            var actionsAtStage = await _db.RequestApprovals.CountAsync(a => a.RequestId == req.Id
                && a.StageId == stage.Id && a.Action == Domain.Enums.ApprovalAction.Approved, ct);
            var approversInGroup = stage.ParallelGroup.HasValue
                ? req.WorkflowDefinition.Stages.Count(s => s.ParallelGroup == stage.ParallelGroup)
                : 1;

            var stageComplete = stage.CompletionRule switch
            {
                CompletionRule.AnyOne => true,
                CompletionRule.All => actionsAtStage >= approversInGroup,
                CompletionRule.Majority => actionsAtStage > approversInGroup / 2,
                _ => true
            };

            if (stageComplete)
            {
                var nextStage = req.WorkflowDefinition.Stages
                    .Where(s => s.SortOrder > stage.SortOrder).OrderBy(s => s.SortOrder).FirstOrDefault();

                if (nextStage is null)
                {
                    req.Status = RequestStatus.Approved;
                    req.CurrentStageId = null;
                }
                else
                {
                    req.CurrentStageId = nextStage.Id;
                    await _notify.SendEmailAsync(nextStage.ApproverRoleId,
                        $"Request {req.RequestNumber} needs your approval", "", ct);
                }
            }
        }

        req.ModifiedOn = DateTime.UtcNow;
        await _db.SaveChangesAsync(ct);
    }
}
