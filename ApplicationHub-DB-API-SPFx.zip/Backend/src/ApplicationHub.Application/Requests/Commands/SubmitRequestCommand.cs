using ApplicationHub.Application.Common.Interfaces;
using ApplicationHub.Domain.Enums;
using Microsoft.EntityFrameworkCore;
using MediatR;

namespace ApplicationHub.Application.Requests.Commands;

public record SubmitRequestCommand(int ApplicationId, int RequesterId, string FormDataJson) : IRequest<string>;

public class SubmitRequestCommandHandler : IRequestHandler<SubmitRequestCommand, string>
{
    private readonly IApplicationHubDbContext _db;
    private readonly INotificationService _notify;
    public SubmitRequestCommandHandler(IApplicationHubDbContext db, INotificationService notify)
    { _db = db; _notify = notify; }

    public async Task<string> Handle(SubmitRequestCommand request, CancellationToken ct)
    {
        var app = await _db.Applications.FirstAsync(a => a.Id == request.ApplicationId, ct);
        var form = await _db.FormDefinitions.FirstAsync(f => f.ApplicationId == app.Id && f.IsActive, ct);
        var workflow = await _db.WorkflowDefinitions
            .Include(w => w.Stages)
            .FirstAsync(w => w.ApplicationId == app.Id && w.IsActive, ct);

        var firstStage = workflow.Stages.OrderBy(s => s.SortOrder).First();
        var seq = await _db.Requests.CountAsync(r => r.ApplicationId == app.Id, ct) + 1;
        var prefix = new string(app.Name.Split(' ').Select(w => w[0]).Take(2).ToArray()).ToUpper();

        var entity = new Domain.Entities.Request
        {
            ApplicationId = app.Id,
            RequestNumber = $"{prefix}-{DateTime.UtcNow.Year}-{seq:D5}",
            RequesterId = request.RequesterId,
            WorkflowDefinitionId = workflow.Id,
            FormDefinitionId = form.Id,
            FormDataJson = request.FormDataJson,
            Status = RequestStatus.InProgress,
            CurrentStageId = firstStage.Id
        };
        entity.History.Add(new Domain.Entities.RequestHistory
        {
            Action = "Submitted", PerformedById = request.RequesterId
        });

        _db.Requests.Add(entity);
        await _db.SaveChangesAsync(ct);

        await _notify.SendEmailAsync(firstStage.ApproverRoleId, $"New {app.Name} request {entity.RequestNumber}",
            "A new request is waiting for your approval.", ct);

        return entity.RequestNumber;
    }
}
