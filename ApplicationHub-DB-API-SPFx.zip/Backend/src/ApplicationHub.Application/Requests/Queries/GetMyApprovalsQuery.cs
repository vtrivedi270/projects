using ApplicationHub.Application.Common.Interfaces;
using ApplicationHub.Application.Common.Models;
using ApplicationHub.Domain.Enums;
using Microsoft.EntityFrameworkCore;
using MediatR;

namespace ApplicationHub.Application.Requests.Queries;

/// <summary>"My Approvals" tab — requests currently sitting at a stage the caller's role owns,
/// including anything delegated to them.</summary>
public record GetMyApprovalsQuery(int UserId, decimal ApproverRoleLevel, IReadOnlyList<int> DelegatedFromUserIds,
    int? ApplicationId, int Page, int PageSize) : IRequest<IReadOnlyList<RequestListItemDto>>;

public class GetMyApprovalsQueryHandler : IRequestHandler<GetMyApprovalsQuery, IReadOnlyList<RequestListItemDto>>
{
    private readonly IApplicationHubDbContext _db;
    public GetMyApprovalsQueryHandler(IApplicationHubDbContext db) => _db = db;

    public async Task<IReadOnlyList<RequestListItemDto>> Handle(GetMyApprovalsQuery q, CancellationToken ct)
    {
        var user = await _db.Users.Include(u => u.Role).FirstAsync(u => u.Id == q.UserId, ct);

        var query = _db.Requests.Include(r => r.Application).Include(r => r.Requester).Include(r => r.CurrentStage)
            .Where(r => r.Status == RequestStatus.InProgress
                && r.CurrentStage != null
                && r.CurrentStage.ApproverRoleId == user.RoleId);
        if (q.ApplicationId.HasValue) query = query.Where(r => r.ApplicationId == q.ApplicationId);

        return await query.OrderBy(r => r.CreatedOn)
            .Skip((q.Page - 1) * q.PageSize).Take(q.PageSize)
            .Select(r => new RequestListItemDto(r.Id, r.RequestNumber, r.Application.Name, r.Requester.FullName,
                r.CreatedOn, r.Status.ToString(), r.CurrentStage!.StageName))
            .ToListAsync(ct);
    }
}
