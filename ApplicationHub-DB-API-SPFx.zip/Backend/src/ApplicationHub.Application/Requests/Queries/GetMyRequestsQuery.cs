using ApplicationHub.Application.Common.Interfaces;
using ApplicationHub.Application.Common.Models;
using Microsoft.EntityFrameworkCore;
using MediatR;

namespace ApplicationHub.Application.Requests.Queries;

/// <summary>"My Requests" tab — everything the caller personally raised, any application.</summary>
public record GetMyRequestsQuery(int UserId, int? ApplicationId, int Page, int PageSize) : IRequest<IReadOnlyList<RequestListItemDto>>;

public class GetMyRequestsQueryHandler : IRequestHandler<GetMyRequestsQuery, IReadOnlyList<RequestListItemDto>>
{
    private readonly IApplicationHubDbContext _db;
    public GetMyRequestsQueryHandler(IApplicationHubDbContext db) => _db = db;

    public async Task<IReadOnlyList<RequestListItemDto>> Handle(GetMyRequestsQuery q, CancellationToken ct)
    {
        var query = _db.Requests.Include(r => r.Application).Include(r => r.Requester).Include(r => r.CurrentStage)
            .Where(r => r.RequesterId == q.UserId);
        if (q.ApplicationId.HasValue) query = query.Where(r => r.ApplicationId == q.ApplicationId);

        return await query.OrderByDescending(r => r.CreatedOn)
            .Skip((q.Page - 1) * q.PageSize).Take(q.PageSize)
            .Select(r => new RequestListItemDto(r.Id, r.RequestNumber, r.Application.Name, r.Requester.FullName,
                r.CreatedOn, r.Status.ToString(), r.CurrentStage?.StageName))
            .ToListAsync(ct);
    }
}
