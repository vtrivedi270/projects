using ApplicationHub.Application.Common.Interfaces;
using ApplicationHub.Application.Common.Models;
using Microsoft.EntityFrameworkCore;
using MediatR;

namespace ApplicationHub.Application.Requests.Queries;

/// <summary>"All Requests" tab — scoped by the caller's DataScope permission (Own/Team/Department/Division/All),
/// enforced upstream by the controller/authorization filter, not repeated here.</summary>
public record GetAllRequestsQuery(int ApplicationId, IReadOnlyList<int> VisibleRequesterIds, int Page, int PageSize)
    : IRequest<IReadOnlyList<RequestListItemDto>>;

public class GetAllRequestsQueryHandler : IRequestHandler<GetAllRequestsQuery, IReadOnlyList<RequestListItemDto>>
{
    private readonly IApplicationHubDbContext _db;
    public GetAllRequestsQueryHandler(IApplicationHubDbContext db) => _db = db;

    public async Task<IReadOnlyList<RequestListItemDto>> Handle(GetAllRequestsQuery q, CancellationToken ct)
    {
        return await _db.Requests.Include(r => r.Application).Include(r => r.Requester).Include(r => r.CurrentStage)
            .Where(r => r.ApplicationId == q.ApplicationId && q.VisibleRequesterIds.Contains(r.RequesterId))
            .OrderByDescending(r => r.CreatedOn)
            .Skip((q.Page - 1) * q.PageSize).Take(q.PageSize)
            .Select(r => new RequestListItemDto(r.Id, r.RequestNumber, r.Application.Name, r.Requester.FullName,
                r.CreatedOn, r.Status.ToString(), r.CurrentStage?.StageName))
            .ToListAsync(ct);
    }
}
