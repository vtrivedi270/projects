using ApplicationHub.Application.Common.Interfaces;
using ApplicationHub.Application.Common.Models;
using Microsoft.EntityFrameworkCore;
using MediatR;

namespace ApplicationHub.Application.Requests.Queries;

/// <summary>Powers the record-detail screen: Entry Form + Attachment + History + Workflow tabs in one call.</summary>
public record GetRequestDetailQuery(int RequestId) : IRequest<RequestDetailDto>;

public class GetRequestDetailQueryHandler : IRequestHandler<GetRequestDetailQuery, RequestDetailDto>
{
    private readonly IApplicationHubDbContext _db;
    public GetRequestDetailQueryHandler(IApplicationHubDbContext db) => _db = db;

    public async Task<RequestDetailDto> Handle(GetRequestDetailQuery q, CancellationToken ct)
    {
        var r = await _db.Requests
            .Include(x => x.Application)
            .Include(x => x.FormDefinition).ThenInclude(f => f.Fields)
            .Include(x => x.WorkflowDefinition).ThenInclude(w => w.Stages).ThenInclude(s => s.ApproverRole)
            .Include(x => x.Approvals).ThenInclude(a => a.Approver)
            .Include(x => x.Attachments).ThenInclude(a => a.UploadedBy)
            .Include(x => x.History).ThenInclude(h => h.PerformedBy)
            .FirstAsync(x => x.Id == q.RequestId, ct);

        var fields = r.FormDefinition.Fields.OrderBy(f => f.SortOrder).Select(f => new FormFieldDto(
            f.Id, f.ControlType.ToString(), f.Label, f.BindTo, f.IsRequired, f.IsReadOnly,
            f.VisibleToRoles, f.ColumnWidth.ToString(), f.SortOrder, f.OptionsJson)).ToList();

        var steps = r.WorkflowDefinition.Stages.OrderBy(s => s.SortOrder).Select(s =>
        {
            var action = r.Approvals.Where(a => a.StageId == s.Id).OrderByDescending(a => a.ActionedOn).FirstOrDefault();
            var status = action is not null ? action.Action.ToString()
                : r.CurrentStageId == s.Id ? "Pending" : "NotStarted";
            return new WorkflowStepStatusDto(s.StageName, action is not null ? action.Approver.FullName : s.ApproverRole.Name,
                status, action?.ActionedOn);
        }).ToList();

        var attachments = r.Attachments.Select(a => new AttachmentDto(
            a.Id, a.FileName, a.SharePointUrl, a.SizeBytes, a.UploadedBy.FullName, a.UploadedOn)).ToList();

        var history = r.History.OrderByDescending(h => h.PerformedOn).Select(h => new HistoryItemDto(
            h.Action, h.Details, h.PerformedBy.FullName, h.PerformedOn)).ToList();

        return new RequestDetailDto(r.Id, r.RequestNumber, r.Application.Name, r.Status.ToString(),
            r.FormDataJson, new FormDefinitionDto(r.ApplicationId, r.FormDefinition.Version, fields),
            steps, attachments, history);
    }
}
