using ApplicationHub.Application.Common.Interfaces;
using Microsoft.EntityFrameworkCore;
using MediatR;

namespace ApplicationHub.Application.Attachments.Commands;

/// <summary>Stores the file in the request's application-specific SharePoint library, then records it.</summary>
public record UploadAttachmentCommand(int RequestId, int UploadedById, string FileName, Stream Content) : IRequest<int>;

public class UploadAttachmentCommandHandler : IRequestHandler<UploadAttachmentCommand, int>
{
    private readonly IApplicationHubDbContext _db;
    private readonly ISharePointAttachmentService _sp;
    public UploadAttachmentCommandHandler(IApplicationHubDbContext db, ISharePointAttachmentService sp)
    { _db = db; _sp = sp; }

    public async Task<int> Handle(UploadAttachmentCommand cmd, CancellationToken ct)
    {
        var req = await _db.Requests.Include(r => r.Application).FirstAsync(r => r.Id == cmd.RequestId, ct);
        var url = await _sp.UploadAsync(req.Application.SharePointLibraryName, cmd.FileName, cmd.Content, ct);

        var attachment = new Domain.Entities.Attachment
        {
            RequestId = req.Id, FileName = cmd.FileName, SharePointUrl = url,
            SizeBytes = cmd.Content.Length, UploadedById = cmd.UploadedById
        };
        _db.Attachments.Add(attachment);
        req.History.Add(new Domain.Entities.RequestHistory
        {
            RequestId = req.Id, Action = "Attachment uploaded", Details = cmd.FileName, PerformedById = cmd.UploadedById
        });
        await _db.SaveChangesAsync(ct);
        return attachment.Id;
    }
}
