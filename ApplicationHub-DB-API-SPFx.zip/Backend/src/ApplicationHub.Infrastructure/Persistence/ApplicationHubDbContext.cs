using ApplicationHub.Application.Common.Interfaces;
using ApplicationHub.Domain.Entities;
using Microsoft.EntityFrameworkCore;

namespace ApplicationHub.Infrastructure.Persistence;

public class ApplicationHubDbContext : DbContext, IApplicationHubDbContext
{
    public ApplicationHubDbContext(DbContextOptions<ApplicationHubDbContext> options) : base(options) { }

    public DbSet<Application> Applications => Set<Application>();
    public DbSet<FormDefinition> FormDefinitions => Set<FormDefinition>();
    public DbSet<FormField> FormFields => Set<FormField>();
    public DbSet<WorkflowDefinition> WorkflowDefinitions => Set<WorkflowDefinition>();
    public DbSet<WorkflowStage> WorkflowStages => Set<WorkflowStage>();
    public DbSet<Request> Requests => Set<Request>();
    public DbSet<RequestApproval> RequestApprovals => Set<RequestApproval>();
    public DbSet<Attachment> Attachments => Set<Attachment>();
    public DbSet<RequestHistory> RequestHistory => Set<RequestHistory>();
    public DbSet<Delegation> Delegations => Set<Delegation>();
    public DbSet<Role> Roles => Set<Role>();
    public DbSet<Permission> Permissions => Set<Permission>();
    public DbSet<User> Users => Set<User>();
    public DbSet<MakerCheckerQueueItem> MakerCheckerQueue => Set<MakerCheckerQueueItem>();

    protected override void OnModelCreating(ModelBuilder builder)
    {
        builder.ApplyConfigurationsFromAssembly(typeof(ApplicationHubDbContext).Assembly);
        base.OnModelCreating(builder);
    }
}
