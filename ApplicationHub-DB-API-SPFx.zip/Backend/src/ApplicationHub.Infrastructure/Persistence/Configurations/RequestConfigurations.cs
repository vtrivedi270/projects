using ApplicationHub.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace ApplicationHub.Infrastructure.Persistence.Configurations;

public class RequestConfiguration : IEntityTypeConfiguration<Request>
{
    public void Configure(EntityTypeBuilder<Request> b)
    {
        b.ToTable("Requests");
        b.Property(x => x.RequestNumber).HasMaxLength(30).IsRequired();
        b.HasIndex(x => x.RequestNumber).IsUnique();
        b.Property(x => x.Status).HasConversion<string>().HasMaxLength(20);
        b.Property(x => x.FormDataJson).HasColumnType("nvarchar(max)");
        b.HasIndex(x => new { x.ApplicationId, x.Status });
        b.HasOne(x => x.CurrentStage).WithMany().HasForeignKey(x => x.CurrentStageId).OnDelete(DeleteBehavior.NoAction);
        b.HasMany(x => x.Approvals).WithOne(a => a.Request).HasForeignKey(a => a.RequestId);
        b.HasMany(x => x.Attachments).WithOne(a => a.Request).HasForeignKey(a => a.RequestId);
        b.HasMany(x => x.History).WithOne(h => h.Request).HasForeignKey(h => h.RequestId);
    }
}

public class RequestApprovalConfiguration : IEntityTypeConfiguration<RequestApproval>
{
    public void Configure(EntityTypeBuilder<RequestApproval> b)
    {
        b.ToTable("RequestApprovals");
        b.Property(x => x.Action).HasConversion<string>().HasMaxLength(20);
        b.Property(x => x.Comment).HasMaxLength(500);
    }
}
