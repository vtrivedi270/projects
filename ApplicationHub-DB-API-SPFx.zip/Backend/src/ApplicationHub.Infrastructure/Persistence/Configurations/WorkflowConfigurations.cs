using ApplicationHub.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace ApplicationHub.Infrastructure.Persistence.Configurations;

public class WorkflowDefinitionConfiguration : IEntityTypeConfiguration<WorkflowDefinition>
{
    public void Configure(EntityTypeBuilder<WorkflowDefinition> b)
    {
        b.ToTable("WorkflowDefinitions");
        b.HasIndex(x => new { x.ApplicationId, x.Version }).IsUnique();
        b.HasMany(x => x.Stages).WithOne(s => s.WorkflowDefinition).HasForeignKey(s => s.WorkflowDefinitionId);
    }
}

public class WorkflowStageConfiguration : IEntityTypeConfiguration<WorkflowStage>
{
    public void Configure(EntityTypeBuilder<WorkflowStage> b)
    {
        b.ToTable("WorkflowStages");
        b.Property(x => x.CompletionRule).HasConversion<string>().HasMaxLength(20);
        b.Property(x => x.StageName).HasMaxLength(150).IsRequired();
        b.HasOne(x => x.ApproverRole).WithMany().HasForeignKey(x => x.ApproverRoleId).OnDelete(DeleteBehavior.Restrict);
        // self-referencing amend target — no cascade, avoids multiple-cascade-path SQL Server error
        b.HasOne<WorkflowStage>().WithMany().HasForeignKey(x => x.AmendTargetStageId).OnDelete(DeleteBehavior.NoAction);
    }
}
