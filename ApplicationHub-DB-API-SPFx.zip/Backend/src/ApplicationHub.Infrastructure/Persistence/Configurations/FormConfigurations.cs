using ApplicationHub.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace ApplicationHub.Infrastructure.Persistence.Configurations;

public class FormDefinitionConfiguration : IEntityTypeConfiguration<FormDefinition>
{
    public void Configure(EntityTypeBuilder<FormDefinition> b)
    {
        b.ToTable("FormDefinitions");
        b.HasIndex(x => new { x.ApplicationId, x.Version }).IsUnique();
        b.HasMany(x => x.Fields).WithOne(f => f.FormDefinition).HasForeignKey(f => f.FormDefinitionId);
    }
}

public class FormFieldConfiguration : IEntityTypeConfiguration<FormField>
{
    public void Configure(EntityTypeBuilder<FormField> b)
    {
        b.ToTable("FormFields");
        b.Property(x => x.ControlType).HasConversion<string>().HasMaxLength(30);
        b.Property(x => x.ColumnWidth).HasConversion<string>().HasMaxLength(10);
        b.Property(x => x.Label).HasMaxLength(150).IsRequired();
        b.Property(x => x.OptionsJson).HasColumnType("nvarchar(max)");
    }
}
