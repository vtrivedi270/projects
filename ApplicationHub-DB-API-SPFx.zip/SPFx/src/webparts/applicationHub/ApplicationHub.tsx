import * as React from 'react';
import { useState } from 'react';
import { ConfigProvider, Menu, Badge } from 'antd';
import {
  AppstoreOutlined, FileTextOutlined, DeploymentUnitOutlined, BranchesOutlined,
  SafetyCertificateOutlined, ClockCircleOutlined, BarChartOutlined
} from '@ant-design/icons';
import { WebPartContext } from '@microsoft/sp-webpart-base';
import { ApplicationHubService } from './services/ApplicationHubService';
import { IApplicationDto } from './models/models';
import { Dashboard } from './components/Dashboard/Dashboard';
import { ApplicationDashboard } from './components/ApplicationDashboard/ApplicationDashboard';
import { RecordDetail } from './components/RecordDetail/RecordDetail';
import { ManageApplications } from './components/Admin/ManageApplications';
import { FormBuilder } from './components/Admin/FormBuilder';
import { WorkflowBuilder } from './components/Admin/WorkflowBuilder';
import { RolesPermissions } from './components/Admin/RolesPermissions';
import { DelegationScreen } from './components/Admin/Delegation';
import { Reports } from './components/Admin/Reports';

export interface IApplicationHubProps {
  context: WebPartContext;
  apiBaseUrl: string;
  apiResourceId: string;
  currentUserId: number;
  currentUserRoleLevel: number;
  isAdmin: boolean;
}

type Screen = 'dashboard' | 'app-dash' | 'record' | 'admin-apps' | 'admin-form' | 'admin-workflow'
  | 'admin-roles' | 'admin-delegation' | 'admin-reports';

/** Root shell: red-themed antd ConfigProvider + left nav switching between every screen in the approved preview. */
export const ApplicationHubWebPart: React.FC<IApplicationHubProps> = (props) => {
  const service = React.useMemo(
    () => new ApplicationHubService(props.context, props.apiBaseUrl, props.apiResourceId),
    [props.context, props.apiBaseUrl, props.apiResourceId]
  );

  const [screen, setScreen] = useState<Screen>('dashboard');
  const [activeApp, setActiveApp] = useState<IApplicationDto | undefined>(undefined);
  const [activeRequestId, setActiveRequestId] = useState<number | undefined>(undefined);
  const [apps, setApps] = useState<IApplicationDto[]>([]);

  React.useEffect(() => { service.getApplications(props.currentUserId).then(setApps); }, [service]);

  const openApplication = (app: IApplicationDto) => { setActiveApp(app); setScreen('app-dash'); };
  const openRequest = (id: number) => { setActiveRequestId(id); setScreen('record'); };

  const navItems = [
    { key: 'dashboard', icon: <AppstoreOutlined />, label: 'Dashboard' },
    { key: 'admin-apps', icon: <FileTextOutlined />, label: 'Manage Applications' },
    ...(props.isAdmin ? [
      { key: 'admin-form', icon: <DeploymentUnitOutlined />, label: 'Form Builder' },
      { key: 'admin-workflow', icon: <BranchesOutlined />, label: 'Workflow Builder' },
      { key: 'admin-roles', icon: <SafetyCertificateOutlined />, label: 'Roles & Permissions' },
      { key: 'admin-delegation', icon: <ClockCircleOutlined />, label: 'Delegation' },
      { key: 'admin-reports', icon: <BarChartOutlined />, label: 'Reports' }
    ] : [])
  ];

  return (
    <ConfigProvider theme={{ token: { colorPrimary: '#CF1322', borderRadius: 6 } }}>
      <div style={{ display: 'flex', minHeight: 600, fontFamily: 'Segoe UI, sans-serif' }}>
        <div style={{ width: 220, background: '#3D0C02' }}>
          <Menu theme="dark" mode="inline" selectedKeys={[screen]} items={navItems}
            style={{ background: 'transparent', borderRight: 0 }}
            onClick={e => setScreen(e.key as Screen)} />
        </div>
        <div style={{ flex: 1, padding: 24, background: '#F5F5F7' }}>
          {screen === 'dashboard' && (
            <Dashboard service={service} currentUserId={props.currentUserId} onOpenApplication={openApplication} />
          )}
          {screen === 'app-dash' && activeApp && (
            <ApplicationDashboard service={service} application={activeApp} currentUserId={props.currentUserId}
              currentUserRoleLevel={props.currentUserRoleLevel} onOpenRequest={openRequest}
              onNewRequest={() => openRequest(0)} />
          )}
          {screen === 'record' && activeRequestId !== undefined && (
            <RecordDetail service={service} requestId={activeRequestId} currentUserId={props.currentUserId}
              canApprove={props.currentUserRoleLevel > 1} onBack={() => setScreen('app-dash')} />
          )}
          {screen === 'admin-apps' && (
            <ManageApplications service={service} currentUserId={props.currentUserId}
              onEditForm={app => { setActiveApp(app); setScreen('admin-form'); }}
              onEditWorkflow={app => { setActiveApp(app); setScreen('admin-workflow'); }} />
          )}
          {screen === 'admin-form' && activeApp && <FormBuilder service={service} application={activeApp} />}
          {screen === 'admin-workflow' && activeApp && <WorkflowBuilder service={service} application={activeApp} />}
          {screen === 'admin-roles' && <RolesPermissions service={service} />}
          {screen === 'admin-delegation' && <DelegationScreen service={service} />}
          {screen === 'admin-reports' && <Reports service={service} applications={apps} />}
        </div>
      </div>
    </ConfigProvider>
  );
};
