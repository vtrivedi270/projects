import { AadHttpClient, HttpClientResponse } from '@microsoft/sp-http';
import { WebPartContext } from '@microsoft/sp-webpart-base';
import {
  IApplicationDto, IFormDefinitionDto, IFormFieldDto, IWorkflowDefinitionDto, IWorkflowStageDto,
  IRequestListItemDto, IRequestDetailDto, IDelegationDto, IRoleDto, IPermissionMatrixRowDto
} from '../models/models';

/**
 * Thin wrapper around the ApplicationHub.Api endpoints, authenticated via AadHttpClient
 * (Azure AD app registration for the API, resource id configured in the web part properties).
 */
export class ApplicationHubService {
  private client: Promise<AadHttpClient>;
  private readonly baseUrl: string;

  constructor(context: WebPartContext, apiBaseUrl: string, apiResourceId: string) {
    this.baseUrl = apiBaseUrl.replace(/\/$/, '');
    this.client = context.aadHttpClientFactory.getClient(apiResourceId);
  }

  private async get<T>(path: string): Promise<T> {
    const client = await this.client;
    const res: HttpClientResponse = await client.get(`${this.baseUrl}${path}`, AadHttpClient.configurations.v1);
    if (!res.ok) throw new Error(`GET ${path} failed: ${res.status}`);
    return res.json();
  }

  private async send<T>(method: 'POST' | 'PUT', path: string, body?: unknown): Promise<T> {
    const client = await this.client;
    const options = {
      headers: { 'Content-Type': 'application/json' },
      body: body !== undefined ? JSON.stringify(body) : undefined
    };
    const res: HttpClientResponse = method === 'POST'
      ? await client.post(`${this.baseUrl}${path}`, AadHttpClient.configurations.v1, options)
      : await client.fetch(`${this.baseUrl}${path}`, AadHttpClient.configurations.v1, { ...options, method: 'PUT' });
    if (!res.ok) throw new Error(`${method} ${path} failed: ${res.status}`);
    return res.status === 204 ? (undefined as unknown as T) : res.json();
  }

  // ---- Dashboard ----
  getApplications(currentUserId: number): Promise<IApplicationDto[]> {
    return this.get(`/api/applications?currentUserId=${currentUserId}`);
  }

  // ---- Application dashboard (My Request / My Approval / All Request) ----
  getMyRequests(userId: number, applicationId?: number, page = 1, pageSize = 20): Promise<IRequestListItemDto[]> {
    return this.get(`/api/requests/mine?userId=${userId}${applicationId ? `&applicationId=${applicationId}` : ''}&page=${page}&pageSize=${pageSize}`);
  }
  getMyApprovals(userId: number, roleLevel: number, applicationId?: number, page = 1, pageSize = 20): Promise<IRequestListItemDto[]> {
    return this.get(`/api/requests/pending-my-approval?userId=${userId}&roleLevel=${roleLevel}${applicationId ? `&applicationId=${applicationId}` : ''}&page=${page}&pageSize=${pageSize}`);
  }
  getAllRequests(applicationId: number, page = 1, pageSize = 20): Promise<IRequestListItemDto[]> {
    return this.get(`/api/requests?applicationId=${applicationId}&page=${page}&pageSize=${pageSize}`);
  }

  // ---- Record detail: Entry Form / Attachment / History / Workflow ----
  getRequestDetail(requestId: number): Promise<IRequestDetailDto> {
    return this.get(`/api/requests/${requestId}`);
  }
  submitRequest(applicationId: number, requesterId: number, formDataJson: string): Promise<string> {
    return this.send('POST', '/api/requests', { applicationId, requesterId, formDataJson });
  }
  approveRequest(requestId: number, approverId: number, comment?: string): Promise<void> {
    return this.send('POST', `/api/requests/${requestId}/approve`, { approverId, comment });
  }
  rejectRequest(requestId: number, approverId: number, comment?: string): Promise<void> {
    return this.send('POST', `/api/requests/${requestId}/reject`, { approverId, comment });
  }
  returnRequest(requestId: number, approverId: number, comment?: string): Promise<void> {
    return this.send('POST', `/api/requests/${requestId}/return`, { approverId, comment });
  }
  uploadAttachment(requestId: number, uploadedById: number, file: File): Promise<{ attachmentId: number }> {
    const form = new FormData();
    form.append('uploadedById', String(uploadedById));
    form.append('file', file);
    return this.client.then(client => client.fetch(
      `${this.baseUrl}/api/requests/${requestId}/attachments`, AadHttpClient.configurations.v1,
      { method: 'POST', body: form as unknown as string }
    )).then(res => res.json());
  }

  // ---- Admin: Manage Applications ----
  createApplication(name: string, category: string, iconKey: string): Promise<number> {
    return this.send('POST', '/api/applications', { name, category, iconKey });
  }
  cloneApplication(sourceApplicationId: number, newName: string): Promise<number> {
    return this.send('POST', `/api/applications/${sourceApplicationId}/clone`, newName);
  }

  // ---- Admin: Form Builder ----
  getFormDefinition(applicationId: number): Promise<IFormDefinitionDto> {
    return this.get(`/api/applications/${applicationId}/form`);
  }
  saveFormDefinition(applicationId: number, fields: IFormFieldDto[]): Promise<number> {
    return this.send('PUT', `/api/applications/${applicationId}/form`, fields);
  }

  // ---- Admin: Workflow Builder ----
  getWorkflowDefinition(applicationId: number): Promise<IWorkflowDefinitionDto> {
    return this.get(`/api/applications/${applicationId}/workflow`);
  }
  saveWorkflowDefinition(applicationId: number, stages: IWorkflowStageDto[]): Promise<number> {
    return this.send('PUT', `/api/applications/${applicationId}/workflow`, stages);
  }

  // ---- Admin: Roles & Permissions ----
  getRoleHierarchy(): Promise<IRoleDto[]> {
    return this.get('/api/roles');
  }
  savePermissionMatrix(roleId: number, rows: IPermissionMatrixRowDto[]): Promise<void> {
    return this.send('PUT', `/api/roles/${roleId}/permissions`, rows);
  }

  // ---- Admin: Delegation ----
  getDelegations(): Promise<IDelegationDto[]> {
    return this.get('/api/delegations');
  }
  createDelegation(delegatorId: number, delegateId: number, applicationIdsCsv: string,
    type: 'TimeBound' | 'Permanent', startDate?: string, endDate?: string): Promise<number> {
    return this.send('POST', '/api/delegations', { delegatorId, delegateId, applicationIdsCsv, type, startDate, endDate });
  }

  // ---- Admin: Reports ----
  generateReport(applicationId: number | null, from: string, to: string, metrics: string[], exportAs: string) {
    return this.send('POST', '/api/reports/generate', { applicationId, from, to, metrics, exportAs });
  }
}
