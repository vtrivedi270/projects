export interface IApplicationDto {
  id: number;
  name: string;
  category: string;
  iconKey: string;
  isActive: boolean;
  pendingApprovalCount: number;
}

export interface IFormFieldDto {
  id: number;
  controlType: 'Text' | 'TextArea' | 'Dropdown' | 'Date' | 'Checkbox' | 'Radio' | 'Number'
    | 'FileUpload' | 'UserPicker' | 'Toggle' | 'Table' | 'Divider';
  label: string;
  bindTo: string | null;
  isRequired: boolean;
  isReadOnly: boolean;
  visibleToRoles: string | null;
  columnWidth: 'Half' | 'Full';
  sortOrder: number;
  optionsJson: string | null;
}

export interface IFormDefinitionDto {
  applicationId: number;
  version: number;
  fields: IFormFieldDto[];
}

export interface IWorkflowStageDto {
  id: number;
  sortOrder: number;
  stageName: string;
  approverRole: string;
  completionRule: 'All' | 'AnyOne' | 'Majority';
  slaHours: number | null;
  allowAmend: boolean;
  amendTargetStageId: number | null;
  parallelGroup: number | null;
}

export interface IWorkflowDefinitionDto {
  applicationId: number;
  version: number;
  stages: IWorkflowStageDto[];
}

export interface IRequestListItemDto {
  id: number;
  requestNumber: string;
  applicationName: string;
  requesterName: string;
  createdOn: string;
  status: 'Draft' | 'InProgress' | 'Approved' | 'Rejected' | 'Returned';
  currentStageName: string | null;
}

export interface IWorkflowStepStatusDto {
  stageName: string;
  approverRoleOrUser: string;
  status: 'Approved' | 'Rejected' | 'Returned' | 'Pending' | 'NotStarted';
  actionedOn: string | null;
}

export interface IAttachmentDto {
  id: number;
  fileName: string;
  sharePointUrl: string;
  sizeBytes: number;
  uploadedByName: string;
  uploadedOn: string;
}

export interface IHistoryItemDto {
  action: string;
  details: string | null;
  performedByName: string;
  performedOn: string;
}

export interface IRequestDetailDto {
  id: number;
  requestNumber: string;
  applicationName: string;
  status: string;
  formDataJson: string;
  form: IFormDefinitionDto;
  workflowSteps: IWorkflowStepStatusDto[];
  attachments: IAttachmentDto[];
  history: IHistoryItemDto[];
}

export interface IDelegationDto {
  id: number;
  delegatorName: string;
  delegateName: string;
  applicationScope: string;
  delegationType: 'TimeBound' | 'Permanent';
  startDate: string | null;
  endDate: string | null;
  isActive: boolean;
}

export interface IRoleDto {
  id: number;
  name: string;
  level: number;
  isCustom: boolean;
  isFlat: boolean;
}

export interface IPermissionMatrixRowDto {
  applicationId: number;
  applicationName: string;
  canCreate: boolean;
  canRead: boolean;
  canUpdate: boolean;
  canDelete: boolean;
  canApprove: boolean;
  dataScope: 'Own' | 'Team' | 'Department' | 'Division' | 'All';
}
