import * as React from 'react';
import * as ReactDom from 'react-dom';
import { Version } from '@microsoft/sp-core-library';
import { IPropertyPaneConfiguration, PropertyPaneTextField } from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';
import { ApplicationHubWebPart as ApplicationHubComponent, IApplicationHubProps } from './ApplicationHub';

export interface IApplicationHubWebPartProps {
  apiBaseUrl: string;
  apiResourceId: string;
}

export default class ApplicationHubWebPart extends BaseClientSideWebPart<IApplicationHubWebPartProps> {
  public render(): void {
    const element: React.ReactElement<IApplicationHubProps> = React.createElement(ApplicationHubComponent, {
      context: this.context,
      apiBaseUrl: this.properties.apiBaseUrl,
      apiResourceId: this.properties.apiResourceId,
      currentUserId: 0,          // resolved server-side from the AAD token on each API call
      currentUserRoleLevel: 6,   // TODO: fetch from /api/users/me once wired up
      isAdmin: true
    });
    ReactDom.render(element, this.domElement);
  }

  protected onDispose(): void {
    ReactDom.unmountComponentAtNode(this.domElement);
  }

  protected get dataVersion(): Version { return Version.parse('1.0'); }

  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return {
      pages: [{
        header: { description: 'Application Hub settings' },
        groups: [{
          groupName: 'API connection',
          groupFields: [
            PropertyPaneTextField('apiBaseUrl', { label: 'API base URL (ApplicationHub.Api)' }),
            PropertyPaneTextField('apiResourceId', { label: 'Azure AD API app (client) ID' })
          ]
        }]
      }]
    };
  }
}
