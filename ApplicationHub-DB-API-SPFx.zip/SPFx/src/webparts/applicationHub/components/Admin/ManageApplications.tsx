import * as React from 'react';
import { useEffect, useState } from 'react';
import { Table, Button, Tag, Space, Modal, Form, Input, Select, message } from 'antd';
import { PlusOutlined, EditOutlined, BranchesOutlined, CopyOutlined } from '@ant-design/icons';
import { ApplicationHubService } from '../../services/ApplicationHubService';
import { IApplicationDto } from '../../models/models';

export interface IManageApplicationsProps {
  service: ApplicationHubService;
  currentUserId: number;
  onEditForm: (app: IApplicationDto) => void;
  onEditWorkflow: (app: IApplicationDto) => void;
}

/** Admin ▸ App Builder ▸ Manage Applications — create, clone, or open any of the 50 applications. */
export const ManageApplications: React.FC<IManageApplicationsProps> = ({ service, currentUserId, onEditForm, onEditWorkflow }) => {
  const [apps, setApps] = useState<IApplicationDto[]>([]);
  const [modalOpen, setModalOpen] = useState(false);
  const [form] = Form.useForm();

  const load = () => service.getApplications(currentUserId).then(setApps);
  useEffect(() => { load(); }, []);

  const createApp = async () => {
    const v = await form.validateFields();
    await service.createApplication(v.name, v.category, v.iconKey ?? 'file');
    message.success(`${v.name} created`);
    setModalOpen(false);
    form.resetFields();
    load();
  };

  const clone = async (app: IApplicationDto) => {
    await service.cloneApplication(app.id, `${app.name} (copy)`);
    message.success('Application cloned with its current form and workflow');
    load();
  };

  const columns = [
    { title: 'Application', dataIndex: 'name', key: 'name', render: (v: string) => <b>{v}</b> },
    { title: 'Category', dataIndex: 'category', key: 'category' },
    { title: 'Status', dataIndex: 'isActive', key: 'isActive',
      render: (v: boolean) => <Tag color={v ? 'green' : 'default'}>{v ? 'Active' : 'Draft'}</Tag> },
    { title: 'Actions', key: 'actions', align: 'right' as const,
      render: (_: unknown, app: IApplicationDto) => (
        <Space>
          <Button size="small" icon={<EditOutlined />} onClick={() => onEditForm(app)}>Form</Button>
          <Button size="small" icon={<BranchesOutlined />} onClick={() => onEditWorkflow(app)}>Workflow</Button>
          <Button size="small" icon={<CopyOutlined />} onClick={() => clone(app)}>Clone</Button>
        </Space>
      ) }
  ];

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 12 }}>
        <h2 style={{ margin: 0 }}>Manage Applications</h2>
        <Button type="primary" icon={<PlusOutlined />} style={{ background: '#CF1322', borderColor: '#CF1322' }}
          onClick={() => setModalOpen(true)}>New Application</Button>
      </div>
      <Table rowKey="id" columns={columns} dataSource={apps} pagination={{ pageSize: 10 }} />

      <Modal title="New Application" open={modalOpen} onOk={createApp} onCancel={() => setModalOpen(false)}>
        <Form form={form} layout="vertical">
          <Form.Item name="name" label="Application Name" rules={[{ required: true }]}>
            <Input placeholder="e.g. Loan Application" />
          </Form.Item>
          <Form.Item name="category" label="Category" rules={[{ required: true }]}>
            <Select options={['HR', 'Finance', 'IT', 'Admin'].map(c => ({ label: c, value: c }))} />
          </Form.Item>
        </Form>
      </Modal>
    </div>
  );
};
