import * as React from 'react';
import { useEffect, useState } from 'react';
import { Row, Col, Card, Button, Switch, Select, Input, message } from 'antd';
import {
  FontSizeOutlined, AlignLeftOutlined, CaretDownOutlined, CalendarOutlined, CheckSquareOutlined,
  BorderOuterOutlined, NumberOutlined, UploadOutlined, UserOutlined, SwapOutlined, TableOutlined, MinusOutlined
} from '@ant-design/icons';
import { ApplicationHubService } from '../../services/ApplicationHubService';
import { IApplicationDto, IFormFieldDto } from '../../models/models';
import { FormRenderer } from '../FormRenderer';

const PALETTE: { type: IFormFieldDto['controlType']; label: string; icon: React.ReactNode }[] = [
  { type: 'Text', label: 'Text Input', icon: <FontSizeOutlined /> },
  { type: 'TextArea', label: 'Text Area', icon: <AlignLeftOutlined /> },
  { type: 'Dropdown', label: 'Dropdown', icon: <CaretDownOutlined /> },
  { type: 'Date', label: 'Date Picker', icon: <CalendarOutlined /> },
  { type: 'Checkbox', label: 'Checkbox', icon: <CheckSquareOutlined /> },
  { type: 'Radio', label: 'Radio Group', icon: <BorderOuterOutlined /> },
  { type: 'Number', label: 'Number', icon: <NumberOutlined /> },
  { type: 'FileUpload', label: 'File Upload', icon: <UploadOutlined /> },
  { type: 'UserPicker', label: 'User Picker', icon: <UserOutlined /> },
  { type: 'Toggle', label: 'Toggle Switch', icon: <SwapOutlined /> },
  { type: 'Table', label: 'Table / Grid', icon: <TableOutlined /> },
  { type: 'Divider', label: 'Section Divider', icon: <MinusOutlined /> }
];

export interface IFormBuilderProps {
  service: ApplicationHubService;
  application: IApplicationDto;
}

/** Admin ▸ App Builder ▸ Form Builder — drag-from-palette canvas with live antd preview + field properties panel. */
export const FormBuilder: React.FC<IFormBuilderProps> = ({ service, application }) => {
  const [fields, setFields] = useState<IFormFieldDto[]>([]);
  const [selectedId, setSelectedId] = useState<number | undefined>(undefined);

  useEffect(() => {
    service.getFormDefinition(application.id).then(def => setFields(def.fields)).catch(() => setFields([]));
  }, [service, application.id]);

  const selected = fields.find(f => f.id === selectedId);

  const addField = (type: IFormFieldDto['controlType']) => {
    const newField: IFormFieldDto = {
      id: -(fields.length + 1), controlType: type, label: `New ${type}`, bindTo: null,
      isRequired: false, isReadOnly: false, visibleToRoles: null, columnWidth: 'Half',
      sortOrder: fields.length + 1, optionsJson: type === 'Dropdown' || type === 'Radio' ? '["Option 1","Option 2"]' : null
    };
    setFields([...fields, newField]);
    setSelectedId(newField.id);
  };

  const updateSelected = (patch: Partial<IFormFieldDto>) => {
    setFields(fields.map(f => (f.id === selectedId ? { ...f, ...patch } : f)));
  };

  const save = async () => {
    await service.saveFormDefinition(application.id, fields);
    message.success('Form saved as a new version');
  };

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 12 }}>
        <h2 style={{ margin: 0 }}>Form Builder — {application.name}</h2>
        <Button type="primary" style={{ background: '#CF1322', borderColor: '#CF1322' }} onClick={save}>Save Form</Button>
      </div>

      <Row gutter={16}>
        <Col span={5}>
          <div style={{ fontSize: 11, fontWeight: 700, color: '#8C8C8C', marginBottom: 8 }}>CONTROLS</div>
          {PALETTE.map(p => (
            <Card key={p.type} size="small" hoverable onClick={() => addField(p.type)}
              style={{ marginBottom: 8, borderRadius: 6 }} bodyStyle={{ padding: 8, display: 'flex', gap: 8, alignItems: 'center' }}>
              <span style={{ color: '#CF1322' }}>{p.icon}</span> {p.label}
            </Card>
          ))}
        </Col>

        <Col span={13}>
          <div style={{ fontSize: 11, fontWeight: 700, color: '#8C8C8C', marginBottom: 8 }}>CANVAS (live preview)</div>
          <Card style={{ minHeight: 500 }}>
            {fields.length === 0
              ? <div style={{ textAlign: 'center', color: '#8C8C8C', padding: 40 }}>Add a control from the palette to begin</div>
              : <FormRenderer fields={fields} values={{}} onChange={() => undefined} designMode />}
            <div style={{ marginTop: 12 }}>
              {fields.map(f => (
                <Button key={f.id} size="small" type={selectedId === f.id ? 'primary' : 'default'}
                  style={selectedId === f.id ? { background: '#CF1322', borderColor: '#CF1322', margin: 4 } : { margin: 4 }}
                  onClick={() => setSelectedId(f.id)}>
                  {f.label}
                </Button>
              ))}
            </div>
          </Card>
        </Col>

        <Col span={6}>
          <div style={{ fontSize: 11, fontWeight: 700, color: '#8C8C8C', marginBottom: 8 }}>FIELD PROPERTIES</div>
          <Card>
            {!selected ? <div style={{ color: '#8C8C8C', fontSize: 12 }}>Select a field on the canvas</div> : (
              <>
                <div style={{ marginBottom: 10 }}>
                  <div style={{ fontSize: 11, color: '#8C8C8C', marginBottom: 4 }}>Label</div>
                  <Input value={selected.label} onChange={e => updateSelected({ label: e.target.value })} />
                </div>
                <div style={{ marginBottom: 10 }}>
                  <div style={{ fontSize: 11, color: '#8C8C8C', marginBottom: 4 }}>Bind To</div>
                  <Input value={selected.bindTo ?? ''} placeholder="CurrentUser.FullName"
                    onChange={e => updateSelected({ bindTo: e.target.value })} />
                </div>
                <div style={{ marginBottom: 10, display: 'flex', justifyContent: 'space-between' }}>
                  <span style={{ fontSize: 12 }}>Required</span>
                  <Switch checked={selected.isRequired} onChange={v => updateSelected({ isRequired: v })} />
                </div>
                <div style={{ marginBottom: 10, display: 'flex', justifyContent: 'space-between' }}>
                  <span style={{ fontSize: 12 }}>Read-only</span>
                  <Switch checked={selected.isReadOnly} onChange={v => updateSelected({ isReadOnly: v })} />
                </div>
                <div style={{ marginBottom: 10 }}>
                  <div style={{ fontSize: 11, color: '#8C8C8C', marginBottom: 4 }}>Column width</div>
                  <Select style={{ width: '100%' }} value={selected.columnWidth}
                    onChange={v => updateSelected({ columnWidth: v })}
                    options={[{ label: 'Half width', value: 'Half' }, { label: 'Full width', value: 'Full' }]} />
                </div>
              </>
            )}
          </Card>
        </Col>
      </Row>
    </div>
  );
};
