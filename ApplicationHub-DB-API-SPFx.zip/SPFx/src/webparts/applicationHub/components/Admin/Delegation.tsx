import * as React from 'react';
import { useEffect, useState } from 'react';
import { Table, Tag, Button, Modal, Form, Select, DatePicker, message } from 'antd';
import { PlusOutlined } from '@ant-design/icons';
import { ApplicationHubService } from '../../services/ApplicationHubService';
import { IDelegationDto } from '../../models/models';

export interface IDelegationProps {
  service: ApplicationHubService;
}

/** Admin ▸ App Builder ▸ Delegation — time-bound or permanent reassignment of approval authority. */
export const DelegationScreen: React.FC<IDelegationProps> = ({ service }) => {
  const [rows, setRows] = useState<IDelegationDto[]>([]);
  const [open, setOpen] = useState(false);
  const [form] = Form.useForm();

  const load = () => service.getDelegations().then(setRows);
  useEffect(() => { load(); }, []);

  const create = async () => {
    const v = await form.validateFields();
    await service.createDelegation(v.delegatorId, v.delegateId, v.scope ?? 'ALL', v.type,
      v.range?.[0]?.format('YYYY-MM-DD'), v.range?.[1]?.format('YYYY-MM-DD'));
    message.success('Delegation created');
    setOpen(false); form.resetFields(); load();
  };

  const columns = [
    { title: 'Delegator', dataIndex: 'delegatorName', key: 'delegatorName' },
    { title: 'Delegate', dataIndex: 'delegateName', key: 'delegateName' },
    { title: 'Applications', dataIndex: 'applicationScope', key: 'applicationScope' },
    { title: 'Type', dataIndex: 'delegationType', key: 'delegationType',
      render: (v: string) => <Tag color={v === 'Permanent' ? 'gold' : 'blue'}>{v}</Tag> },
    { title: 'Duration', key: 'duration',
      render: (_: unknown, r: IDelegationDto) => r.startDate ? `${r.startDate} – ${r.endDate}` : 'Ongoing' },
    { title: 'Status', dataIndex: 'isActive', key: 'isActive',
      render: (v: boolean) => <Tag color={v ? 'green' : 'red'}>{v ? 'Active' : 'Expired'}</Tag> }
  ];

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 12 }}>
        <h2 style={{ margin: 0 }}>Delegation</h2>
        <Button type="primary" icon={<PlusOutlined />} style={{ background: '#CF1322', borderColor: '#CF1322' }}
          onClick={() => setOpen(true)}>New Delegation</Button>
      </div>
      <Table rowKey="id" columns={columns} dataSource={rows} pagination={{ pageSize: 10 }} />

      <Modal title="New Delegation" open={open} onOk={create} onCancel={() => setOpen(false)}>
        <Form form={form} layout="vertical">
          <Form.Item name="delegatorId" label="Delegator" rules={[{ required: true }]}>
            <Select placeholder="Select user" options={[]} />
          </Form.Item>
          <Form.Item name="delegateId" label="Delegate to" rules={[{ required: true }]}>
            <Select placeholder="Select user" options={[]} />
          </Form.Item>
          <Form.Item name="type" label="Type" rules={[{ required: true }]} initialValue="TimeBound">
            <Select options={[{ label: 'Time-bound', value: 'TimeBound' }, { label: 'Permanent', value: 'Permanent' }]} />
          </Form.Item>
          <Form.Item name="range" label="Date range (time-bound only)">
            <DatePicker.RangePicker style={{ width: '100%' }} />
          </Form.Item>
        </Form>
      </Modal>
    </div>
  );
};
