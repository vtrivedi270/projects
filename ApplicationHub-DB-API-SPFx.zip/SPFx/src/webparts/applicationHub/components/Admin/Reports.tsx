import * as React from 'react';
import { useState } from 'react';
import { Card, Row, Col, Select, DatePicker, Button, Table, message } from 'antd';
import { ApplicationHubService } from '../../services/ApplicationHubService';
import { IApplicationDto } from '../../models/models';

export interface IReportsProps {
  service: ApplicationHubService;
  applications: IApplicationDto[];
}

/** Admin ▸ App Builder ▸ Reports — volume, average turnaround, and SLA breaches per application. */
export const Reports: React.FC<IReportsProps> = ({ service, applications }) => {
  const [applicationId, setApplicationId] = useState<number | undefined>(undefined);
  const [range, setRange] = useState<[string, string] | undefined>(undefined);
  const [rows, setRows] = useState<{ applicationName: string; volume: number; avgApprovalHours: number; slaBreaches: number }[]>([]);

  const generate = async () => {
    if (!range) { message.warning('Choose a date range'); return; }
    const result = await service.generateReport(applicationId ?? null, range[0], range[1],
      ['Volume', 'AvgApprovalTime', 'SlaBreaches'], 'PDF');
    setRows(result as unknown as typeof rows);
  };

  const columns = [
    { title: 'Application', dataIndex: 'applicationName', key: 'applicationName' },
    { title: 'Volume', dataIndex: 'volume', key: 'volume' },
    { title: 'Avg. approval time (hrs)', dataIndex: 'avgApprovalHours', key: 'avgApprovalHours',
      render: (v: number) => v.toFixed(1) },
    { title: 'SLA breaches', dataIndex: 'slaBreaches', key: 'slaBreaches' }
  ];

  return (
    <div>
      <h2 style={{ marginTop: 0 }}>Reports</h2>
      <Row gutter={16}>
        <Col span={10}>
          <Card title="Report builder" size="small">
            <div style={{ marginBottom: 12 }}>
              <div style={{ fontSize: 12, color: '#8C8C8C', marginBottom: 4 }}>Application</div>
              <Select style={{ width: '100%' }} allowClear placeholder="All Applications" value={applicationId}
                onChange={setApplicationId} options={applications.map(a => ({ label: a.name, value: a.id }))} />
            </div>
            <div style={{ marginBottom: 12 }}>
              <div style={{ fontSize: 12, color: '#8C8C8C', marginBottom: 4 }}>Date range</div>
              <DatePicker.RangePicker style={{ width: '100%' }}
                onChange={dates => setRange(dates ? [dates[0]!.format('YYYY-MM-DD'), dates[1]!.format('YYYY-MM-DD')] : undefined)} />
            </div>
            <Button type="primary" style={{ background: '#CF1322', borderColor: '#CF1322' }} onClick={generate}>
              Generate Report
            </Button>
          </Card>
        </Col>
        <Col span={14}>
          <Card title="Results" size="small">
            <Table rowKey="applicationName" columns={columns} dataSource={rows} pagination={false} size="small" />
          </Card>
        </Col>
      </Row>
    </div>
  );
};
