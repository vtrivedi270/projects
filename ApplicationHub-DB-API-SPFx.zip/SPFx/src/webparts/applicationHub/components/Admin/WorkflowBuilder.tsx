import * as React from 'react';
import { useEffect, useState } from 'react';
import { Card, Button, Select, Input, InputNumber, Switch, Space, message, Tag } from 'antd';
import { PlusOutlined, ArrowRightOutlined } from '@ant-design/icons';
import { ApplicationHubService } from '../../services/ApplicationHubService';
import { IApplicationDto, IWorkflowStageDto, IRoleDto } from '../../models/models';

export interface IWorkflowBuilderProps {
  service: ApplicationHubService;
  application: IApplicationDto;
}

/** Admin ▸ App Builder ▸ Workflow Builder — ordered stages with approver role, completion rule, SLA and amend target. */
export const WorkflowBuilder: React.FC<IWorkflowBuilderProps> = ({ service, application }) => {
  const [stages, setStages] = useState<IWorkflowStageDto[]>([]);
  const [roles, setRoles] = useState<IRoleDto[]>([]);

  useEffect(() => {
    service.getWorkflowDefinition(application.id).then(def => setStages(def.stages)).catch(() => setStages([]));
    service.getRoleHierarchy().then(setRoles);
  }, [service, application.id]);

  const addStage = () => {
    const newStage: IWorkflowStageDto = {
      id: -(stages.length + 1), sortOrder: stages.length + 1, stageName: `Stage ${stages.length + 1}`,
      approverRole: roles[0]?.name ?? 'Employee', completionRule: 'AnyOne', slaHours: 48,
      allowAmend: false, amendTargetStageId: null, parallelGroup: null
    };
    setStages([...stages, newStage]);
  };

  const update = (id: number, patch: Partial<IWorkflowStageDto>) =>
    setStages(stages.map(s => (s.id === id ? { ...s, ...patch } : s)));

  const publish = async () => {
    await service.saveWorkflowDefinition(application.id, stages);
    message.success('Workflow published as a new version');
  };

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 12 }}>
        <div>
          <h2 style={{ margin: 0 }}>Workflow Builder — {application.name}</h2>
          <span style={{ color: '#8C8C8C', fontSize: 13 }}>In-flight requests keep running on their original version</span>
        </div>
        <Space>
          <Button icon={<PlusOutlined />} onClick={addStage}>Add Stage</Button>
          <Button type="primary" style={{ background: '#CF1322', borderColor: '#CF1322' }} onClick={publish}>
            Publish Version
          </Button>
        </Space>
      </div>

      <div style={{ display: 'flex', alignItems: 'center', overflowX: 'auto', padding: '20px 4px', gap: 4 }}>
        <Tag color="green" style={{ padding: '10px 14px', borderRadius: 8 }}>Submitted</Tag>
        {stages.sort((a, b) => a.sortOrder - b.sortOrder).map(stage => (
          <React.Fragment key={stage.id}>
            <ArrowRightOutlined style={{ color: '#D9D9D9' }} />
            <Card size="small" style={{ minWidth: 220 }}
              title={<Input size="small" bordered={false} value={stage.stageName}
                onChange={e => update(stage.id, { stageName: e.target.value })} />}>
              <div style={{ marginBottom: 8 }}>
                <div style={{ fontSize: 11, color: '#8C8C8C' }}>Approver role</div>
                <Select size="small" style={{ width: '100%' }} value={stage.approverRole}
                  onChange={v => update(stage.id, { approverRole: v })}
                  options={roles.map(r => ({ label: r.name, value: r.name }))} />
              </div>
              <div style={{ marginBottom: 8 }}>
                <div style={{ fontSize: 11, color: '#8C8C8C' }}>Completion rule</div>
                <Select size="small" style={{ width: '100%' }} value={stage.completionRule}
                  onChange={v => update(stage.id, { completionRule: v })}
                  options={[{ label: 'Any One', value: 'AnyOne' }, { label: 'All', value: 'All' }, { label: 'Majority', value: 'Majority' }]} />
              </div>
              <div style={{ marginBottom: 8 }}>
                <div style={{ fontSize: 11, color: '#8C8C8C' }}>SLA (hours)</div>
                <InputNumber size="small" style={{ width: '100%' }} value={stage.slaHours ?? undefined}
                  onChange={v => update(stage.id, { slaHours: v })} />
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                <span style={{ fontSize: 12 }}>Allow amend</span>
                <Switch size="small" checked={stage.allowAmend} onChange={v => update(stage.id, { allowAmend: v })} />
              </div>
            </Card>
          </React.Fragment>
        ))}
        <ArrowRightOutlined style={{ color: '#D9D9D9' }} />
        <Tag color="red" style={{ padding: '10px 14px', borderRadius: 8 }}>Approved</Tag>
      </div>
    </div>
  );
};
