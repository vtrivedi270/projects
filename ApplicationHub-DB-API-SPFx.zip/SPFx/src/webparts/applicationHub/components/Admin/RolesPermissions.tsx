import * as React from 'react';
import { useEffect, useState } from 'react';
import { Row, Col, Card, List, Select, Checkbox, Button, message, Tag } from 'antd';
import { ApplicationHubService } from '../../services/ApplicationHubService';
import { IRoleDto, IApplicationDto, IPermissionMatrixRowDto } from '../../models/models';

export interface IRolesPermissionsProps {
  service: ApplicationHubService;
}

const HIERARCHY_DESC: Record<string, string> = {
  'Super Admin': 'Full system access · maker-checker on mutations',
  Admin: 'App Builder configuration',
  'Division Head': 'Approves across division · data scope: Division',
  'Department Head': 'Approves within department · data scope: Department',
  'Reporting Manager': 'Approves direct reports · data scope: Team',
  Employee: 'Raises requests · data scope: Own'
};

/** Admin ▸ App Builder ▸ Roles & Permissions — hierarchy view + per-role CRUD/Approve matrix across all applications. */
export const RolesPermissions: React.FC<IRolesPermissionsProps> = ({ service }) => {
  const [roles, setRoles] = useState<IRoleDto[]>([]);
  const [apps, setApps] = useState<IApplicationDto[]>([]);
  const [selectedRoleId, setSelectedRoleId] = useState<number | undefined>(undefined);
  const [rows, setRows] = useState<IPermissionMatrixRowDto[]>([]);

  useEffect(() => {
    service.getRoleHierarchy().then(r => { setRoles(r); setSelectedRoleId(r[0]?.id); });
    service.getApplications(0).then(setApps);
  }, [service]);

  useEffect(() => {
    if (!selectedRoleId) return;
    setRows(apps.map(a => ({
      applicationId: a.id, applicationName: a.name, canCreate: false, canRead: true,
      canUpdate: false, canDelete: false, canApprove: false, dataScope: 'Own'
    })));
  }, [selectedRoleId, apps]);

  const toggle = (appId: number, key: keyof IPermissionMatrixRowDto) =>
    setRows(rows.map(r => (r.applicationId === appId ? { ...r, [key]: !r[key] } : r)));

  const save = async () => {
    if (!selectedRoleId) return;
    await service.savePermissionMatrix(selectedRoleId, rows);
    message.success('Permissions saved');
  };

  return (
    <div>
      <h2 style={{ marginTop: 0 }}>Roles &amp; Permissions</h2>
      <Row gutter={16} style={{ marginBottom: 16 }}>
        <Col span={12}>
          <Card title="Organizational hierarchy" size="small">
            <List size="small" dataSource={roles.filter(r => !r.isFlat && !r.isCustom).sort((a, b) => a.level - b.level)}
              renderItem={r => (
                <List.Item>
                  <List.Item.Meta
                    avatar={<div style={{
                      width: 24, height: 24, borderRadius: 12, background: '#CF1322', color: '#fff',
                      fontSize: 11, display: 'flex', alignItems: 'center', justifyContent: 'center'
                    }}>{r.level}</div>}
                    title={r.name} description={HIERARCHY_DESC[r.name] ?? ''} />
                </List.Item>
              )} />
          </Card>
        </Col>
        <Col span={12}>
          <Card title="Custom roles" size="small">
            <List size="small" dataSource={roles.filter(r => r.isCustom)} renderItem={r => (
              <List.Item extra={<Tag color="green">Active</Tag>}>
                {r.name} <span style={{ color: '#8C8C8C', fontSize: 11 }}>· level {r.level}{r.isFlat ? ', standalone' : ''}</span>
              </List.Item>
            )} />
          </Card>
        </Col>
      </Row>

      <Card title={
        <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
          Module permissions —
          <Select size="small" style={{ width: 220 }} value={selectedRoleId} onChange={setSelectedRoleId}
            options={roles.map(r => ({ label: r.name, value: r.id }))} />
        </div>
      } extra={<Button type="primary" size="small" style={{ background: '#CF1322', borderColor: '#CF1322' }} onClick={save}>Save</Button>}>
        <table style={{ width: '100%', fontSize: 13 }}>
          <thead>
            <tr style={{ color: '#8C8C8C', fontSize: 11 }}>
              <th style={{ textAlign: 'left' }}>Application</th>
              <th>Create</th><th>Read</th><th>Update</th><th>Delete</th><th>Approve</th>
            </tr>
          </thead>
          <tbody>
            {rows.map(r => (
              <tr key={r.applicationId} style={{ borderTop: '1px solid #F0F0F0' }}>
                <td style={{ padding: '8px 0' }}>{r.applicationName}</td>
                {(['canCreate', 'canRead', 'canUpdate', 'canDelete', 'canApprove'] as const).map(k => (
                  <td key={k} style={{ textAlign: 'center' }}>
                    <Checkbox checked={r[k] as boolean} onChange={() => toggle(r.applicationId, k)} />
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </Card>
    </div>
  );
};
