import * as React from 'react';
import { useEffect, useState } from 'react';
import { Tabs, Steps, Upload, Button, List, Tag, Skeleton, Space, message } from 'antd';
import { UploadOutlined, FileOutlined, CheckOutlined, CloseOutlined, RollbackOutlined } from '@ant-design/icons';
import { ApplicationHubService } from '../../services/ApplicationHubService';
import { IRequestDetailDto } from '../../models/models';
import { FormRenderer } from '../FormRenderer';

const STEP_STATUS: Record<string, 'wait' | 'process' | 'finish' | 'error'> = {
  NotStarted: 'wait', Pending: 'process', Approved: 'finish', Rejected: 'error', Returned: 'error'
};

export interface IRecordDetailProps {
  service: ApplicationHubService;
  requestId: number;
  currentUserId: number;
  canApprove: boolean;
  onBack: () => void;
}

/** Record detail screen: Entry Form / Attachment / History / Workflow, matching the approved preview. */
export const RecordDetail: React.FC<IRecordDetailProps> = ({ service, requestId, currentUserId, canApprove, onBack }) => {
  const [detail, setDetail] = useState<IRequestDetailDto | undefined>(undefined);
  const [values, setValues] = useState<Record<string, unknown>>({});

  const reload = () => service.getRequestDetail(requestId).then(d => {
    setDetail(d);
    setValues(JSON.parse(d.formDataJson || '{}'));
  });

  useEffect(() => { reload(); }, [requestId]);

  if (!detail) return <Skeleton active paragraph={{ rows: 8 }} />;

  const act = async (kind: 'approve' | 'reject' | 'return') => {
    const fn = kind === 'approve' ? service.approveRequest : kind === 'reject' ? service.rejectRequest : service.returnRequest;
    await fn.call(service, requestId, currentUserId);
    message.success(`Request ${kind === 'approve' ? 'approved' : kind === 'reject' ? 'rejected' : 'returned for amendment'}`);
    reload();
  };

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
        <Space>
          <Button onClick={onBack}>Back</Button>
          <h2 style={{ margin: 0 }}>{detail.applicationName}</h2>
          <Tag>{detail.requestNumber}</Tag>
          <Tag color="blue">{detail.status}</Tag>
        </Space>
        {canApprove && detail.status === 'InProgress' && (
          <Space>
            <Button icon={<RollbackOutlined />} onClick={() => act('return')}>Return</Button>
            <Button danger icon={<CloseOutlined />} onClick={() => act('reject')}>Reject</Button>
            <Button type="primary" icon={<CheckOutlined />} style={{ background: '#CF1322', borderColor: '#CF1322' }}
              onClick={() => act('approve')}>Approve</Button>
          </Space>
        )}
      </div>

      <Tabs
        items={[
          {
            key: 'entry', label: 'Entry Form',
            children: <FormRenderer fields={detail.form.fields} values={values} onChange={(k, v) => setValues({ ...values, [k]: v })} />
          },
          {
            key: 'attach', label: `Attachments (${detail.attachments.length})`,
            children: (
              <>
                <Upload beforeUpload={file => {
                  service.uploadAttachment(requestId, currentUserId, file as unknown as File).then(reload);
                  return false;
                }}>
                  <Button icon={<UploadOutlined />}>Upload file</Button>
                </Upload>
                <List style={{ marginTop: 12 }} dataSource={detail.attachments} renderItem={a => (
                  <List.Item>
                    <List.Item.Meta avatar={<FileOutlined style={{ color: '#CF1322' }} />}
                      title={a.fileName}
                      description={`${(a.sizeBytes / 1024).toFixed(0)} KB · uploaded by ${a.uploadedByName}`} />
                  </List.Item>
                )} />
              </>
            )
          },
          {
            key: 'history', label: 'History',
            children: (
              <List dataSource={detail.history} renderItem={h => (
                <List.Item>
                  <List.Item.Meta title={<><b>{h.performedByName}</b> — {h.action}</>}
                    description={`${h.details ?? ''} · ${new Date(h.performedOn).toLocaleString()}`} />
                </List.Item>
              )} />
            )
          },
          {
            key: 'workflow', label: 'Workflow',
            children: (
              <Steps direction="vertical" size="small" items={detail.workflowSteps.map(s => ({
                title: s.stageName,
                description: `${s.approverRoleOrUser}${s.actionedOn ? ' · ' + new Date(s.actionedOn).toLocaleString() : ''}`,
                status: STEP_STATUS[s.status]
              }))} />
            )
          }
        ]}
      />
    </div>
  );
};
