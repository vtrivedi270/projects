import * as React from 'react';
import { useEffect, useState } from 'react';
import { Row, Col, Card, Badge, Skeleton, Typography, Tag } from 'antd';
import {
  FileTextOutlined, AppstoreOutlined, TeamOutlined, CalendarOutlined, UploadOutlined
} from '@ant-design/icons';
import { ApplicationHubService } from '../../services/ApplicationHubService';
import { IApplicationDto } from '../../models/models';

const { Title, Text } = Typography;

const ICONS: Record<string, React.ReactNode> = {
  file: <FileTextOutlined />, layers: <AppstoreOutlined />, users: <TeamOutlined />,
  calendar: <CalendarOutlined />, upload: <UploadOutlined />
};

export interface IDashboardProps {
  service: ApplicationHubService;
  currentUserId: number;
  onOpenApplication: (app: IApplicationDto) => void;
}

/** Main Dashboard — all configured applications as tiles, each badged with the caller's pending approvals. */
export const Dashboard: React.FC<IDashboardProps> = ({ service, currentUserId, onOpenApplication }) => {
  const [apps, setApps] = useState<IApplicationDto[] | undefined>(undefined);
  const [category, setCategory] = useState<string>('All');

  useEffect(() => {
    service.getApplications(currentUserId).then(setApps).catch(() => setApps([]));
  }, [service, currentUserId]);

  if (!apps) return <Skeleton active paragraph={{ rows: 6 }} />;

  const categories = ['All', ...Array.from(new Set(apps.map(a => a.category)))];
  const visible = category === 'All' ? apps : apps.filter(a => a.category === category);
  const totalPending = apps.reduce((sum, a) => sum + a.pendingApprovalCount, 0);

  return (
    <div>
      <Title level={4} style={{ marginBottom: 4 }}>Welcome back</Title>
      <Text type="secondary">{apps.length} applications configured · {totalPending} pending your approval</Text>

      <div style={{ margin: '18px 0 14px' }}>
        {categories.map(c => (
          <Tag.CheckableTag key={c} checked={category === c} onChange={() => setCategory(c)}
            style={{ borderColor: '#CF1322' }}>
            {c}
          </Tag.CheckableTag>
        ))}
      </div>

      <Row gutter={[14, 14]}>
        {visible.map(app => (
          <Col xs={12} sm={8} md={6} lg={4} key={app.id}>
            <Badge count={app.pendingApprovalCount} offset={[-10, 10]} color="#CF1322">
              <Card hoverable onClick={() => onOpenApplication(app)}
                style={{ borderRadius: 8, textAlign: 'left' }} bodyStyle={{ padding: 14 }}>
                <div style={{
                  width: 36, height: 36, borderRadius: 8, background: '#FFF1F0', color: '#CF1322',
                  display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 18, marginBottom: 10
                }}>
                  {ICONS[app.iconKey] ?? <FileTextOutlined />}
                </div>
                <div style={{ fontWeight: 600, fontSize: 13 }}>{app.name}</div>
                <div style={{ fontSize: 11, color: '#8C8C8C' }}>{app.category}</div>
              </Card>
            </Badge>
          </Col>
        ))}
      </Row>
    </div>
  );
};
