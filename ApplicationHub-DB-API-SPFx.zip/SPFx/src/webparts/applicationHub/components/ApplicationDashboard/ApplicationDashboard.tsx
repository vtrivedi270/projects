import * as React from 'react';
import { useEffect, useState, useCallback } from 'react';
import { Tabs, Table, Tag, Button, Space, Tooltip } from 'antd';
import { EyeOutlined, EditOutlined, DeleteOutlined, FilePdfOutlined, PlusOutlined } from '@ant-design/icons';
import { ApplicationHubService } from '../../services/ApplicationHubService';
import { IApplicationDto, IRequestListItemDto } from '../../models/models';

const STATUS_COLOR: Record<string, string> = {
  InProgress: 'blue', Approved: 'green', Rejected: 'red', Returned: 'gold', Draft: 'default'
};

export interface IApplicationDashboardProps {
  service: ApplicationHubService;
  application: IApplicationDto;
  currentUserId: number;
  currentUserRoleLevel: number;
  onOpenRequest: (id: number) => void;
  onNewRequest: () => void;
}

/** Per-application dashboard: My Request / My Approval / All Request, each backed by its own endpoint. */
export const ApplicationDashboard: React.FC<IApplicationDashboardProps> = ({
  service, application, currentUserId, currentUserRoleLevel, onOpenRequest, onNewRequest
}) => {
  const [activeTab, setActiveTab] = useState('mine');
  const [rows, setRows] = useState<IRequestListItemDto[]>([]);
  const [loading, setLoading] = useState(false);

  const load = useCallback(() => {
    setLoading(true);
    const call = activeTab === 'mine'
      ? service.getMyRequests(currentUserId, application.id)
      : activeTab === 'approvals'
        ? service.getMyApprovals(currentUserId, currentUserRoleLevel, application.id)
        : service.getAllRequests(application.id);
    call.then(setRows).finally(() => setLoading(false));
  }, [service, activeTab, currentUserId, currentUserRoleLevel, application.id]);

  useEffect(() => { load(); }, [load]);

  const columns = [
    { title: 'Request', dataIndex: 'requestNumber', key: 'requestNumber',
      render: (v: string) => <b>{v}</b> },
    { title: 'Requester', dataIndex: 'requesterName', key: 'requesterName' },
    { title: 'Submitted', dataIndex: 'createdOn', key: 'createdOn',
      render: (v: string) => new Date(v).toLocaleDateString() },
    { title: 'Stage', dataIndex: 'currentStageName', key: 'currentStageName',
      render: (v: string | null) => v ?? '—' },
    { title: 'Status', dataIndex: 'status', key: 'status',
      render: (v: string) => <Tag color={STATUS_COLOR[v]}>{v}</Tag> },
    { title: 'Actions', key: 'actions', align: 'right' as const,
      render: (_: unknown, r: IRequestListItemDto) => (
        <Space>
          <Tooltip title="View"><Button size="small" icon={<EyeOutlined />} onClick={() => onOpenRequest(r.id)} /></Tooltip>
          <Tooltip title="Edit"><Button size="small" icon={<EditOutlined />} onClick={() => onOpenRequest(r.id)} /></Tooltip>
          <Tooltip title="Export PDF"><Button size="small" icon={<FilePdfOutlined />} /></Tooltip>
          <Tooltip title="Delete"><Button size="small" danger icon={<DeleteOutlined />} /></Tooltip>
        </Space>
      ) }
  ];

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', marginBottom: 12 }}>
        <div>
          <h2 style={{ margin: 0 }}>{application.name}</h2>
          <span style={{ color: '#8C8C8C', fontSize: 13 }}>{application.category}</span>
        </div>
        <Button type="primary" icon={<PlusOutlined />} style={{ background: '#CF1322', borderColor: '#CF1322' }}
          onClick={onNewRequest}>
          New Request
        </Button>
      </div>

      <Tabs
        activeKey={activeTab}
        onChange={setActiveTab}
        items={[
          { key: 'mine', label: 'My Requests' },
          { key: 'approvals', label: 'My Approvals' },
          { key: 'all', label: 'All Requests' }
        ]}
      />
      <Table rowKey="id" columns={columns} dataSource={rows} loading={loading} pagination={{ pageSize: 10 }} />
    </div>
  );
};
