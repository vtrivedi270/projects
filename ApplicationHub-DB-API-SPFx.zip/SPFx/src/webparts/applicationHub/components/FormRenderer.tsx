import * as React from 'react';
import { Form, Input, Select, DatePicker, Radio, Checkbox, InputNumber, Upload, Switch, Row, Col, Divider, Button } from 'antd';
import { UploadOutlined, UserOutlined } from '@ant-design/icons';
import { IFormFieldDto } from '../models/models';

const { TextArea } = Input;

export interface IFormRendererProps {
  fields: IFormFieldDto[];
  /** current field values, keyed by BindTo; entry-form mode reads/writes this */
  values: Record<string, unknown>;
  onChange: (bindTo: string, value: unknown) => void;
  /** true while rendering inside the Form Builder canvas preview — disables input, shows structure only */
  designMode?: boolean;
}

/**
 * Renders any application's Entry Form from its metadata-driven FormField list.
 * The same component backs both the live Entry Form tab and the Form Builder's live preview,
 * so what admins design in App Builder is exactly what employees fill in.
 */
export const FormRenderer: React.FC<IFormRendererProps> = ({ fields, values, onChange, designMode }) => {
  const colSpan = (w: string) => (w === 'Full' ? 24 : 12);

  const renderControl = (f: IFormFieldDto) => {
    const commonProps = { disabled: f.isReadOnly || designMode, style: { width: '100%' } };
    const value = values[f.bindTo ?? f.label];
    const options: string[] = f.optionsJson ? JSON.parse(f.optionsJson) : [];

    switch (f.controlType) {
      case 'Text':
        return <Input {...commonProps} value={value as string} onChange={e => onChange(f.bindTo ?? f.label, e.target.value)} />;
      case 'TextArea':
        return <TextArea {...commonProps} rows={3} value={value as string} onChange={e => onChange(f.bindTo ?? f.label, e.target.value)} />;
      case 'Number':
        return <InputNumber {...commonProps} value={value as number} onChange={v => onChange(f.bindTo ?? f.label, v)} />;
      case 'Dropdown':
        return (
          <Select {...commonProps} value={value as string} onChange={v => onChange(f.bindTo ?? f.label, v)}
            options={options.map(o => ({ label: o, value: o }))} placeholder={`Choose ${f.label.toLowerCase()}`} />
        );
      case 'Date':
        return <DatePicker {...commonProps} value={value as any} onChange={d => onChange(f.bindTo ?? f.label, d)} />;
      case 'Radio':
        return (
          <Radio.Group disabled={f.isReadOnly || designMode} value={value as string}
            onChange={e => onChange(f.bindTo ?? f.label, e.target.value)}>
            {options.map(o => <Radio key={o} value={o}>{o}</Radio>)}
          </Radio.Group>
        );
      case 'Checkbox':
        return <Checkbox disabled={f.isReadOnly || designMode} checked={value as boolean}
          onChange={e => onChange(f.bindTo ?? f.label, e.target.checked)}>{f.label}</Checkbox>;
      case 'Toggle':
        return <Switch disabled={f.isReadOnly || designMode} checked={value as boolean}
          onChange={v => onChange(f.bindTo ?? f.label, v)} />;
      case 'FileUpload':
        return <Upload disabled={designMode} beforeUpload={() => false}
          onChange={info => onChange(f.bindTo ?? f.label, info.fileList)}>
          <Button icon={<UploadOutlined />} disabled={designMode}>Select file</Button>
        </Upload>;
      case 'UserPicker':
        return <Select {...commonProps} value={value as string} onChange={v => onChange(f.bindTo ?? f.label, v)}
          suffixIcon={<UserOutlined />} placeholder="Search employee" showSearch options={[]} />;
      case 'Table':
        return <div style={{ border: '1px dashed #D9D9D9', borderRadius: 6, padding: 12, color: '#8C8C8C', fontSize: 12 }}>
          Repeating grid — configured columns render here at runtime
        </div>;
      case 'Divider':
        return <Divider style={{ margin: '4px 0' }} />;
      default:
        return <Input {...commonProps} />;
    }
  };

  return (
    <Form layout="vertical">
      <Row gutter={16}>
        {fields.sort((a, b) => a.sortOrder - b.sortOrder).map(f => (
          f.controlType === 'Divider'
            ? <Col span={24} key={f.id}>{renderControl(f)}</Col>
            : f.controlType === 'Checkbox'
              ? <Col span={colSpan(f.columnWidth)} key={f.id}><Form.Item>{renderControl(f)}</Form.Item></Col>
              : (
                <Col span={colSpan(f.columnWidth)} key={f.id}>
                  <Form.Item label={<>{f.label}{f.isRequired && <span style={{ color: '#CF1322' }}> *</span>}</>}>
                    {renderControl(f)}
                  </Form.Item>
                </Col>
              )
        ))}
      </Row>
    </Form>
  );
};
