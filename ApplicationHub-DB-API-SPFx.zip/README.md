# Application Hub — Database, API & SPFx Solution

Implements the Application Hub module (the 50-app dashboard, App Builder admin
screens) previewed and approved earlier in this session, on top of the existing
BPM platform's Role/Permission foundation.

## Structure

```
Database/schema.sql            SQL Server schema + seed data (Leave Request fully wired as the reference app)
Backend/                       .NET 8 Clean Architecture solution — ApplicationHub.sln
  src/ApplicationHub.Domain            Entities & enums (Application, FormField, WorkflowStage, Request, ...)
  src/ApplicationHub.Application       CQRS commands/queries (MediatR) per feature area
  src/ApplicationHub.Infrastructure    EF Core DbContext + Fluent configurations
  src/ApplicationHub.Api               Controllers + Program.cs (Swagger, CORS for SharePoint, AAD-ready)
SPFx/src/webparts/applicationHub       React + TypeScript + antd web part
  ApplicationHub.tsx                   Root shell: red ConfigProvider theme, left nav across every screen
  components/Dashboard                 Main Dashboard — app tiles with approval-count badges
  components/ApplicationDashboard      My Request / My Approval / All Request tabs + table
  components/RecordDetail              Entry Form / Attachment / History / Workflow tabs
  components/FormRenderer.tsx          Shared metadata-driven control renderer (Form Builder preview + live entry form)
  components/Admin/*                   Manage Applications, Form Builder, Workflow Builder, Roles & Permissions, Delegation, Reports
  services/ApplicationHubService.ts    Typed client for every API endpoint (AadHttpClient)
```

## Design notes

- **Metadata-driven, not per-app tables.** `Applications` + `FormDefinitions`/`FormFields` +
  `WorkflowDefinitions`/`WorkflowStages` describe all 50 apps. Adding app #51 is a data
  change (via Admin ▸ Manage Applications), never a schema or code change.
- **Versioned form & workflow definitions.** Saving in Form Builder / Workflow Builder
  creates a new immutable version and activates it; in-flight `Requests` keep their
  original `FormDefinitionId`/`WorkflowDefinitionId`, so history never changes underfoot.
- **One workflow engine.** `ActOnRequestCommand` is the single Approve/Reject/Return
  codepath, evaluating each stage's `CompletionRule` (All / AnyOne / Majority) before
  advancing — used by every one of the 50 apps.
- **Attachments** upload through `AttachmentsController` to the application's own
  SharePoint library (`Application.SharePointLibraryName`), matching "separate library
  per app" from the requirements.
- **Roles/Permissions/Delegation** reuse the platform-wide hierarchy already recorded for
  this project (Super Admin → Admin → Division Head → Department Head → Reporting
  Manager → Employee, plus custom roles); `Permissions` here adds the per-application
  CRUD+Approve+DataScope matrix specific to Application Hub.

## Wiring it up (next steps)

1. Run `Database/schema.sql` against a SQL Server instance.
2. `dotnet build Backend/ApplicationHub.sln`, set the connection string in
   `appsettings.json`, register the API in Azure AD (App Registration + expose an API scope).
3. In SPFx: `npm install` inside `SPFx/`, set `apiBaseUrl` and `apiResourceId` in the
   web part's property pane, `gulp serve` to test in the SharePoint Workbench.
4. Wire `ApplicationHubWebPart.ts`'s placeholder `currentUserId` / `currentUserRoleLevel`
   to a real `/api/users/me` call resolved from the AAD token (stubbed for now).
