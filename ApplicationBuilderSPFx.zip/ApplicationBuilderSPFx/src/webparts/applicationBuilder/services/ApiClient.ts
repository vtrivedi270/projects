import { AadHttpClient, HttpClientResponse } from '@microsoft/sp-http';
import { WebPartContext } from '@microsoft/sp-webpart-base';

export class ApiClient {
  private clientPromise: Promise<AadHttpClient>;
  constructor(private context: WebPartContext, private baseUrl: string) {
    this.clientPromise = context.aadHttpClientFactory.getClient(baseUrl);
  }
  private url(path: string): string { return `${this.baseUrl.replace(/\\/$/, '')}${path}`; }
  async get<T>(path: string): Promise<T> { const c = await this.clientPromise; const r = await c.get(this.url(path), AadHttpClient.configurations.v1); return this.parse<T>(r); }
  async post<T>(path: string, body: any): Promise<T> { const c = await this.clientPromise; const r = await c.post(this.url(path), AadHttpClient.configurations.v1, { headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) }); return this.parse<T>(r); }
  async put<T>(path: string, body: any): Promise<T> { const c = await this.clientPromise; const r = await c.fetch(this.url(path), AadHttpClient.configurations.v1, { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) }); return this.parse<T>(r); }
  async delete<T = any>(path: string): Promise<T> { const c = await this.clientPromise; const r = await c.fetch(this.url(path), AadHttpClient.configurations.v1, { method: 'DELETE' }); return this.parse<T>(r); }
  private async parse<T>(r: HttpClientResponse): Promise<T> { if (!r.ok) throw new Error(`${r.status} ${r.statusText}: ${await r.text()}`); if (r.status === 204) return undefined as T; return r.json(); }
}
