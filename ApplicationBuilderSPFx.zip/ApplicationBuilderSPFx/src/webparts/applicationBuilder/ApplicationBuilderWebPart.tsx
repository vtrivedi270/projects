import * as React from 'react';
import * as ReactDom from 'react-dom';
import { Version } from '@microsoft/sp-core-library';
import { IPropertyPaneConfiguration, PropertyPaneTextField } from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';
import { ApplicationBuilder } from './components/ApplicationBuilder';
import { ApiClient } from './services/ApiClient';

export interface IApplicationBuilderWebPartProps { apiBaseUrl: string; title: string; }
export default class ApplicationBuilderWebPart extends BaseClientSideWebPart<IApplicationBuilderWebPartProps> {
  public render(): void { const api = new ApiClient(this.context, this.properties.apiBaseUrl || 'https://localhost:7043'); ReactDom.render(React.createElement(ApplicationBuilder, { api, title: this.properties.title || 'Application Builder' }), this.domElement); }
  protected onDispose(): void { ReactDom.unmountComponentAtNode(this.domElement); }
  protected get dataVersion(): Version { return Version.parse('1.0'); }
  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration { return { pages: [{ header: { description: 'Application Builder settings' }, groups: [{ groupName: 'API', groupFields: [PropertyPaneTextField('apiBaseUrl', { label: 'Backend API base URL' }), PropertyPaneTextField('title', { label: 'Portal title' })] }] }] }; }
}
