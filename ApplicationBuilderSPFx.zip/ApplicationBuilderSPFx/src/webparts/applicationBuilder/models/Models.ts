export interface IApplication { id: string; code: string; name: string; description?: string; icon?: string; themeColor?: string; isActive?: boolean; }
export interface IApplicationSummary extends IApplication { pendingApprovals: number; myRequests: number; }
export interface IFormField { id: string; fieldKey: string; label: string; controlType: string; isRequired: boolean; displayOrder: number; configJson?: string; }
export interface IFormSection { id: string; title: string; displayOrder: number; fields: IFormField[]; }
export interface IForm { id: string; name: string; version: number; sections: IFormSection[]; }
export interface IRequest { id: string; requestNo: string; applicationId: string; status: string; submittedDate?: string; createdDate?: string; values?: Record<string, any>; }
export interface IApprovalTask { id: string; requestId: string; stageName: string; status: string; assignedToName?: string; dueDate?: string; }
export interface IDashboard { applications: IApplicationSummary[]; pendingApprovals: number; myRequests: number; }
