import * as React from 'react';
import { useEffect, useMemo, useState } from 'react';
import { Layout, Menu, Card, Row, Col, Badge, Typography, Space, Button, Input, Table, Tabs, Form, InputNumber, Select, DatePicker, Switch, Radio, Checkbox, Alert, Spin, Empty, Tag, Modal, message } from 'antd';
import { AppstoreOutlined, CheckCircleOutlined, FileTextOutlined, SettingOutlined, SearchOutlined, PlusOutlined, ArrowLeftOutlined, PaperClipOutlined, HistoryOutlined, ApartmentOutlined, DeleteOutlined, EditOutlined, EyeOutlined } from '@ant-design/icons';
import 'antd/dist/reset.css';
import styles from './ApplicationBuilder.module.scss';
import { ApiClient } from '../services/ApiClient';
import { IApplicationSummary, IDashboard, IForm, IFormField, IRequest } from '../models/Models';

const { Header, Sider, Content } = Layout;

export interface IApplicationBuilderProps { api: ApiClient; title: string; }

type Screen = 'home' | 'requests' | 'form' | 'admin';

export const ApplicationBuilder: React.FC<IApplicationBuilderProps> = ({ api, title }) => {
  const [dashboard, setDashboard] = useState<IDashboard>();
  const [screen, setScreen] = useState<Screen>('home');
  const [selectedApp, setSelectedApp] = useState<IApplicationSummary>();
  const [selectedRequest, setSelectedRequest] = useState<IRequest>();
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string>();
  const [search, setSearch] = useState('');

  const loadDashboard = async () => { setLoading(true); try { setDashboard(await api.get<IDashboard>('/api/dashboard')); setError(undefined); } catch (e) { setError((e as Error).message); } finally { setLoading(false); } };
  useEffect(() => { loadDashboard(); }, []);

  const openApp = (app: IApplicationSummary, target: Screen = 'requests') => { setSelectedApp(app); setScreen(target); };
  const apps = useMemo(() => (dashboard?.applications || []).filter(a => `${a.name} ${a.code}`.toLowerCase().includes(search.toLowerCase())), [dashboard, search]);

  if (loading) return <div className={styles.center}><Spin size="large" /></div>;
  if (error) return <Alert type="error" showIcon message="Unable to load Application Builder" description={error} action={<Button onClick={loadDashboard}>Retry</Button>} />;

  return <Layout className={styles.app}>
    <Sider breakpoint="lg" collapsedWidth="0" className={styles.sider}>
      <div className={styles.brand}><div className={styles.logo}>AB</div><span>{title}</span></div>
      <Menu theme="dark" selectedKeys={[screen]} items={[{ key: 'home', icon: <AppstoreOutlined />, label: 'Applications', onClick: () => setScreen('home') }, { key: 'requests', icon: <FileTextOutlined />, label: 'My Requests', onClick: () => setScreen('requests') }, { key: 'admin', icon: <SettingOutlined />, label: 'Administration', onClick: () => setScreen('admin') }]} />
    </Sider>
    <Layout>
      <Header className={styles.header}><Space><Typography.Title level={4} style={{margin:0,color:'#fff'}}>{screen === 'home' ? 'Application Dashboard' : selectedApp?.name || 'Application Builder'}</Typography.Title></Space><Space><Badge count={dashboard?.pendingApprovals || 0} overflowCount={99}><Button shape="circle" icon={<CheckCircleOutlined />} /></Badge></Space></Header>
      <Content className={styles.content}>
        {screen === 'home' && <Home apps={apps} search={search} setSearch={setSearch} onOpen={openApp} />}
        {screen === 'requests' && selectedApp && <Requests api={api} app={selectedApp} onBack={() => setScreen('home')} onOpen={(r) => { setSelectedRequest(r); setScreen('form'); }} />}
        {screen === 'form' && selectedApp && <RequestDetail api={api} app={selectedApp} request={selectedRequest} onBack={() => setScreen('requests')} onSaved={() => { message.success('Saved'); setScreen('requests'); }} />}
        {screen === 'admin' && <Admin api={api} />}
      </Content>
    </Layout>
  </Layout>;
};

const Home: React.FC<any> = ({ apps, search, setSearch, onOpen }) => <>
  <div className={styles.pageTitle}><div><Typography.Title level={2}>Applications</Typography.Title><Typography.Text type="secondary">Access your configured business applications</Typography.Text></div><Input allowClear prefix={<SearchOutlined />} placeholder="Search applications" value={search} onChange={e => setSearch(e.target.value)} className={styles.search} /></div>
  <Row gutter={[18,18]}>{apps.map((app: IApplicationSummary) => <Col xs={24} sm={12} md={8} lg={6} key={app.id}><Card hoverable className={styles.appCard} onClick={() => onOpen(app)}><div className={styles.appIcon} style={{background: app.themeColor || '#b91c1c'}}>{app.icon || app.name.substring(0,1)}</div><Typography.Title level={4}>{app.name}</Typography.Title><Typography.Text type="secondary">{app.code}</Typography.Text><div className={styles.cardStats}><span>My Requests <b>{app.myRequests || 0}</b></span><span>Approvals <Badge count={app.pendingApprovals || 0} showZero /></span></div></Card></Col>)}</Row>
  {!apps.length && <Empty description="No applications found" />}
</>;

const Requests: React.FC<any> = ({ api, app, onBack, onOpen }) => {
  const [rows, setRows] = useState<IRequest[]>([]); const [loading, setLoading] = useState(true); const [approval, setApproval] = useState(false);
  const load = async () => { setLoading(true); try { setRows(await api.get<IRequest[]>(`/api/applications/${app.id}/requests?approvals=${approval}`)); } finally { setLoading(false); } };
  useEffect(() => { load(); }, [app.id, approval]);
  const del = async (id: string) => { await api.delete(`/api/requests/${id}`); message.success('Deleted'); load(); };
  const columns: any[] = [{ title: 'Request No.', dataIndex: 'requestNo' }, { title: 'Status', dataIndex: 'status', render: (v:string) => <Tag color={v === 'Approved' ? 'green' : v === 'Rejected' ? 'red' : 'gold'}>{v}</Tag> }, { title: 'Created', dataIndex: 'createdDate', render: (v:string) => v ? new Date(v).toLocaleDateString() : '-' }, { title: 'Actions', render: (_:any,r:IRequest) => <Space><Button icon={<EyeOutlined />} onClick={() => onOpen(r)}>View</Button><Button icon={<EditOutlined />} onClick={() => onOpen(r)}>Edit</Button><Button danger icon={<DeleteOutlined />} onClick={() => del(r.id)} /></Space> }];
  return <><Button icon={<ArrowLeftOutlined />} onClick={onBack}>Applications</Button><div className={styles.pageTitle}><div><Typography.Title level={2}>{app.name}</Typography.Title><Typography.Text type="secondary">Manage requests and approvals</Typography.Text></div><Button type="primary" icon={<PlusOutlined />} onClick={() => onOpen(undefined)}>New Request</Button></div><Tabs activeKey={approval ? 'approvals' : 'mine'} onChange={k => setApproval(k === 'approvals')} items={[{key:'mine',label:'My Requests'}, {key:'approvals',label:<Badge count={app.pendingApprovals || 0} offset={[10,-2]}>My Approvals</Badge>}]} /><Table rowKey="id" loading={loading} dataSource={rows} columns={columns} /> </>;
};

const control = (f: IFormField) => { const t = (f.controlType || 'text').toLowerCase(); const p = { placeholder: `Enter ${f.label}` }; if (t === 'textarea' || t === 'richtext') return <Input.TextArea {...p} rows={4}/>; if (['number','decimal','currency'].includes(t)) return <InputNumber style={{width:'100%'}}/>; if (t === 'date' || t === 'datetime') return <DatePicker showTime={t === 'datetime'} style={{width:'100%'}}/>; if (t === 'select' || t === 'lookup' || t === 'userpicker' || t === 'employeepicker') return <Select showSearch style={{width:'100%'}} options={[]} placeholder={p.placeholder}/>; if (t === 'multiselect') return <Select mode="multiple" style={{width:'100%'}} options={[]}/>; if (t === 'radio') return <Radio.Group options={[]}/>; if (t === 'checkbox') return <Checkbox>{f.label}</Checkbox>; if (t === 'switch') return <Switch/>; return <Input {...p}/>; };

const RequestDetail: React.FC<any> = ({ api, app, request, onBack, onSaved }) => {
  const [formMeta, setFormMeta] = useState<IForm>(); const [form] = Form.useForm(); const [loading,setLoading]=useState(true);
  useEffect(() => { (async () => { try { const forms = await api.get<IForm[]>(`/api/applications/${app.id}/forms`); setFormMeta(forms[0]); if (request) { const r=await api.get<IRequest>(`/api/requests/${request.id}`); form.setFieldsValue(r.values || {}); } } finally { setLoading(false); } })(); }, [app.id, request?.id]);
  const save = async (values:any) => { if (request) await api.put(`/api/requests/${request.id}`, { values }); else await api.post(`/api/applications/${app.id}/requests`, { values }); onSaved(); };
  if (loading) return <Spin/>;
  return <><Button icon={<ArrowLeftOutlined />} onClick={onBack}>Requests</Button><div className={styles.pageTitle}><div><Typography.Title level={2}>{request ? request.requestNo : 'New Request'}</Typography.Title><Typography.Text type="secondary">{app.name}</Typography.Text></div></div><Form form={form} layout="vertical" onFinish={save}><Tabs items={[{key:'entry',label:'Entry',children:<Row gutter={18}>{(formMeta?.sections || []).map(s=><Col span={24} key={s.id}><Card title={s.title}>{s.fields.sort((a,b)=>a.displayOrder-b.displayOrder).map(f=><Form.Item key={f.id} name={f.fieldKey} label={f.label} rules={f.isRequired?[{required:true,message:`${f.label} is required`}]:[]}>{control(f)}</Form.Item>)}</Card></Col>)}</Row>},{key:'attachments',label:<span><PaperClipOutlined/> Attachments</span>,children:<Empty description="Attachments are stored in the application's SharePoint library"/>},{key:'history',label:<span><HistoryOutlined/> History</span>,children:<Empty description="Request audit history"/>},{key:'workflow',label:<span><ApartmentOutlined/> Workflow</span>,children:<Empty description="Workflow stages and approval actions"/>}]} /><Space><Button onClick={onBack}>Cancel</Button><Button type="primary" htmlType="submit">Save</Button></Space></Form></>;
};

const Admin: React.FC<any> = ({ api }) => <Card><Typography.Title level={2}>Administration</Typography.Title><Row gutter={[16,16]}><Col xs={24} md={8}><Card hoverable><SettingOutlined/> Application Configuration<br/><Typography.Text type="secondary">Applications, forms and metadata</Typography.Text></Card></Col><Col xs={24} md={8}><Card hoverable><ApartmentOutlined/> Workflow Builder<br/><Typography.Text type="secondary">Stages, approvers and delegation</Typography.Text></Card></Col><Col xs={24} md={8}><Card hoverable><CheckCircleOutlined/> Roles & Permissions<br/><Typography.Text type="secondary">Users, roles and application permissions</Typography.Text></Card></Col></Row></Card>;
