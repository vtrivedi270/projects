# Application Builder - SPFx React Frontend

Node 18 / SPFx 1.20 / React 17.0.1 / Ant Design 5.

## Why SPFx 1.20
Microsoft's compatibility table lists SPFx 1.20.0 with Node.js 18 and React 17.0.1. SPFx 1.21+ requires Node 22, so this package intentionally targets SPFx 1.20 for the requested Node 18 environment.

## Prerequisites
- Node.js 18 LTS
- npm
- SharePoint Framework build toolchain from package.json
- Backend from `ApplicationBuilderNet`

## Run
```bash
nvm use 18
npm install
npm run serve
```
For production package:
```bash
npm install
npm run build
npm run package-solution
```
The package is generated under `sharepoint/solution/`.

## Backend
Set the web part property `apiBaseUrl` to the deployed .NET API, e.g. `https://api.contoso.com`.
The frontend uses `AadHttpClient`, so the SharePoint/Entra configuration must grant the SPFx solution permission to call the API and the API must validate the Entra access token audience.

## Implemented UI
- Application hub with application cards and approval counts
- Search
- My Requests / My Approvals
- Request CRUD UI
- Dynamic form rendering from backend form metadata
- Entry / Attachments / History / Workflow tabs
- Admin landing area
- Red enterprise theme
- Ant Design controls

## API contract expected
- GET `/api/dashboard`
- GET `/api/applications/{appId}/forms`
- GET `/api/applications/{appId}/requests?approvals=false`
- POST `/api/applications/{appId}/requests`
- GET `/api/requests/{id}`
- PUT `/api/requests/{id}`
- DELETE `/api/requests/{id}`

This source is structured to connect to the previously generated .NET backend. It has not been compiled in this environment because the available runtime is Node 22 rather than the requested Node 18 and the SPFx toolchain is not installed here.
