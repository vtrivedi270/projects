using System.Globalization;
using System.Net;
using System.Text;
using Microsoft.EntityFrameworkCore;
using ReferralHub.Api.Data;
using ReferralHub.Api.Domain;

namespace ReferralHub.Api.Infrastructure;

/// <summary>
/// Queues an email in rp.Notification in the same SaveChanges as the business change (outbox pattern).
/// NotificationWorker sends 'Queued' rows through Microsoft Graph, retries failures, and marks them Sent.
/// Every stage change and every activity in the services calls this, so people are always told.
/// </summary>
public class Notifier(AppDbContext db, IConfiguration cfg)
{
    /// <param name="path">Deep link inside the SPFx app, for example "/referrals/12". Added to App:BaseUrl.</param>
    public void To(int employeeId, string category, string subject, string headline, string[] lines,
                   string? path = null, string? entity = null, int? id = null)
        => Add(employeeId, null, category, subject, headline, lines, path, entity, id);

    /// <summary>For a mailing list address, for example the all-employees list.</summary>
    public void ToAddress(string email, string category, string subject, string headline, string[] lines,
                          string? path = null, string? entity = null, int? id = null)
        => Add(null, email, category, subject, headline, lines, path, entity, id);

    public async Task<List<int>> IdsWithRoleAsync(string[] roles, CancellationToken ct)
        => await db.EmployeeRoles.Where(x => roles.Contains(x.Role!.Code) && x.Employee!.IsActive)
            .Select(x => x.EmployeeId).Distinct().ToListAsync(ct);

    /// <summary>Emails everyone who holds one of the roles, except the person who did the action.</summary>
    public async Task ToRolesAsync(string[] roles, int? except, string category, string subject, string headline,
                                   string[] lines, string? path, string? entity, int? id, CancellationToken ct)
    {
        foreach (var emp in await IdsWithRoleAsync(roles, ct))
            if (emp != except) To(emp, category, subject, headline, lines, path, entity, id);
    }

    void Add(int? employeeId, string? email, string category, string subject, string headline, string[] lines,
             string? path, string? entity, int? id)
    {
        var url = path == null ? null : (cfg["App:BaseUrl"] ?? "") + path;
        db.Notifications.Add(new Notification
        {
            RecipientEmployeeId = employeeId,
            RecipientEmail = email,
            Category = category,
            Subject = subject.Length > 200 ? subject[..200] : subject,
            Body = EmailTemplate.Render(headline, lines, url),
            RelatedEntity = entity,
            RelatedId = id,
            CreatedOn = Clock.Now
        });
    }
}

public static class EmailTemplate
{
    /// <summary>Times in emails are shown in India time.</summary>
    public static string Ist(DateTime utc)
        => utc.ToUniversalTime().AddHours(5.5).ToString("dd MMM yyyy, h:mm tt", CultureInfo.InvariantCulture) + " IST";

    public static string Render(string headline, IEnumerable<string> lines, string? url, string buttonText = "Open in Referral Hub")
    {
        var sb = new StringBuilder();
        sb.Append("<div style=\"font-family:Segoe UI,Arial,sans-serif;max-width:560px;margin:auto;border:1px solid #EBDDDF;border-radius:12px;overflow:hidden\">");
        sb.Append("<div style=\"background:#C8102E;color:#fff;padding:14px 20px;font-weight:700;font-size:16px\">Referral Hub</div>");
        sb.Append("<div style=\"padding:20px\"><h2 style=\"margin:0 0 12px;color:#26161A;font-size:20px\">")
          .Append(WebUtility.HtmlEncode(headline)).Append("</h2>");
        foreach (var l in lines)
            sb.Append("<p style=\"margin:0 0 10px;color:#26161A;line-height:1.5\">").Append(WebUtility.HtmlEncode(l)).Append("</p>");
        if (!string.IsNullOrEmpty(url))
            sb.Append("<p style=\"margin:18px 0 0\"><a href=\"").Append(WebUtility.HtmlEncode(url))
              .Append("\" style=\"background:#C8102E;color:#fff;text-decoration:none;padding:10px 18px;border-radius:8px;font-weight:600\">")
              .Append(WebUtility.HtmlEncode(buttonText)).Append("</a></p>");
        sb.Append("</div><div style=\"padding:12px 20px;background:#FAF5F4;color:#7A686B;font-size:12px\">This is an automated message from Referral Hub.</div></div>");
        return sb.ToString();
    }
}
