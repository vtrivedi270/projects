using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text.Json;
using Azure.Core;
using Azure.Identity;
using ReferralHub.Api.Domain;

namespace ReferralHub.Api.Infrastructure;

/// <summary>
/// App-only Microsoft Graph client (client credentials). Needed application permissions:
///   Mail.Send (send email as Graph:SenderUpn) and Calendars.ReadWrite (create the invite in Graph:OrganizerUpn's calendar).
/// Restrict both to the two mailboxes with an Exchange Application Access Policy.
/// Keep Graph:ClientSecret in Key Vault or user-secrets, never in source control.
/// </summary>
public class GraphClient(IHttpClientFactory httpFactory, IConfiguration cfg)
{
    readonly Lazy<ClientSecretCredential> _cred = new(() =>
        new ClientSecretCredential(cfg["Graph:TenantId"], cfg["Graph:ClientId"], cfg["Graph:ClientSecret"]));

    public bool IsConfigured => !string.IsNullOrWhiteSpace(cfg["Graph:ClientSecret"]) && !string.IsNullOrWhiteSpace(cfg["Graph:ClientId"]);

    public async Task<HttpResponseMessage> SendAsync(HttpMethod method, string path, object? body, CancellationToken ct)
    {
        var token = await _cred.Value.GetTokenAsync(new TokenRequestContext(["https://graph.microsoft.com/.default"]), ct);
        var req = new HttpRequestMessage(method, "https://graph.microsoft.com/v1.0" + path);
        req.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token.Token);
        if (body != null) req.Content = JsonContent.Create(body);
        return await httpFactory.CreateClient().SendAsync(req, ct);
    }

    public async Task<string> ErrorAsync(HttpResponseMessage res, CancellationToken ct)
    {
        var text = await res.Content.ReadAsStringAsync(ct);
        return $"{(int)res.StatusCode} {(text.Length > 300 ? text[..300] : text)}";
    }
}

public record InviteResult(string Status, string? EventId, string? JoinUrl, string? Error);

/// <summary>Creates or updates one Outlook calendar event with a Teams meeting. Graph emails the invite to every attendee.</summary>
public class CalendarInviteService(GraphClient graph, IConfiguration cfg, ILogger<CalendarInviteService> log)
{
    public async Task<InviteResult> UpsertAsync(Interview iv, Referral r, Employee interviewer, Employee scheduler, CancellationToken ct)
    {
        var organizer = cfg["Graph:OrganizerUpn"];
        if (!graph.IsConfigured || string.IsNullOrWhiteSpace(organizer))
            return new InviteResult(InviteStatuses.NotSent, iv.CalendarEventId, iv.MeetingLink, "Calendar invites are not configured on the server.");

        try
        {
            var start = DateTime.SpecifyKind(iv.ScheduledAt, DateTimeKind.Utc);
            var end = start.AddMinutes(iv.DurationMinutes);
            var attendees = new[]
            {
                Attendee(interviewer.Email, interviewer.DisplayName),
                Attendee(r.CandidateEmail, r.CandidateName),
                Attendee(scheduler.Email, scheduler.DisplayName)
            };
            var subject = $"Interview {iv.RoundNo}: {r.CandidateName} - {r.Requisition?.Title}";
            var html = EmailTemplate.Render($"Interview {iv.RoundNo}",
                [$"Candidate: {r.CandidateName}", $"Position: {r.Requisition?.Title}",
                 $"When: {EmailTemplate.Ist(start)} ({iv.DurationMinutes} minutes)", $"Interviewer: {interviewer.DisplayName}"], null);

            var common = new
            {
                subject,
                body = new { contentType = "HTML", content = html },
                start = new { dateTime = start.ToString("yyyy-MM-ddTHH:mm:ss"), timeZone = "UTC" },
                end = new { dateTime = end.ToString("yyyy-MM-ddTHH:mm:ss"), timeZone = "UTC" },
                attendees
            };

            HttpResponseMessage res;
            if (string.IsNullOrEmpty(iv.CalendarEventId))
            {
                // New invite with a Teams meeting
                var create = new
                {
                    common.subject, common.body, common.start, common.end, common.attendees,
                    isOnlineMeeting = true, onlineMeetingProvider = "teamsForBusiness"
                };
                res = await graph.SendAsync(HttpMethod.Post, $"/users/{organizer}/events", create, ct);
            }
            else
            {
                // Reschedule: update the same event so attendees get an updated invite, not a second one
                res = await graph.SendAsync(HttpMethod.Patch, $"/users/{organizer}/events/{iv.CalendarEventId}", common, ct);
            }

            if (!res.IsSuccessStatusCode)
                return new InviteResult(InviteStatuses.Failed, iv.CalendarEventId, iv.MeetingLink, await graph.ErrorAsync(res, ct));

            using var doc = JsonDocument.Parse(await res.Content.ReadAsStringAsync(ct));
            var root = doc.RootElement;
            var id = root.TryGetProperty("id", out var idEl) ? idEl.GetString() : iv.CalendarEventId;
            string? join = iv.MeetingLink;
            if (root.TryGetProperty("onlineMeeting", out var om) && om.ValueKind == JsonValueKind.Object
                && om.TryGetProperty("joinUrl", out var ju)) join = ju.GetString();
            return new InviteResult(InviteStatuses.Sent, id, join, null);
        }
        catch (Exception ex)
        {
            log.LogError(ex, "Calendar invite failed for interview {Id}", iv.InterviewId);
            return new InviteResult(InviteStatuses.Failed, iv.CalendarEventId, iv.MeetingLink, ex.Message);
        }
    }

    static object Attendee(string email, string name) => new { emailAddress = new { address = email, name }, type = "required" };
}
