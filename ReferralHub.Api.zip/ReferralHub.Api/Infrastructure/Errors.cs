using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace ReferralHub.Api.Infrastructure;

/// <summary>A business rule was broken. Returned as HTTP 400 with a message the UI can show.</summary>
public class DomainException(string message) : Exception(message);
public class ForbiddenException(string message) : Exception(message);
public class NotFoundException(string message) : Exception(message);

public class ErrorMiddleware(RequestDelegate next, ILogger<ErrorMiddleware> log)
{
    public async Task Invoke(HttpContext ctx)
    {
        try { await next(ctx); }
        catch (Exception ex) when (!ctx.Response.HasStarted)
        {
            var (code, title) = ex switch
            {
                DomainException => (400, ex.Message),
                ForbiddenException => (403, ex.Message),
                NotFoundException => (404, ex.Message),
                // Rowversion mismatch: another user changed the same requisition or referral a moment ago
                DbUpdateConcurrencyException => (409, "Someone else just changed this record. Refresh and try again."),
                _ => (500, "Something went wrong. Please try again.")
            };
            if (code == 500) log.LogError(ex, "Unhandled error on {Path}", ctx.Request.Path);
            ctx.Response.Clear();
            ctx.Response.StatusCode = code;
            await ctx.Response.WriteAsJsonAsync(new ProblemDetails { Status = code, Title = title });
        }
    }
}
