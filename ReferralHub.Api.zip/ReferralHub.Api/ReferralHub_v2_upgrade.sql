/* =====================================================================
   Referral Hub - upgrade v2 (run AFTER ReferralHub_schema.sql; safe to re-run)
   1. INTERVIEWER role + which rounds each interviewer takes
   2. Approval history (append-only) and "acted by" on every approval step
   3. Interview meeting invite fields (Teams / Outlook calendar event)
   4. Referral timeline: stage changes, round, and what the referrer may see
   5. Email outbox: retries, category, external recipients
   ===================================================================== */
USE ReferralHub;
GO

/* ---------- 1. Interviewer role ---------- */
IF NOT EXISTS (SELECT 1 FROM rp.AppRole WHERE Code = 'INTERVIEWER')
    INSERT rp.AppRole(RoleId, Code, Name) VALUES (7, 'INTERVIEWER', 'Interviewer');
GO

/* An interviewer with NO rows here can take any round.
   Add rows to limit them, e.g. a tech lead for round 1 and 2, a leader for round 3. */
IF OBJECT_ID('rp.InterviewerRound') IS NULL
CREATE TABLE rp.InterviewerRound(
    EmployeeId  int NOT NULL CONSTRAINT FK_InterviewerRound_Employee REFERENCES rp.Employee(EmployeeId),
    RoundNo     tinyint NOT NULL CONSTRAINT CK_InterviewerRound_Round CHECK (RoundNo BETWEEN 1 AND 3),
    CONSTRAINT PK_InterviewerRound PRIMARY KEY (EmployeeId, RoundNo)
);
GO

/* ---------- 2. Approval: who acted, when, and full history ---------- */
IF COL_LENGTH('rp.RequisitionApproval', 'ActedByEmployeeId') IS NULL
    ALTER TABLE rp.RequisitionApproval ADD ActedByEmployeeId int NULL
        CONSTRAINT FK_ReqApproval_ActedBy REFERENCES rp.Employee(EmployeeId);
GO
UPDATE rp.RequisitionApproval SET ActedByEmployeeId = ApproverEmployeeId
WHERE Status IN ('Approved','Rejected') AND ActedByEmployeeId IS NULL;
GO

/* One row per event: Submitted, Approved, Rejected, Published. Never updated or deleted. */
IF OBJECT_ID('rp.RequisitionHistory') IS NULL
CREATE TABLE rp.RequisitionHistory(
    HistoryId       bigint IDENTITY(1,1) CONSTRAINT PK_RequisitionHistory PRIMARY KEY,
    RequisitionId   int NOT NULL CONSTRAINT FK_ReqHistory_Req REFERENCES rp.JobRequisition(RequisitionId),
    EventType       varchar(30) NOT NULL,
    StepNo          tinyint NULL,
    FromStatus      varchar(16) NULL,
    ToStatus        varchar(16) NULL,
    ActorEmployeeId int NOT NULL CONSTRAINT FK_ReqHistory_Actor REFERENCES rp.Employee(EmployeeId),
    Comments        nvarchar(500) NULL,
    CreatedOn       datetime2(0) NOT NULL CONSTRAINT DF_ReqHistory_On DEFAULT SYSUTCDATETIME()
);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_ReqHistory_Req')
    CREATE INDEX IX_ReqHistory_Req ON rp.RequisitionHistory(RequisitionId, CreatedOn);
GO

/* Backfill history for requisitions that already exist */
IF NOT EXISTS (SELECT 1 FROM rp.RequisitionHistory)
BEGIN
    INSERT rp.RequisitionHistory(RequisitionId, EventType, ToStatus, ActorEmployeeId, CreatedOn)
    SELECT RequisitionId, 'Submitted', 'PendingApproval', RequestedByEmployeeId, CreatedOn FROM rp.JobRequisition;

    INSERT rp.RequisitionHistory(RequisitionId, EventType, StepNo, ActorEmployeeId, Comments, CreatedOn)
    SELECT RequisitionId, Status, StepNo, ApproverEmployeeId, Comments, ActedOn
    FROM rp.RequisitionApproval WHERE Status IN ('Approved','Rejected');

    INSERT rp.RequisitionHistory(RequisitionId, EventType, FromStatus, ToStatus, ActorEmployeeId, CreatedOn)
    SELECT j.RequisitionId, 'Published', 'PendingApproval', 'Open', a.ApproverEmployeeId, j.PublishedOn
    FROM rp.JobRequisition j JOIN rp.RequisitionApproval a ON a.RequisitionId = j.RequisitionId AND a.StepNo = 3
    WHERE j.PublishedOn IS NOT NULL;
END
GO

/* History cannot be edited or removed */
CREATE OR ALTER TRIGGER rp.trg_RequisitionHistory_AppendOnly ON rp.RequisitionHistory
INSTEAD OF UPDATE, DELETE AS
BEGIN
    RAISERROR('Requisition history is append-only.', 16, 1);
    IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
END
GO

/* ---------- 3. Interview meeting invite ---------- */
IF COL_LENGTH('rp.Interview', 'DurationMinutes') IS NULL
    ALTER TABLE rp.Interview ADD DurationMinutes smallint NOT NULL CONSTRAINT DF_Interview_Duration DEFAULT 60;
IF COL_LENGTH('rp.Interview', 'CalendarEventId') IS NULL
    ALTER TABLE rp.Interview ADD CalendarEventId nvarchar(300) NULL;      -- Microsoft Graph event id, used to update the same invite
IF COL_LENGTH('rp.Interview', 'InviteStatus') IS NULL
    ALTER TABLE rp.Interview ADD InviteStatus varchar(10) NOT NULL CONSTRAINT DF_Interview_InviteStatus DEFAULT 'NotSent'
        CONSTRAINT CK_Interview_InviteStatus CHECK (InviteStatus IN ('NotSent','Sent','Failed'));
IF COL_LENGTH('rp.Interview', 'InviteSentOn') IS NULL
    ALTER TABLE rp.Interview ADD InviteSentOn datetime2(0) NULL;
IF COL_LENGTH('rp.Interview', 'InviteError') IS NULL
    ALTER TABLE rp.Interview ADD InviteError nvarchar(500) NULL;
IF COL_LENGTH('rp.Interview', 'ReminderSentOn') IS NULL
    ALTER TABLE rp.Interview ADD ReminderSentOn datetime2(0) NULL;        -- 24-hour reminder to the interviewer
GO

/* ---------- 4. Referral timeline (history) ---------- */
IF COL_LENGTH('rp.ReferralActivity', 'FromStageId') IS NULL
    ALTER TABLE rp.ReferralActivity ADD FromStageId tinyint NULL, ToStageId tinyint NULL, RoundNo tinyint NULL;
IF COL_LENGTH('rp.ReferralActivity', 'VisibleToReferrer') IS NULL
    ALTER TABLE rp.ReferralActivity ADD VisibleToReferrer bit NOT NULL CONSTRAINT DF_RefAct_Visible DEFAULT 0;
GO
UPDATE rp.ReferralActivity SET VisibleToReferrer = 1
WHERE VisibleToReferrer = 0
  AND ActivityType IN ('Submitted','Contacted','Shortlisted','InterviewScheduled','InterviewRescheduled',
                       'InterviewCompleted','SentForFinalApproval','Selected','Closed');
GO

/* ---------- 5. Email outbox ---------- */
IF COL_LENGTH('rp.Notification', 'Category') IS NULL
    ALTER TABLE rp.Notification ADD Category varchar(40) NOT NULL CONSTRAINT DF_Notification_Category DEFAULT 'General';
IF COL_LENGTH('rp.Notification', 'Attempts') IS NULL
    ALTER TABLE rp.Notification ADD Attempts tinyint NOT NULL CONSTRAINT DF_Notification_Attempts DEFAULT 0;
IF COL_LENGTH('rp.Notification', 'LastError') IS NULL
    ALTER TABLE rp.Notification ADD LastError nvarchar(500) NULL;
IF COL_LENGTH('rp.Notification', 'RecipientEmail') IS NULL
    ALTER TABLE rp.Notification ADD RecipientEmail nvarchar(256) NULL;    -- for a mailing list such as all-employees@
GO
ALTER TABLE rp.Notification ALTER COLUMN RecipientEmployeeId int NULL;
GO
IF NOT EXISTS (SELECT 1 FROM sys.check_constraints WHERE name = 'CK_Notification_Recipient')
    ALTER TABLE rp.Notification ADD CONSTRAINT CK_Notification_Recipient
        CHECK (RecipientEmployeeId IS NOT NULL OR RecipientEmail IS NOT NULL);
GO

/* ---------- Example: make people interviewers (edit the emails) ----------
INSERT rp.EmployeeRole(EmployeeId, RoleId)
SELECT e.EmployeeId, 7 FROM rp.Employee e
WHERE e.Email IN ('hitesh@yourtenant.com','nilesh@yourtenant.com','pooja@yourtenant.com')
  AND NOT EXISTS (SELECT 1 FROM rp.EmployeeRole x WHERE x.EmployeeId = e.EmployeeId AND x.RoleId = 7);

-- optional: limit rounds (no rows = any round)
INSERT rp.InterviewerRound(EmployeeId, RoundNo)
SELECT EmployeeId, r.n FROM rp.Employee CROSS JOIN (VALUES (1),(2)) r(n) WHERE Email = 'hitesh@yourtenant.com';
---------------------------------------------------------------------- */
