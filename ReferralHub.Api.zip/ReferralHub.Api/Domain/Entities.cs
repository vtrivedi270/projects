using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ReferralHub.Api.Domain;

public class Employee
{
    [Key] public int EmployeeId { get; set; }
    public Guid? EntraObjectId { get; set; }
    public string Email { get; set; } = "";
    public string DisplayName { get; set; } = "";
    public string? JobTitle { get; set; }
    public int? DepartmentId { get; set; }
    public int? ManagerEmployeeId { get; set; }
    public bool IsActive { get; set; } = true;
    public DateTime CreatedOn { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedOn { get; set; }
    public List<EmployeeRole> Roles { get; set; } = new();
}

public class Division
{
    [Key] public int DivisionId { get; set; }
    public string Name { get; set; } = "";
    public int DivisionHeadEmployeeId { get; set; }
    public DateTime? UpdatedOn { get; set; }
}

public class Department
{
    [Key] public int DepartmentId { get; set; }
    public int DivisionId { get; set; }
    public string Name { get; set; } = "";
    public int DepartmentHeadEmployeeId { get; set; }
    public decimal? DefaultBonusAmount { get; set; }
    public DateTime? UpdatedOn { get; set; }
    public Division? Division { get; set; }
}

public class AppRole
{
    [Key, DatabaseGenerated(DatabaseGeneratedOption.None)] public byte RoleId { get; set; }
    public string Code { get; set; } = "";
    public string Name { get; set; } = "";
}

public class EmployeeRole
{
    public int EmployeeId { get; set; }
    public byte RoleId { get; set; }
    public Employee? Employee { get; set; }
    public AppRole? Role { get; set; }
}

public class Location
{
    [Key] public int LocationId { get; set; }
    public string Name { get; set; } = "";
}

public class Skill
{
    [Key] public int SkillId { get; set; }
    public string Name { get; set; } = "";
}

public class ReferralStage
{
    [Key, DatabaseGenerated(DatabaseGeneratedOption.None)] public byte StageId { get; set; }
    public string Name { get; set; } = "";
}

public class JobRequisition
{
    [Key] public int RequisitionId { get; set; }
    public string Title { get; set; } = "";
    public int DepartmentId { get; set; }
    public int LocationId { get; set; }
    public string EmploymentType { get; set; } = "FullTime";
    public short NoOfPositions { get; set; }
    public short PositionsFilled { get; set; }
    public string? ExperienceRequired { get; set; }
    public DateOnly HireByDate { get; set; }
    public string Summary { get; set; } = "";
    public string Requirements { get; set; } = "";
    public int RequestedByEmployeeId { get; set; }
    public string Status { get; set; } = ReqStatus.PendingApproval;
    public string? RejectionReason { get; set; }
    public DateTime? PublishedOn { get; set; }
    public DateTime CreatedOn { get; set; }
    public DateTime UpdatedOn { get; set; }
    [Timestamp] public byte[] RowVer { get; set; } = Array.Empty<byte>();

    public Department? Department { get; set; }
    public Location? Location { get; set; }
    public Employee? RequestedBy { get; set; }
    public List<JobRequisitionSkill> Skills { get; set; } = new();
    public List<RequisitionApproval> Approvals { get; set; } = new();
    public List<RequisitionHistory> History { get; set; } = new();
}

public class JobRequisitionSkill
{
    public int RequisitionId { get; set; }
    public int SkillId { get; set; }
    public Skill? Skill { get; set; }
}

public class RequisitionApproval
{
    [Key] public int ApprovalId { get; set; }
    public int RequisitionId { get; set; }
    public byte StepNo { get; set; }
    public string ApproverRole { get; set; } = "";
    public int ApproverEmployeeId { get; set; }
    public string Status { get; set; } = StepStatus.Waiting;
    public DateTime? ActedOn { get; set; }
    public string? Comments { get; set; }
    public int? ActedByEmployeeId { get; set; }          // who actually approved or rejected
    public Employee? Approver { get; set; }
    public Employee? ActedBy { get; set; }
}

/// <summary>Append-only history of a requisition: Submitted, Approved, Rejected, Published.</summary>
public class RequisitionHistory
{
    [Key] public long HistoryId { get; set; }
    public int RequisitionId { get; set; }
    public string EventType { get; set; } = "";
    public byte? StepNo { get; set; }
    public string? FromStatus { get; set; }
    public string? ToStatus { get; set; }
    public int ActorEmployeeId { get; set; }
    public string? Comments { get; set; }
    public DateTime CreatedOn { get; set; }
    public Employee? Actor { get; set; }
}

/// <summary>Which interview rounds an interviewer takes. No rows = any round.</summary>
public class InterviewerRound
{
    public int EmployeeId { get; set; }
    public byte RoundNo { get; set; }
}

public class Referral
{
    [Key] public int ReferralId { get; set; }
    public int RequisitionId { get; set; }
    public int ReferredByEmployeeId { get; set; }
    public string CandidateName { get; set; } = "";
    public string CandidateEmail { get; set; } = "";
    public string CandidatePhone { get; set; } = "";
    [Column(TypeName = "decimal(4,1)")] public decimal TotalExperienceYears { get; set; }
    public string? CurrentCompany { get; set; }
    public string? NoticePeriod { get; set; }
    public string? Relationship { get; set; }
    public string? ReferrerNote { get; set; }
    public byte CurrentStageId { get; set; } = Stages.Referred;
    public string Outcome { get; set; } = Outcomes.Active;
    public string? ClosedReason { get; set; }
    public int? AssignedHrEmployeeId { get; set; }
    public DateOnly? JoinedOn { get; set; }
    public int? JoinedConfirmedByEmployeeId { get; set; }
    public DateTime ReferredOn { get; set; }
    public DateTime UpdatedOn { get; set; }
    [Timestamp] public byte[] RowVer { get; set; } = Array.Empty<byte>();

    public JobRequisition? Requisition { get; set; }
    public Employee? ReferredBy { get; set; }
    public List<ReferralDocument> Documents { get; set; } = new();
    public List<ReferralActivity> Activities { get; set; } = new();
    public List<Interview> Interviews { get; set; } = new();
    public List<FinalApproval> FinalApprovals { get; set; } = new();
    public ReferralBonus? Bonus { get; set; }
}

/// <summary>One bonus request per referral, created by the referring employee after the candidate joins.</summary>
public class ReferralBonus
{
    [Key] public int BonusId { get; set; }
    public int ReferralId { get; set; }
    public int RequestedByEmployeeId { get; set; }
    [Column(TypeName = "decimal(10,2)")] public decimal? RequestedAmount { get; set; }
    [Column(TypeName = "decimal(10,2)")] public decimal? ApprovedAmount { get; set; }
    public string Status { get; set; } = BonusStatus.Requested;
    public string? Comments { get; set; }
    public DateTime RequestedOn { get; set; }
    public int? DecidedByEmployeeId { get; set; }
    public DateTime? DecidedOn { get; set; }
    public int? PaidByEmployeeId { get; set; }
    public DateTime? PaidOn { get; set; }
    public string? PayoutReference { get; set; }
    [Timestamp] public byte[] RowVer { get; set; } = Array.Empty<byte>();

    public Referral? Referral { get; set; }
    public Employee? RequestedBy { get; set; }
    public Employee? DecidedBy { get; set; }
    public Employee? PaidBy { get; set; }
    public List<ReferralBonusHistory> History { get; set; } = new();
}

public class ReferralBonusHistory
{
    [Key] public long HistoryId { get; set; }
    public int BonusId { get; set; }
    public string EventType { get; set; } = "";
    public int ActorEmployeeId { get; set; }
    public string? Comments { get; set; }
    public DateTime CreatedOn { get; set; }
    public Employee? Actor { get; set; }
}

public class ReferralDocument
{
    [Key] public int DocumentId { get; set; }
    public int ReferralId { get; set; }
    public string DocType { get; set; } = "Resume";
    public string FileName { get; set; } = "";
    public string ContentType { get; set; } = "";
    public long SizeBytes { get; set; }
    public string StorageUrl { get; set; } = "";
    public DateTime UploadedOn { get; set; }
}

public class ReferralActivity
{
    [Key] public long ActivityId { get; set; }
    public int ReferralId { get; set; }
    public string ActivityType { get; set; } = "";
    public int ActorEmployeeId { get; set; }
    public string? Notes { get; set; }
    public byte? FromStageId { get; set; }
    public byte? ToStageId { get; set; }
    public byte? RoundNo { get; set; }
    public bool VisibleToReferrer { get; set; }          // milestones the referring employee may see (never feedback)
    public DateTime CreatedOn { get; set; }
    public Employee? Actor { get; set; }
}

public class Interview
{
    [Key] public int InterviewId { get; set; }
    public int ReferralId { get; set; }
    public byte RoundNo { get; set; }
    public int InterviewerEmployeeId { get; set; }
    public DateTime ScheduledAt { get; set; }
    public string Mode { get; set; } = "Online";
    public string? MeetingLink { get; set; }
    public string Status { get; set; } = InterviewStatuses.Scheduled;
    public int ScheduledByEmployeeId { get; set; }
    public DateTime CreatedOn { get; set; }
    public short DurationMinutes { get; set; } = 60;
    public string? CalendarEventId { get; set; }
    public string InviteStatus { get; set; } = InviteStatuses.NotSent;
    public DateTime? InviteSentOn { get; set; }
    public string? InviteError { get; set; }
    public DateTime? ReminderSentOn { get; set; }

    public Referral? Referral { get; set; }
    public Employee? Interviewer { get; set; }
    public List<InterviewFeedback> Feedback { get; set; } = new();
}

public class InterviewFeedback
{
    [Key] public int FeedbackId { get; set; }
    public int InterviewId { get; set; }
    public int SubmittedByEmployeeId { get; set; }
    public byte Rating { get; set; }
    public string Recommendation { get; set; } = "";
    public string Comments { get; set; } = "";
    public DateTime SubmittedOn { get; set; }
    public Employee? SubmittedBy { get; set; }
}

public class FinalApproval
{
    public int ReferralId { get; set; }
    public string ApproverRole { get; set; } = "";
    public string Decision { get; set; } = Decisions.Pending;
    public int? DecidedByEmployeeId { get; set; }
    public DateTime? DecidedOn { get; set; }
    public string? Comments { get; set; }
    public Employee? DecidedBy { get; set; }
}

public class Notification
{
    [Key] public long NotificationId { get; set; }
    public int? RecipientEmployeeId { get; set; }
    public string? RecipientEmail { get; set; }
    public string Category { get; set; } = "General";
    public byte Attempts { get; set; }
    public string? LastError { get; set; }
    public string Channel { get; set; } = "Email";
    public string Subject { get; set; } = "";
    public string Body { get; set; } = "";
    public string? RelatedEntity { get; set; }
    public int? RelatedId { get; set; }
    public string Status { get; set; } = "Queued";
    public DateTime CreatedOn { get; set; }
    public DateTime? SentOn { get; set; }
    public Employee? Recipient { get; set; }
}
