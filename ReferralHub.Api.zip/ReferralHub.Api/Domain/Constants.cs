namespace ReferralHub.Api.Domain;

/// <summary>Values stored in the varchar columns. They must match the CHECK constraints in the SQL script.</summary>
public static class Roles
{
    public const string Employee = "EMPLOYEE", Manager = "MANAGER", DeptHead = "DEPT_HEAD",
                        DivHead = "DIV_HEAD", HrHead = "HR_HEAD", Hr = "HR", Interviewer = "INTERVIEWER", Admin = "ADMIN";

    public static string Label(string code) => code switch
    {
        DeptHead => "Department head", DivHead => "Division head", HrHead => "HR head",
        Hr => "HR", Manager => "Manager", Interviewer => "Interviewer", Admin => "Administrator", _ => "Employee"
    };
}

public static class BonusStatus
{
    public const string Requested = "Requested", Approved = "Approved", Rejected = "Rejected", Paid = "Paid";
}

public static class InviteStatuses
{
    public const string NotSent = "NotSent", Sent = "Sent", Failed = "Failed";
}

public static class ReqStatus
{
    public const string Draft = "Draft", PendingApproval = "PendingApproval", Open = "Open",
                        Rejected = "Rejected", Closed = "Closed", Filled = "Filled";
}

public static class StepStatus
{
    public const string Waiting = "Waiting", Pending = "Pending", Approved = "Approved", Rejected = "Rejected";
}

public static class Outcomes
{
    public const string Active = "Active", Selected = "Selected", Rejected = "Rejected", Withdrawn = "Withdrawn";
}

public static class Decisions
{
    public const string Pending = "Pending", Approved = "Approved", Rejected = "Rejected";
}

public static class InterviewStatuses
{
    public const string Scheduled = "Scheduled", Completed = "Completed", Cancelled = "Cancelled";
}

/// <summary>Referral stages. Interview round N sits at stage N + 2.</summary>
public static class Stages
{
    public const byte Referred = 1, HrReview = 2, Interview1 = 3, Interview2 = 4, Interview3 = 5, FinalApproval = 6;

    static readonly string[] Names = ["", "Referred", "HR review", "Interview 1", "Interview 2", "Interview 3", "Final approval"];

    public static byte ForRound(int round) => (byte)(round + 2);
    public static string Name(byte id) => id < Names.Length ? Names[id] : "";
}

public static class Clock
{
    public static DateTime Now => DateTime.UtcNow;
    /// <summary>Today's date in India (UTC+5:30), used for hire-by checks.</summary>
    public static DateOnly Today => DateOnly.FromDateTime(DateTime.UtcNow.AddHours(5.5));
}
