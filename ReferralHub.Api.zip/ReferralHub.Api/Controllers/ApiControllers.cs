using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Identity.Web.Resource;
using ReferralHub.Api.Data;
using ReferralHub.Api.Domain;
using ReferralHub.Api.Dtos;
using ReferralHub.Api.Infrastructure;
using ReferralHub.Api.Services;

namespace ReferralHub.Api.Controllers;

// All endpoints need a valid Entra ID token that carries the access_as_user scope.

[ApiController, Authorize, RequiredScope("access_as_user"), Route("api")]
public class MeController(CurrentUser me, AppDbContext db) : ControllerBase
{
    /// <summary>Who am I and which roles do I have. The web part uses this to decide which screens to show.</summary>
    [HttpGet("me")]
    public async Task<object> Me(CancellationToken ct)
    {
        var e = await me.GetAsync(ct);
        return new { e.EmployeeId, e.DisplayName, e.Email, e.JobTitle, Roles = await me.RolesAsync(ct) };
    }

    [HttpGet("lookups")]
    public async Task<object> Lookups(CancellationToken ct)
    {
        await me.GetAsync(ct);
        return new
        {
            Departments = await db.Departments.AsNoTracking().OrderBy(x => x.Name).Select(x => new LookupItem(x.DepartmentId, x.Name)).ToListAsync(ct),
            Locations = await db.Locations.AsNoTracking().OrderBy(x => x.Name).Select(x => new LookupItem(x.LocationId, x.Name)).ToListAsync(ct)
        };
    }
}

[ApiController, Authorize, RequiredScope("access_as_user"), Route("api")]
public class RequisitionsController(RequisitionService svc) : ControllerBase
{
    /// <summary>Approved, open positions for all employees.</summary>
    [HttpGet("positions")]
    public Task<List<PositionDto>> Positions([FromQuery] string? department, [FromQuery] string? q, CancellationToken ct)
        => svc.OpenPositionsAsync(department, q, ct);

    /// <summary>Manager raises a requisition. It starts with the department head.</summary>
    [HttpPost("requisitions")]
    public async Task<IActionResult> Create(CreateRequisitionDto dto, CancellationToken ct)
        => Ok(new { id = await svc.CreateAsync(dto, ct) });

    [HttpGet("requisitions/mine")]
    public Task<List<RequisitionDto>> Mine(CancellationToken ct) => svc.MineAsync(ct);

    [HttpGet("requisitions")]
    public Task<List<RequisitionDto>> All(CancellationToken ct) => svc.AllAsync(ct);

    /// <summary>Requisitions waiting for my approval (Dept head, Div head or HR head).</summary>
    [HttpGet("approvals/requisitions")]
    public Task<List<RequisitionDto>> Inbox(CancellationToken ct) => svc.InboxAsync(ct);

    /// <summary>Approval history with date, time and person for each event.</summary>
    [HttpGet("requisitions/{id:int}/history")]
    public Task<List<HistoryItemDto>> History(int id, CancellationToken ct) => svc.HistoryAsync(id, ct);

    [HttpPost("requisitions/{id:int}/approve")]
    public async Task<IActionResult> Approve(int id, DecisionDto? dto, CancellationToken ct)
    { await svc.ApproveAsync(id, dto?.Comments, ct); return NoContent(); }

    [HttpPost("requisitions/{id:int}/reject")]
    public async Task<IActionResult> Reject(int id, RejectDto dto, CancellationToken ct)
    { await svc.RejectAsync(id, dto.Reason, ct); return NoContent(); }
}

[ApiController, Authorize, RequiredScope("access_as_user"), Route("api")]
public class ReferralsController(ReferralService svc) : ControllerBase
{
    /// <summary>Any employee refers a candidate against an open position.</summary>
    [HttpPost("positions/{requisitionId:int}/referrals")]
    public async Task<IActionResult> Submit(int requisitionId, SubmitReferralDto dto, CancellationToken ct)
        => Ok(new { id = await svc.SubmitAsync(requisitionId, dto, ct) });

    [HttpGet("referrals/mine")]
    public Task<List<MyReferralDto>> Mine(CancellationToken ct) => svc.MineAsync(ct);

    /// <summary>Status page for the referring employee (progress and milestones, no feedback).</summary>
    [HttpGet("referrals/mine/{id:int}")]
    public Task<MyReferralStatusDto> MyStatus(int id, CancellationToken ct) => svc.MyStatusAsync(id, ct);

    /// <summary>HR pipeline. Optional filters: stage id (1-6) and outcome (Active, Selected, Rejected).</summary>
    [HttpGet("referrals")]
    public Task<List<PipelineRowDto>> Pipeline([FromQuery] byte? stage, [FromQuery] string? outcome, CancellationToken ct)
        => svc.PipelineAsync(stage, outcome, ct);

    [HttpGet("referrals/{id:int}")]
    public Task<ReferralDetailDto> Detail(int id, CancellationToken ct) => svc.GetAsync(id, ct);

    [HttpPost("referrals/{id:int}/contact")]
    public async Task<IActionResult> Contact(int id, CancellationToken ct) { await svc.ContactAsync(id, ct); return NoContent(); }

    [HttpPost("referrals/{id:int}/shortlist")]
    public async Task<IActionResult> Shortlist(int id, CancellationToken ct) { await svc.ShortlistAsync(id, ct); return NoContent(); }

    [HttpPost("referrals/{id:int}/close")]
    public async Task<IActionResult> Close(int id, RejectDto dto, CancellationToken ct) { await svc.CloseAsync(id, dto.Reason, ct); return NoContent(); }

    /// <summary>Interviewer dropdown for a round (employees with the INTERVIEWER role).</summary>
    [HttpGet("interviewers")]
    public Task<List<InterviewerDto>> Interviewers([FromQuery] int round, CancellationToken ct) => svc.InterviewersAsync(round, ct);

    /// <summary>Schedule or reschedule round 1, 2 or 3 and send the Teams meeting invite.</summary>
    [HttpPut("referrals/{id:int}/interviews/{round:int}")]
    public Task<ScheduleResultDto> Schedule(int id, int round, ScheduleDto dto, CancellationToken ct)
        => svc.ScheduleAsync(id, round, dto, ct);

    [HttpPost("interviews/{interviewId:int}/resend-invite")]
    public Task<ScheduleResultDto> ResendInvite(int interviewId, CancellationToken ct) => svc.ResendInviteAsync(interviewId, ct);

    /// <summary>Interviewer's own interviews (upcoming and past).</summary>
    [HttpGet("interviews/mine")]
    public Task<List<MyInterviewDto>> MyInterviews(CancellationToken ct) => svc.MyInterviewsAsync(ct);

    /// <summary>Feedback after every round (interviewer or HR).</summary>
    [HttpPost("interviews/{interviewId:int}/feedback")]
    public async Task<IActionResult> Feedback(int interviewId, FeedbackDto dto, CancellationToken ct)
    { await svc.SubmitFeedbackAsync(interviewId, dto, ct); return NoContent(); }

    /// <summary>HR records the joining date once a selected candidate actually joins. Unlocks the bonus request.</summary>
    [HttpPost("referrals/{id:int}/join")]
    public async Task<IActionResult> MarkJoined(int id, MarkJoinedDto dto, CancellationToken ct)
    { await svc.MarkJoinedAsync(id, dto, ct); return NoContent(); }

    /// <summary>Candidates waiting for my final decision (Division head or HR head).</summary>
    [HttpGet("approvals/hiring")]
    public Task<List<PipelineRowDto>> HiringInbox(CancellationToken ct) => svc.HiringInboxAsync(ct);

    [HttpPost("referrals/{id:int}/final-approval/approve")]
    public async Task<IActionResult> FinalApprove(int id, DecisionDto? dto, CancellationToken ct)
    { await svc.FinalDecisionAsync(id, true, dto?.Comments, ct); return NoContent(); }

    [HttpPost("referrals/{id:int}/final-approval/reject")]
    public async Task<IActionResult> FinalReject(int id, RejectDto dto, CancellationToken ct)
    { await svc.FinalDecisionAsync(id, false, dto.Reason, ct); return NoContent(); }
}

/// <summary>Referral bonus: requested by the referring employee once their candidate has joined.</summary>
[ApiController, Authorize, RequiredScope("access_as_user"), Route("api")]
public class BonusesController(BonusService svc) : ControllerBase
{
    [HttpPost("referrals/{id:int}/bonus-request")]
    public async Task<IActionResult> Request(int id, BonusRequestDto dto, CancellationToken ct)
        => Ok(new { id = await svc.RequestAsync(id, dto, ct) });

    [HttpGet("bonuses/mine")]
    public Task<List<BonusDto>> Mine(CancellationToken ct) => svc.MineAsync(ct);

    /// <summary>HR queue. Optional filter: Requested, Approved, Rejected or Paid.</summary>
    [HttpGet("bonuses")]
    public Task<List<BonusDto>> All([FromQuery] string? status, CancellationToken ct) => svc.AllAsync(status, ct);

    [HttpGet("bonuses/{id:int}")]
    public Task<BonusDto> Get(int id, CancellationToken ct) => svc.GetAsync(id, ct);

    [HttpPost("bonuses/{id:int}/approve")]
    public async Task<IActionResult> Approve(int id, BonusDecisionDto dto, CancellationToken ct)
    { await svc.DecideAsync(id, true, dto, ct); return NoContent(); }

    [HttpPost("bonuses/{id:int}/reject")]
    public async Task<IActionResult> Reject(int id, BonusDecisionDto dto, CancellationToken ct)
    { await svc.DecideAsync(id, false, dto, ct); return NoContent(); }

    [HttpPost("bonuses/{id:int}/pay")]
    public async Task<IActionResult> Pay(int id, BonusPayDto dto, CancellationToken ct)
    { await svc.PayAsync(id, dto, ct); return NoContent(); }
}

/// <summary>Master data: employees, role assignment, departments, divisions, locations, skills. ADMIN role only.</summary>
[ApiController, Authorize, RequiredScope("access_as_user"), Route("api/admin")]
public class AdminController(AdminService svc) : ControllerBase
{
    [HttpGet("employees")]
    public Task<List<EmployeeAdminDto>> Employees([FromQuery] string? q, CancellationToken ct) => svc.EmployeesAsync(q, ct);

    [HttpPost("employees")]
    public async Task<IActionResult> CreateEmployee(UpsertEmployeeDto dto, CancellationToken ct)
        => Ok(new { id = await svc.CreateEmployeeAsync(dto, ct) });

    [HttpPut("employees/{id:int}")]
    public async Task<IActionResult> UpdateEmployee(int id, UpsertEmployeeDto dto, CancellationToken ct)
    { await svc.UpdateEmployeeAsync(id, dto, ct); return NoContent(); }

    /// <summary>Body: a plain array of role codes, e.g. ["MANAGER","INTERVIEWER"]. Employee role is kept automatically.</summary>
    [HttpPut("employees/{id:int}/roles")]
    public async Task<IActionResult> SetRoles(int id, List<string> roles, CancellationToken ct)
    { await svc.SetRolesAsync(id, roles, ct); return NoContent(); }

    [HttpGet("divisions")]
    public Task<List<DivisionAdminDto>> Divisions(CancellationToken ct) => svc.DivisionsAsync(ct);

    [HttpPost("divisions")]
    public async Task<IActionResult> CreateDivision(UpsertDivisionDto dto, CancellationToken ct)
        => Ok(new { id = await svc.CreateDivisionAsync(dto, ct) });

    [HttpPut("divisions/{id:int}")]
    public async Task<IActionResult> UpdateDivision(int id, UpsertDivisionDto dto, CancellationToken ct)
    { await svc.UpdateDivisionAsync(id, dto, ct); return NoContent(); }

    [HttpGet("departments")]
    public Task<List<DepartmentAdminDto>> Departments(CancellationToken ct) => svc.DepartmentsAsync(ct);

    [HttpPost("departments")]
    public async Task<IActionResult> CreateDepartment(UpsertDepartmentDto dto, CancellationToken ct)
        => Ok(new { id = await svc.CreateDepartmentAsync(dto, ct) });

    [HttpPut("departments/{id:int}")]
    public async Task<IActionResult> UpdateDepartment(int id, UpsertDepartmentDto dto, CancellationToken ct)
    { await svc.UpdateDepartmentAsync(id, dto, ct); return NoContent(); }

    [HttpGet("locations")]
    public Task<List<LookupItem>> Locations(CancellationToken ct) => svc.LocationsAsync(ct);

    [HttpPost("locations")]
    public async Task<IActionResult> CreateLocation(UpsertLocationDto dto, CancellationToken ct)
        => Ok(new { id = await svc.CreateLocationAsync(dto, ct) });

    [HttpGet("skills")]
    public Task<List<LookupItem>> Skills(CancellationToken ct) => svc.SkillsAsync(ct);

    [HttpPost("skills")]
    public async Task<IActionResult> CreateSkill(UpsertSkillDto dto, CancellationToken ct)
        => Ok(new { id = await svc.CreateSkillAsync(dto, ct) });
}
