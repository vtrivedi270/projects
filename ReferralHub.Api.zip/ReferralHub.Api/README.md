# Referral Hub API v3 (.NET 8, EF Core, SQL Server, Microsoft Graph)

Backend for the SPFx (React) referral portal. Not compiled in the authoring environment: run `dotnet build` first and fix any typos.

## Set up
1. Run `ReferralHub_schema.sql`, then `ReferralHub_v2_upgrade.sql`, then `ReferralHub_v3_upgrade.sql` in order (interviewer role and invites, then joining date, referral bonus, and the ADMIN role).
2. Run the seed script below (first users and roles), then give people the INTERVIEWER role and one person the ADMIN role (examples at the end of the v2 and v3 scripts).
3. `appsettings.json`: connection string, `AzureAd`, `Cors:Origins`, `App:BaseUrl` (link used in emails), `Graph`, `Notifications`.
4. `dotnet run`, then `/swagger` (Development only).

## Entra ID (two app registrations)
**A. API app (for the SPFx web part).** Expose an API: Application ID URI `api://<client-id>` and scope `access_as_user`. In the SPFx solution `config/package-solution.json` add
`"webApiPermissionRequests": [{ "resource": "<API app name>", "scope": "access_as_user" }]` and approve it in SharePoint admin center > Advanced > API access.

**B. Graph app (used by the server only).** Application permissions, with admin consent:
- `Mail.Send` (sends the notification emails as `Graph:SenderUpn`)
- `Calendars.ReadWrite` (creates the Teams meeting invite in `Graph:OrganizerUpn`'s calendar)

Use two shared mailboxes (for example hr-notifications@ and hr-interviews@) and limit the app to only those with an Exchange Application Access Policy. Put `Graph:ClientSecret` in Key Vault or user-secrets, not in the file.

## Emails (every stage and activity)
All emails are queued in `rp.Notification` in the same transaction as the change, then sent by `NotificationWorker` every 30 seconds (5 attempts, then Failed). Times in emails are shown in IST.

| Event | Who gets the email |
|---|---|
| Requisition submitted | Department head (approve), requester (confirmation) |
| Step approved | Next approver (approve), requester (who approved, when) |
| Third approval, position live | Requester, all-employees list |
| Requisition rejected | Requester (name, reason, time) |
| Referral submitted | HR team, referrer (confirmation) |
| HR contacted | Referrer |
| Shortlisted | Referrer |
| Interview scheduled or rescheduled | Interviewer, referrer, assigned HR; Teams invite to interviewer, candidate and HR |
| Interview reminder (24 hours before) | Interviewer |
| Feedback submitted | Assigned HR (result and next step), referrer ("interview completed", no result) |
| After round 3, final approval opens | Division head, HR head, HR team |
| One head approves | Assigned HR |
| Selected | Referrer, HR team, hiring manager |
| Rejected or closed at any stage | Referrer, assigned HR |

## Referral bonus
- After a candidate is `Selected`, HR records the joining date: `POST /api/referrals/{id}/join`. This emails the referrer and unlocks the bonus request.
- The referring employee (and only them) submits the request: `POST /api/referrals/{id}/bonus-request`. One request per referral. The request shows the department's `DefaultBonusAmount` as a guide only.
- HR approves with a final amount, rejects with a reason, or later marks it paid with an optional payout reference (a payroll batch or voucher number, never an account number): `POST /api/bonuses/{id}/approve|reject|pay`.
- `rp.ReferralBonusHistory` is an append-only audit trail (protected by a trigger), and every step emails the requester.
- The employee's own requests: `GET /api/bonuses/mine`. HR's queue with an optional status filter: `GET /api/bonuses?status=Requested`.

## Master data (ADMIN role)
- `GET/POST/PUT /api/admin/employees` and `PUT /api/admin/employees/{id}/roles` (send a plain array of role codes; `EMPLOYEE` is always kept).
- `GET/POST/PUT /api/admin/departments` and `/divisions` (sets the approval chain for new requisitions: department head, then division head).
- `GET/POST /api/admin/locations` and `/skills`.
- Everything here is ADMIN-only. Changing a department's or division's head only changes routing for requisitions created afterwards; it does not move an approval already in flight.

## Interviewer role
- Role code `INTERVIEWER`. Scheduling shows only people who hold it: `GET /api/interviewers?round=1`.
- `rp.InterviewerRound` limits which rounds a person takes. No rows means any round.
- The referrer can never be the interviewer of their own referral.
- Interview time, duration (30, 45, 60, 90 minutes) and a Teams invite are set when HR schedules. If Graph fails, the interview is still saved and HR can call resend-invite.
- Interviewers use `GET /api/interviews/mine` and submit feedback for their own interviews only.

## History and "approved by"
- `rp.RequisitionHistory` (append-only, protected by a trigger): Submitted, Approved, Rejected, Published, each with person and date/time. `GET /api/requisitions/{id}/history`.
- Each approval step returns the assigned approver, who acted, and when (`ActedBy`, `ActedOn`).
- `rp.ReferralActivity` is the referral timeline with actor, time, stage change and interview round. Final approvals keep `DecidedBy` and `DecidedOn`.
- The referring employee sees only milestones marked `VisibleToReferrer` (no feedback, ratings or reasons): `GET /api/referrals/mine/{id}`.

## Endpoints
| Who | Method and route | What it does |
|---|---|---|
| Everyone | GET `/api/me`, `/api/lookups` | Name and roles, departments and locations |
| Everyone | GET `/api/positions?department=&q=` | Approved, open positions |
| Everyone | POST `/api/positions/{id}/referrals` | Submit a referral (candidate details + resume link) |
| Everyone | GET `/api/referrals/mine` and `/api/referrals/mine/{id}` | My referrals, and the status page for one |
| Manager | POST `/api/requisitions`, GET `/api/requisitions/mine` | Raise a requisition, see my requisitions |
| Approver | GET `/api/approvals/requisitions` | Requisitions waiting for me |
| Approver | POST `/api/requisitions/{id}/approve` or `/reject` | Approve, or reject with a reason |
| Requester, approvers, HR | GET `/api/requisitions/{id}/history` | Approval history |
| HR | GET `/api/requisitions` | All requisitions |
| HR | GET `/api/referrals?stage=&outcome=` | Candidate pipeline |
| HR, heads, interviewers | GET `/api/referrals/{id}` | Detail with feedback and timeline |
| HR | POST `/api/referrals/{id}/contact`, `/shortlist`, `/close` | Stage moves |
| HR | GET `/api/interviewers?round=` | Interviewer dropdown |
| HR | PUT `/api/referrals/{id}/interviews/{round}` | Schedule or reschedule and send the invite |
| HR | POST `/api/interviews/{id}/resend-invite` | Resend the calendar invite |
| Interviewer | GET `/api/interviews/mine` | My interviews |
| Interviewer, HR | POST `/api/interviews/{id}/feedback` | Rating, Proceed or Reject, comments |
| Div head, HR head | GET `/api/approvals/hiring` | Candidates waiting for my final decision |
| Div head, HR head | POST `/api/referrals/{id}/final-approval/approve` or `/reject` | Final decision |
| HR | POST `/api/referrals/{id}/join` | Record the candidate's joining date |
| Referrer | POST `/api/referrals/{id}/bonus-request` | Request the referral bonus |
| Referrer | GET `/api/bonuses/mine` | My bonus requests |
| HR | GET `/api/bonuses?status=`, GET `/api/bonuses/{id}` | Bonus queue and detail |
| HR | POST `/api/bonuses/{id}/approve`, `/reject`, `/pay` | Decide and pay |
| Admin | `/api/admin/employees`, `/divisions`, `/departments`, `/locations`, `/skills` | Master data |

Schedule body: `{ "interviewerEmployeeId": 5, "scheduledAt": "2026-09-22T05:30:00Z", "durationMinutes": 60, "sendInvite": true }`

## Rules the services enforce
- Requisition: Dept head, Div head, HR head in order. The third approval sets status `Open`. A rejection needs a reason.
- Referral only for `Open` positions before the hire-by date and not filled. Same candidate email cannot be referred twice for one job.
- Interview round N is schedulable only at stage N + 2, so round 2 unlocks after round 1 feedback.
- Feedback `Reject` closes the referral. `Proceed` opens the next round, and after round 3 opens final approval.
- Final approval needs both the Division head and the HR head. One rejection closes it. Two approvals set `Selected` and add 1 to `PositionsFilled`.
- `UpdatedOn` changes on every action, so the `rowversion` check returns HTTP 409 if two people act at once.

## Seed script (edit the emails)
```sql
USE ReferralHub;
INSERT rp.Employee(Email, DisplayName, JobTitle) VALUES
 ('mahesh@yourtenant.com','Mahesh Vaghela','Department Head'),
 ('kavita@yourtenant.com','Kavita Rao','Division Head'),
 ('suresh@yourtenant.com','Suresh Iyer','HR Head'),
 ('neha@yourtenant.com','Neha Trivedi','HR Manager'),
 ('sanjay@yourtenant.com','Sanjay Bhatt','Engineering Manager'),
 ('hitesh@yourtenant.com','Hitesh Vora','Tech Lead'),
 ('riya@yourtenant.com','Riya Desai','Software Engineer');

INSERT rp.Division(Name, DivisionHeadEmployeeId)
 SELECT 'Technology', EmployeeId FROM rp.Employee WHERE Email='kavita@yourtenant.com';
INSERT rp.Department(DivisionId, Name, DepartmentHeadEmployeeId)
 SELECT d.DivisionId, 'Engineering', e.EmployeeId
 FROM rp.Division d CROSS JOIN rp.Employee e WHERE d.Name='Technology' AND e.Email='mahesh@yourtenant.com';
UPDATE rp.Employee SET DepartmentId = (SELECT DepartmentId FROM rp.Department WHERE Name='Engineering');

INSERT rp.EmployeeRole(EmployeeId, RoleId)
 SELECT e.EmployeeId, r.RoleId
 FROM (VALUES
   ('mahesh@yourtenant.com','DEPT_HEAD'),('kavita@yourtenant.com','DIV_HEAD'),('suresh@yourtenant.com','HR_HEAD'),
   ('neha@yourtenant.com','HR'),('sanjay@yourtenant.com','MANAGER'),('hitesh@yourtenant.com','INTERVIEWER'),
   ('kavita@yourtenant.com','INTERVIEWER')) v(Email, Code)
 JOIN rp.Employee e ON e.Email = v.Email JOIN rp.AppRole r ON r.Code = v.Code;
-- everyone is also an employee
INSERT rp.EmployeeRole(EmployeeId, RoleId)
 SELECT EmployeeId, (SELECT RoleId FROM rp.AppRole WHERE Code='EMPLOYEE') FROM rp.Employee;
```

## Next
Resume upload from the web part to a SharePoint library (then send the file URL to the referral endpoint), and unit tests for the stage rules in `ReferralService`.

## Seed addition for v3 (edit the email)
```sql
INSERT rp.EmployeeRole(EmployeeId, RoleId)
SELECT EmployeeId, 8 FROM rp.Employee WHERE Email = 'suresh@yourtenant.com'
  AND NOT EXISTS (SELECT 1 FROM rp.EmployeeRole x WHERE x.EmployeeId = rp.Employee.EmployeeId AND x.RoleId = 8);
UPDATE rp.Department SET DefaultBonusAmount = 25000 WHERE Name = 'Engineering';
```
