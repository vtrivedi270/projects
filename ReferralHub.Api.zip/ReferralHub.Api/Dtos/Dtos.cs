using ReferralHub.Api.Domain;

namespace ReferralHub.Api.Dtos;

// ----- Requests -----
public record CreateRequisitionDto(
    string Title, int DepartmentId, int LocationId, string? EmploymentType, short NoOfPositions,
    string? ExperienceRequired, DateOnly HireByDate, string Summary, string Requirements, List<string>? Skills);

public record DecisionDto(string? Comments);
public record RejectDto(string Reason);

/// <summary>The SPFx web part uploads the resume to a SharePoint library first, then sends its details here.</summary>
public record ResumeDto(string FileName, string ContentType, long SizeBytes, string StorageUrl);

public record SubmitReferralDto(
    string CandidateName, string CandidateEmail, string CandidatePhone, decimal TotalExperienceYears,
    string? CurrentCompany, string? NoticePeriod, string? Relationship, string? ReferrerNote, ResumeDto Resume);

/// <summary>ScheduledAt must be UTC (ISO 8601 with Z). DurationMinutes: 30, 45, 60 or 90. SendInvite defaults to true.</summary>
public record ScheduleDto(int InterviewerEmployeeId, DateTime ScheduledAt, int? DurationMinutes, bool? SendInvite);
public record FeedbackDto(byte Rating, string Recommendation, string Comments);

// ----- Responses -----
public record PositionDto(
    int Id, string Title, string Department, string Location, string EmploymentType, int Openings,
    string? Experience, DateOnly HireBy, string Summary, string Requirements, List<string> Skills, int ReferralCount)
{
    public int DaysLeft => HireBy.DayNumber - Clock.Today.DayNumber;
}

/// <summary>Approver = who the step is assigned to. ActedBy and ActedOn = who approved or rejected it, and when.</summary>
public record ApprovalStepDto(byte StepNo, string Role, string Approver, string Status, string? ActedBy, DateTime? ActedOn, string? Comments);

public record RequisitionDto(
    int Id, string Title, string Department, string Location, int Positions, string? Experience, DateOnly HireBy,
    string Summary, string Status, string RequestedBy, DateTime CreatedOn, string? RejectionReason,
    List<ApprovalStepDto> Steps);

public record HistoryItemDto(DateTime On, string Event, byte? StepNo, string By, string? FromStatus, string? ToStatus, string? Comments);

public record MyReferralDto(int Id, string Candidate, string Position, DateTime ReferredOn, byte StageId, string Outcome)
{
    public string Stage => Stages.Name(StageId);
}

/// <summary>State is done, current, closed or todo.</summary>
public record StatusStepDto(string Name, string State);
public record StatusEventDto(DateTime On, string Label, string? Detail);

/// <summary>What the referring employee sees: stage progress and milestones. No feedback, ratings or reasons.</summary>
public record MyReferralStatusDto(
    int Id, string Candidate, string Position, DateTime ReferredOn, byte StageId, string Stage, string Outcome,
    string NextStep, List<StatusStepDto> Steps, List<StatusEventDto> Events);

public record PipelineRowDto(
    int Id, string Candidate, string Position, string ReferredBy, DateTime ReferredOn, byte StageId, string Outcome,
    double? AvgRating, DateTime? NextInterviewAt)
{
    public string Stage => Stages.Name(StageId);
}

public record ResumeInfo(string FileName, string Url);
public record FeedbackView(byte Rating, string Recommendation, string Comments, string By, DateTime On);
public record InterviewView(
    int Id, byte Round, int InterviewerId, string Interviewer, DateTime ScheduledAt, int DurationMinutes, string Mode,
    string? MeetingLink, string Status, string InviteStatus, DateTime? InviteSentOn, FeedbackView? Feedback);
public record FinalView(string Role, string Decision, string? By, DateTime? On, string? Comments);
public record TimelineItem(string Type, string By, string? Notes, DateTime On, byte? FromStage, byte? ToStage, byte? Round);

public record ReferralDetailDto(
    int Id, string Candidate, string Email, string Phone, decimal ExperienceYears, string? Company,
    string? NoticePeriod, string? Relationship, string? ReferrerNote, int RequisitionId, string Position,
    string ReferredBy, DateTime ReferredOn, byte StageId, string Stage, string Outcome, string? ClosedReason,
    DateOnly? JoinedOn, ResumeInfo? Resume, List<InterviewView> Interviews, List<FinalView> FinalApprovals, List<TimelineItem> Timeline);

public record InterviewerDto(int Id, string Name, string? Title);
public record MyInterviewDto(
    int InterviewId, int ReferralId, string Candidate, string Position, byte Round, DateTime ScheduledAt,
    int DurationMinutes, string? MeetingLink, string Status, string? ResumeUrl);
public record ScheduleResultDto(int InterviewId, string InviteStatus, string? MeetingLink, string? Warning);
public record LookupItem(int Id, string Name);

// ----- Referral bonus -----
public record MarkJoinedDto(DateOnly JoinedOn);
public record BonusRequestDto(string? Comments);
public record BonusDecisionDto(decimal? Amount, string? Comments);
public record BonusPayDto(string? PayoutReference, string? Comments);

public record BonusHistoryItemDto(DateTime On, string Event, string By, string? Comments);
public record BonusDto(
    int Id, int ReferralId, string Candidate, string Position, string RequestedBy, DateTime RequestedOn,
    decimal? RequestedAmount, decimal? ApprovedAmount, string Status, string? DecidedBy, DateTime? DecidedOn,
    string? PaidBy, DateTime? PaidOn, string? PayoutReference, string? Comments, List<BonusHistoryItemDto> History);

// ----- Master data (admin) -----
public record UpsertDepartmentDto(string Name, int DivisionId, int DepartmentHeadEmployeeId, decimal? DefaultBonusAmount);
public record UpsertDivisionDto(string Name, int DivisionHeadEmployeeId);
public record UpsertLocationDto(string Name);
public record UpsertSkillDto(string Name);

public record UpsertEmployeeDto(
    string Email, string DisplayName, string? JobTitle, int? DepartmentId, int? ManagerEmployeeId,
    bool? IsActive, List<string>? Roles);

public record EmployeeAdminDto(
    int Id, string Email, string DisplayName, string? JobTitle, string? Department, string? Manager,
    bool IsActive, List<string> Roles, DateTime CreatedOn);

public record DivisionAdminDto(int Id, string Name, string HeadName, int DepartmentCount);
public record DepartmentAdminDto(int Id, string Name, string Division, string HeadName, decimal? DefaultBonusAmount);
