using Microsoft.EntityFrameworkCore;
using ReferralHub.Api.Domain;

namespace ReferralHub.Api.Data;

/// <summary>Maps to the existing SQL Server schema created by ReferralHub_schema.sql (database-first).</summary>
public class AppDbContext(DbContextOptions<AppDbContext> options) : DbContext(options)
{
    public DbSet<Employee> Employees => Set<Employee>();
    public DbSet<Division> Divisions => Set<Division>();
    public DbSet<Department> Departments => Set<Department>();
    public DbSet<AppRole> AppRoles => Set<AppRole>();
    public DbSet<EmployeeRole> EmployeeRoles => Set<EmployeeRole>();
    public DbSet<Location> Locations => Set<Location>();
    public DbSet<Skill> Skills => Set<Skill>();
    public DbSet<ReferralStage> ReferralStages => Set<ReferralStage>();
    public DbSet<JobRequisition> Requisitions => Set<JobRequisition>();
    public DbSet<JobRequisitionSkill> RequisitionSkills => Set<JobRequisitionSkill>();
    public DbSet<RequisitionApproval> RequisitionApprovals => Set<RequisitionApproval>();
    public DbSet<Referral> Referrals => Set<Referral>();
    public DbSet<ReferralDocument> ReferralDocuments => Set<ReferralDocument>();
    public DbSet<ReferralActivity> ReferralActivities => Set<ReferralActivity>();
    public DbSet<Interview> Interviews => Set<Interview>();
    public DbSet<InterviewFeedback> InterviewFeedbacks => Set<InterviewFeedback>();
    public DbSet<FinalApproval> FinalApprovals => Set<FinalApproval>();
    public DbSet<Notification> Notifications => Set<Notification>();
    public DbSet<RequisitionHistory> RequisitionHistory => Set<RequisitionHistory>();
    public DbSet<InterviewerRound> InterviewerRounds => Set<InterviewerRound>();
    public DbSet<ReferralBonus> ReferralBonuses => Set<ReferralBonus>();
    public DbSet<ReferralBonusHistory> ReferralBonusHistory => Set<ReferralBonusHistory>();

    protected override void OnModelCreating(ModelBuilder b)
    {
        b.HasDefaultSchema("rp");
        // Tables are singular in the database (rp.Employee, rp.Referral, ...)
        foreach (var e in b.Model.GetEntityTypes()) e.SetTableName(e.ClrType.Name);

        b.Entity<EmployeeRole>(e =>
        {
            e.HasKey(x => new { x.EmployeeId, x.RoleId });
            e.HasOne(x => x.Employee).WithMany(x => x.Roles).HasForeignKey(x => x.EmployeeId);
            e.HasOne(x => x.Role).WithMany().HasForeignKey(x => x.RoleId);
        });

        b.Entity<Department>().HasOne(x => x.Division).WithMany().HasForeignKey(x => x.DivisionId);

        b.Entity<JobRequisition>(e =>
        {
            e.HasOne(x => x.Department).WithMany().HasForeignKey(x => x.DepartmentId);
            e.HasOne(x => x.Location).WithMany().HasForeignKey(x => x.LocationId);
            e.HasOne(x => x.RequestedBy).WithMany().HasForeignKey(x => x.RequestedByEmployeeId);
            e.HasMany(x => x.Skills).WithOne().HasForeignKey(x => x.RequisitionId);
            e.HasMany(x => x.Approvals).WithOne().HasForeignKey(x => x.RequisitionId);
            e.HasMany(x => x.History).WithOne().HasForeignKey(x => x.RequisitionId);
        });

        b.Entity<RequisitionHistory>().HasOne(x => x.Actor).WithMany().HasForeignKey(x => x.ActorEmployeeId);
        b.Entity<InterviewerRound>().HasKey(x => new { x.EmployeeId, x.RoundNo });
        b.Entity<Notification>().HasOne(x => x.Recipient).WithMany().HasForeignKey(x => x.RecipientEmployeeId);

        b.Entity<JobRequisitionSkill>(e =>
        {
            e.HasKey(x => new { x.RequisitionId, x.SkillId });
            e.HasOne(x => x.Skill).WithMany().HasForeignKey(x => x.SkillId);
        });

        b.Entity<RequisitionApproval>(e =>
        {
            e.HasOne(x => x.Approver).WithMany().HasForeignKey(x => x.ApproverEmployeeId);
            e.HasOne(x => x.ActedBy).WithMany().HasForeignKey(x => x.ActedByEmployeeId);
        });

        b.Entity<Referral>(e =>
        {
            e.HasOne(x => x.Requisition).WithMany().HasForeignKey(x => x.RequisitionId);
            e.HasOne(x => x.ReferredBy).WithMany().HasForeignKey(x => x.ReferredByEmployeeId);
            e.HasMany(x => x.Documents).WithOne().HasForeignKey(x => x.ReferralId);
            e.HasMany(x => x.Activities).WithOne().HasForeignKey(x => x.ReferralId);
            e.HasMany(x => x.Interviews).WithOne(i => i.Referral).HasForeignKey(i => i.ReferralId);
            e.HasMany(x => x.FinalApprovals).WithOne().HasForeignKey(f => f.ReferralId);
            e.HasOne(x => x.Bonus).WithOne(bo => bo.Referral!).HasForeignKey<ReferralBonus>(bo => bo.ReferralId);
        });

        b.Entity<ReferralBonus>(e =>
        {
            e.HasOne(x => x.RequestedBy).WithMany().HasForeignKey(x => x.RequestedByEmployeeId);
            e.HasOne(x => x.DecidedBy).WithMany().HasForeignKey(x => x.DecidedByEmployeeId);
            e.HasOne(x => x.PaidBy).WithMany().HasForeignKey(x => x.PaidByEmployeeId);
            e.HasMany(x => x.History).WithOne().HasForeignKey(h => h.BonusId);
        });
        b.Entity<ReferralBonusHistory>().HasOne(x => x.Actor).WithMany().HasForeignKey(x => x.ActorEmployeeId);

        b.Entity<ReferralActivity>().HasOne(x => x.Actor).WithMany().HasForeignKey(x => x.ActorEmployeeId);

        b.Entity<Interview>(e =>
        {
            e.HasOne(x => x.Interviewer).WithMany().HasForeignKey(x => x.InterviewerEmployeeId);
            e.HasMany(x => x.Feedback).WithOne().HasForeignKey(f => f.InterviewId);
        });

        b.Entity<InterviewFeedback>().HasOne(x => x.SubmittedBy).WithMany().HasForeignKey(x => x.SubmittedByEmployeeId);

        b.Entity<FinalApproval>(e =>
        {
            e.HasKey(x => new { x.ReferralId, x.ApproverRole });
            e.HasOne(x => x.DecidedBy).WithMany().HasForeignKey(x => x.DecidedByEmployeeId);
        });
    }
}
