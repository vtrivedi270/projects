using System.Linq.Expressions;
using Microsoft.EntityFrameworkCore;
using ReferralHub.Api.Data;
using ReferralHub.Api.Domain;
using ReferralHub.Api.Dtos;
using ReferralHub.Api.Infrastructure;

namespace ReferralHub.Api.Services;

/// <summary>
/// Job requisition life cycle:
///   manager submits -> step 1 Dept head -> step 2 Div head -> step 3 HR head -> status Open (visible to all employees).
/// Any rejection ends the requisition with a reason.
/// Every action writes a row to rp.RequisitionHistory (who, what, when) and queues the emails.
/// </summary>
public class RequisitionService(AppDbContext db, CurrentUser me, Notifier notify, IConfiguration cfg)
{
    static readonly string[] EmploymentTypes = ["FullTime", "PartTime", "Contract"];

    static readonly Expression<Func<JobRequisition, RequisitionDto>> ToDto = j => new RequisitionDto(
        j.RequisitionId, j.Title, j.Department!.Name, j.Location!.Name, j.NoOfPositions, j.ExperienceRequired,
        j.HireByDate, j.Summary, j.Status, j.RequestedBy!.DisplayName, j.CreatedOn, j.RejectionReason,
        j.Approvals.OrderBy(a => a.StepNo)
            .Select(a => new ApprovalStepDto(a.StepNo, a.ApproverRole, a.Approver!.DisplayName, a.Status,
                                             a.ActedBy!.DisplayName, a.ActedOn, a.Comments))
            .ToList());

    // ---------- Commands ----------

    public async Task<int> CreateAsync(CreateRequisitionDto d, CancellationToken ct)
    {
        await me.RequireAsync(Roles.Manager, ct);
        var user = await me.GetAsync(ct);

        var title = d.Title?.Trim();
        if (string.IsNullOrEmpty(title)) throw new DomainException("Enter a job title.");
        if (title.Length > 200) throw new DomainException("The job title is too long.");
        if (d.NoOfPositions < 1) throw new DomainException("Number of positions must be at least 1.");
        if (d.HireByDate < Clock.Today) throw new DomainException("The hire-by date cannot be in the past.");
        if (string.IsNullOrWhiteSpace(d.Summary) || string.IsNullOrWhiteSpace(d.Requirements))
            throw new DomainException("Add the role summary and the requirements.");
        var type = d.EmploymentType ?? "FullTime";
        if (!EmploymentTypes.Contains(type)) throw new DomainException("Choose a valid employment type.");

        var dept = await db.Departments.Include(x => x.Division)
                       .FirstOrDefaultAsync(x => x.DepartmentId == d.DepartmentId, ct)
                   ?? throw new DomainException("Choose a valid department.");
        if (!await db.Locations.AnyAsync(x => x.LocationId == d.LocationId, ct))
            throw new DomainException("Choose a valid location.");

        // Approval chain: Dept head of the chosen department, Div head of its division, then the HR head
        var hrHeadId = await db.EmployeeRoles
            .Where(x => x.Role!.Code == Roles.HrHead && x.Employee!.IsActive)
            .Select(x => x.EmployeeId).FirstOrDefaultAsync(ct);
        if (hrHeadId == 0) throw new DomainException("No HR head is set up. Ask an administrator to assign the HR_HEAD role.");

        var now = Clock.Now;
        var req = new JobRequisition
        {
            Title = title, DepartmentId = dept.DepartmentId, LocationId = d.LocationId, EmploymentType = type,
            NoOfPositions = d.NoOfPositions, ExperienceRequired = d.ExperienceRequired?.Trim(), HireByDate = d.HireByDate,
            Summary = d.Summary.Trim(), Requirements = d.Requirements.Trim(), RequestedByEmployeeId = user.EmployeeId,
            Status = ReqStatus.PendingApproval, CreatedOn = now, UpdatedOn = now
        };

        req.Approvals.Add(new RequisitionApproval { StepNo = 1, ApproverRole = Roles.DeptHead, ApproverEmployeeId = dept.DepartmentHeadEmployeeId, Status = StepStatus.Pending });
        req.Approvals.Add(new RequisitionApproval { StepNo = 2, ApproverRole = Roles.DivHead, ApproverEmployeeId = dept.Division!.DivisionHeadEmployeeId, Status = StepStatus.Waiting });
        req.Approvals.Add(new RequisitionApproval { StepNo = 3, ApproverRole = Roles.HrHead, ApproverEmployeeId = hrHeadId, Status = StepStatus.Waiting });
        req.History.Add(new RequisitionHistory { EventType = "Submitted", ToStatus = ReqStatus.PendingApproval, ActorEmployeeId = user.EmployeeId, CreatedOn = now });

        // Skills: reuse existing rows (case-insensitive), create the rest
        var names = (d.Skills ?? []).Select(s => s.Trim()).Where(s => s.Length > 0 && s.Length <= 80)
            .Distinct(StringComparer.OrdinalIgnoreCase).Take(10).ToList();
        var existing = await db.Skills.Where(s => names.Contains(s.Name)).ToListAsync(ct);
        foreach (var n in names)
        {
            var skill = existing.FirstOrDefault(x => x.Name.Equals(n, StringComparison.OrdinalIgnoreCase)) ?? new Skill { Name = n };
            req.Skills.Add(new JobRequisitionSkill { Skill = skill });
        }

        db.Requisitions.Add(req);
        await using var tx = await db.Database.BeginTransactionAsync(ct);
        await db.SaveChangesAsync(ct);   // gets RequisitionId

        // Email 1: step 1 approver (action needed). Email 2: confirmation to the requester.
        notify.To(dept.DepartmentHeadEmployeeId, "RequisitionApprovalNeeded", $"Approval needed: {title}",
            "A job requisition needs your approval",
            [$"{user.DisplayName} raised a requisition for {title} in {dept.Name} ({d.NoOfPositions} position(s), hire by {d.HireByDate:dd MMM yyyy}).",
             "Your step: 1 of 3 (Department head, then Division head, then HR head)."],
            $"/approvals", "Requisition", req.RequisitionId);
        notify.To(user.EmployeeId, "RequisitionSubmitted", $"Submitted: {title}",
            "Your requisition was submitted",
            [$"{title} is now with the Department head for approval. You will get an email at every step."],
            $"/requisitions", "Requisition", req.RequisitionId);
        await db.SaveChangesAsync(ct);
        await tx.CommitAsync(ct);
        return req.RequisitionId;
    }

    public async Task ApproveAsync(int id, string? comments, CancellationToken ct)
    {
        var user = await me.GetAsync(ct);
        var req = await LoadPending(id, ct);
        var step = CurrentStep(req, user);
        var now = Clock.Now;

        step.Status = StepStatus.Approved;
        step.ActedOn = now;
        step.ActedByEmployeeId = user.EmployeeId;
        step.Comments = comments?.Trim();
        req.History.Add(new RequisitionHistory { EventType = "Approved", StepNo = step.StepNo, ActorEmployeeId = user.EmployeeId, Comments = step.Comments, CreatedOn = now });

        var next = req.Approvals.Where(a => a.StepNo > step.StepNo).OrderBy(a => a.StepNo).FirstOrDefault();
        var by = $"{user.DisplayName} ({Roles.Label(step.ApproverRole)})";
        if (next != null)
        {
            next.Status = StepStatus.Pending;
            notify.To(next.ApproverEmployeeId, "RequisitionApprovalNeeded", $"Approval needed: {req.Title}",
                "A job requisition needs your approval",
                [$"{req.Title} was approved by {by} on {EmailTemplate.Ist(now)}.", $"Your step: {next.StepNo} of 3 ({Roles.Label(next.ApproverRole)})."],
                "/approvals", "Requisition", req.RequisitionId);
            notify.To(req.RequestedByEmployeeId, "RequisitionStepApproved", $"Step {step.StepNo} approved: {req.Title}",
                $"Approved by {user.DisplayName}",
                [$"{Roles.Label(step.ApproverRole)} {user.DisplayName} approved {req.Title} on {EmailTemplate.Ist(now)}.", $"It is now with the {Roles.Label(next.ApproverRole).ToLowerInvariant()}."],
                "/requisitions", "Requisition", req.RequisitionId);
        }
        else
        {
            // Third approval: the job goes live for every employee
            req.Status = ReqStatus.Open;
            req.PublishedOn = now;
            req.History.Add(new RequisitionHistory { EventType = "Published", FromStatus = ReqStatus.PendingApproval, ToStatus = ReqStatus.Open, ActorEmployeeId = user.EmployeeId, CreatedOn = now });
            notify.To(req.RequestedByEmployeeId, "RequisitionApproved", $"Approved and live: {req.Title}",
                "All three approvals are done",
                [$"{req.Title} was approved by the {Roles.Label(step.ApproverRole).ToLowerInvariant()} {user.DisplayName} on {EmailTemplate.Ist(now)}.",
                 "The position is now open to all employees for referrals."],
                "/requisitions", "Requisition", req.RequisitionId);
            var everyone = cfg["Notifications:AllEmployeesAddress"];
            if (!string.IsNullOrWhiteSpace(everyone))
                notify.ToAddress(everyone, "PositionOpened", $"New open position: {req.Title}",
                    "A new position is open for referrals",
                    [$"{req.Title} ({req.NoOfPositions} position(s)). Refer someone you would enjoy working with."],
                    "/positions", "Requisition", req.RequisitionId);
        }
        req.UpdatedOn = now;
        await db.SaveChangesAsync(ct);
    }

    public async Task RejectAsync(int id, string reason, CancellationToken ct)
    {
        if (string.IsNullOrWhiteSpace(reason)) throw new DomainException("Add a reason so the requester knows what to change.");
        var user = await me.GetAsync(ct);
        var req = await LoadPending(id, ct);
        var step = CurrentStep(req, user);
        var now = Clock.Now;

        step.Status = StepStatus.Rejected;
        step.ActedOn = now;
        step.ActedByEmployeeId = user.EmployeeId;
        step.Comments = reason.Trim();
        req.Status = ReqStatus.Rejected;
        req.RejectionReason = reason.Trim();
        req.UpdatedOn = now;
        req.History.Add(new RequisitionHistory
        {
            EventType = "Rejected", StepNo = step.StepNo, FromStatus = ReqStatus.PendingApproval, ToStatus = ReqStatus.Rejected,
            ActorEmployeeId = user.EmployeeId, Comments = reason.Trim(), CreatedOn = now
        });
        notify.To(req.RequestedByEmployeeId, "RequisitionRejected", $"Rejected: {req.Title}",
            $"Rejected by {user.DisplayName}",
            [$"{Roles.Label(step.ApproverRole)} {user.DisplayName} rejected {req.Title} on {EmailTemplate.Ist(now)}.", $"Reason: {reason.Trim()}"],
            "/requisitions", "Requisition", req.RequisitionId);
        await db.SaveChangesAsync(ct);
    }

    async Task<JobRequisition> LoadPending(int id, CancellationToken ct)
    {
        var req = await db.Requisitions.Include(x => x.Approvals).FirstOrDefaultAsync(x => x.RequisitionId == id, ct)
                  ?? throw new NotFoundException("Requisition not found.");
        if (req.Status != ReqStatus.PendingApproval) throw new DomainException("This requisition is not waiting for approval.");
        return req;
    }

    static RequisitionApproval CurrentStep(JobRequisition req, Employee user)
    {
        var step = req.Approvals.OrderBy(a => a.StepNo).FirstOrDefault(a => a.Status == StepStatus.Pending)
                   ?? throw new DomainException("This requisition has no step waiting for approval.");
        if (step.ApproverEmployeeId != user.EmployeeId) throw new ForbiddenException("This step is assigned to someone else.");
        return step;
    }

    // ---------- Queries ----------

    /// <summary>Approved positions that every employee can see and refer candidates for.</summary>
    public async Task<List<PositionDto>> OpenPositionsAsync(string? department, string? q, CancellationToken ct)
    {
        await me.GetAsync(ct);
        var today = Clock.Today;
        var query = db.Requisitions.AsNoTracking()
            .Where(j => j.Status == ReqStatus.Open && j.HireByDate >= today && j.PositionsFilled < j.NoOfPositions);
        if (!string.IsNullOrWhiteSpace(department)) query = query.Where(j => j.Department!.Name == department);
        if (!string.IsNullOrWhiteSpace(q))
            query = query.Where(j => j.Title.Contains(q) || j.Skills.Any(s => s.Skill!.Name.Contains(q)));

        return await query.OrderBy(j => j.HireByDate)
            .Select(j => new PositionDto(
                j.RequisitionId, j.Title, j.Department!.Name, j.Location!.Name, j.EmploymentType,
                j.NoOfPositions - j.PositionsFilled, j.ExperienceRequired, j.HireByDate, j.Summary, j.Requirements,
                j.Skills.Select(s => s.Skill!.Name).ToList(),
                db.Referrals.Count(r => r.RequisitionId == j.RequisitionId)))
            .ToListAsync(ct);
    }

    public async Task<List<RequisitionDto>> MineAsync(CancellationToken ct)
    {
        var user = await me.GetAsync(ct);
        return await db.Requisitions.AsNoTracking()
            .Where(j => j.RequestedByEmployeeId == user.EmployeeId)
            .OrderByDescending(j => j.CreatedOn).Select(ToDto).ToListAsync(ct);
    }

    public async Task<List<RequisitionDto>> AllAsync(CancellationToken ct)
    {
        await me.RequireAsync(Roles.Hr, ct);
        return await db.Requisitions.AsNoTracking().OrderByDescending(j => j.CreatedOn).Select(ToDto).ToListAsync(ct);
    }

    /// <summary>Requisitions where it is currently my turn to approve.</summary>
    public async Task<List<RequisitionDto>> InboxAsync(CancellationToken ct)
    {
        var user = await me.GetAsync(ct);
        return await db.Requisitions.AsNoTracking()
            .Where(j => j.Status == ReqStatus.PendingApproval &&
                        j.Approvals.Any(a => a.ApproverEmployeeId == user.EmployeeId && a.Status == StepStatus.Pending))
            .OrderBy(j => j.CreatedOn).Select(ToDto).ToListAsync(ct);
    }

    /// <summary>Full history with date, time and person. Visible to the requester, the approvers on the chain, and HR.</summary>
    public async Task<List<HistoryItemDto>> HistoryAsync(int id, CancellationToken ct)
    {
        var user = await me.GetAsync(ct);
        var req = await db.Requisitions.AsNoTracking().Include(x => x.Approvals)
                      .FirstOrDefaultAsync(x => x.RequisitionId == id, ct)
                  ?? throw new NotFoundException("Requisition not found.");
        var allowed = req.RequestedByEmployeeId == user.EmployeeId
                      || req.Approvals.Any(a => a.ApproverEmployeeId == user.EmployeeId)
                      || await me.HasAsync(Roles.Hr, ct);
        if (!allowed) throw new ForbiddenException("You do not have access to this requisition.");

        return await db.RequisitionHistory.AsNoTracking()
            .Where(h => h.RequisitionId == id)
            .OrderBy(h => h.CreatedOn).ThenBy(h => h.HistoryId)
            .Select(h => new HistoryItemDto(h.CreatedOn, h.EventType, h.StepNo, h.Actor!.DisplayName, h.FromStatus, h.ToStatus, h.Comments))
            .ToListAsync(ct);
    }
}
