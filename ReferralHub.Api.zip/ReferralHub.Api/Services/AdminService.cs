using Microsoft.EntityFrameworkCore;
using ReferralHub.Api.Data;
using ReferralHub.Api.Domain;
using ReferralHub.Api.Dtos;
using ReferralHub.Api.Infrastructure;

namespace ReferralHub.Api.Services;

/// <summary>
/// Master data management: who exists in the system, what role(s) they hold, and the department,
/// division and location lists everything else points to. ADMIN role only.
/// This does not touch requisitions or referrals directly - changing a department's head, for example,
/// only affects approval routing for requisitions created after the change.
/// </summary>
public class AdminService(AppDbContext db, CurrentUser me)
{
    static readonly string[] ValidRoles = [Roles.Employee, Roles.Manager, Roles.DeptHead, Roles.DivHead,
        Roles.HrHead, Roles.Hr, Roles.Interviewer, Roles.Admin];

    // ---------- Employees and roles ----------

    public async Task<List<EmployeeAdminDto>> EmployeesAsync(string? q, CancellationToken ct)
    {
        await me.RequireAsync(Roles.Admin, ct);
        var query = db.Employees.AsNoTracking().Include(e => e.Roles).ThenInclude(r => r.Role).AsQueryable();
        if (!string.IsNullOrWhiteSpace(q)) query = query.Where(e => e.DisplayName.Contains(q) || e.Email.Contains(q));
        var list = await query.OrderBy(e => e.DisplayName).ToListAsync(ct);
        var deptNames = await db.Departments.ToDictionaryAsync(d => d.DepartmentId, d => d.Name, ct);
        var byId = list.ToDictionary(e => e.EmployeeId, e => e.DisplayName);
        return list.Select(e => new EmployeeAdminDto(
            e.EmployeeId, e.Email, e.DisplayName, e.JobTitle,
            e.DepartmentId.HasValue && deptNames.TryGetValue(e.DepartmentId.Value, out var dn) ? dn : null,
            e.ManagerEmployeeId.HasValue && byId.TryGetValue(e.ManagerEmployeeId.Value, out var mn) ? mn : null,
            e.IsActive, e.Roles.Select(r => r.Role!.Code).OrderBy(c => c).ToList(), e.CreatedOn)).ToList();
    }

    public async Task<int> CreateEmployeeAsync(UpsertEmployeeDto d, CancellationToken ct)
    {
        await me.RequireAsync(Roles.Admin, ct);
        var email = Text(d.Email, 256, "an email address");
        if (await db.Employees.AnyAsync(e => e.Email == email, ct)) throw new DomainException("An employee with this email already exists.");
        var name = Text(d.DisplayName, 150, "the employee's name");
        if (d.DepartmentId.HasValue && !await db.Departments.AnyAsync(x => x.DepartmentId == d.DepartmentId, ct))
            throw new DomainException("Choose a valid department.");
        if (d.ManagerEmployeeId.HasValue && !await db.Employees.AnyAsync(x => x.EmployeeId == d.ManagerEmployeeId, ct))
            throw new DomainException("Choose a valid manager.");

        var now = Clock.Now;
        var emp = new Employee
        {
            Email = email, DisplayName = name, JobTitle = Opt(d.JobTitle, 150), DepartmentId = d.DepartmentId,
            ManagerEmployeeId = d.ManagerEmployeeId, IsActive = d.IsActive ?? true, CreatedOn = now, UpdatedOn = now
        };
        AssignRoles(emp, d.Roles);
        db.Employees.Add(emp);
        await db.SaveChangesAsync(ct);
        return emp.EmployeeId;
    }

    public async Task UpdateEmployeeAsync(int id, UpsertEmployeeDto d, CancellationToken ct)
    {
        await me.RequireAsync(Roles.Admin, ct);
        var emp = await db.Employees.Include(e => e.Roles).FirstOrDefaultAsync(e => e.EmployeeId == id, ct)
                  ?? throw new NotFoundException("Employee not found.");
        var email = Text(d.Email, 256, "an email address");
        if (email != emp.Email && await db.Employees.AnyAsync(e => e.Email == email && e.EmployeeId != id, ct))
            throw new DomainException("An employee with this email already exists.");
        if (d.ManagerEmployeeId == id) throw new DomainException("An employee cannot be their own manager.");
        if (d.DepartmentId.HasValue && !await db.Departments.AnyAsync(x => x.DepartmentId == d.DepartmentId, ct))
            throw new DomainException("Choose a valid department.");

        emp.Email = email;
        emp.DisplayName = Text(d.DisplayName, 150, "the employee's name");
        emp.JobTitle = Opt(d.JobTitle, 150);
        emp.DepartmentId = d.DepartmentId;
        emp.ManagerEmployeeId = d.ManagerEmployeeId;
        if (d.IsActive.HasValue) emp.IsActive = d.IsActive.Value;
        emp.UpdatedOn = Clock.Now;
        if (d.Roles != null) AssignRoles(emp, d.Roles);
        await db.SaveChangesAsync(ct);
    }

    /// <summary>Replaces an employee's role set with exactly the roles given.</summary>
    public async Task SetRolesAsync(int id, List<string> roles, CancellationToken ct)
    {
        await me.RequireAsync(Roles.Admin, ct);
        var emp = await db.Employees.Include(e => e.Roles).FirstOrDefaultAsync(e => e.EmployeeId == id, ct)
                  ?? throw new NotFoundException("Employee not found.");
        AssignRoles(emp, roles);
        emp.UpdatedOn = Clock.Now;
        await db.SaveChangesAsync(ct);
    }

    void AssignRoles(Employee emp, List<string>? roles)
    {
        if (roles == null) return;
        var clean = roles.Select(r => r.Trim().ToUpperInvariant()).Distinct().ToList();
        var bad = clean.Except(ValidRoles).ToList();
        if (bad.Count > 0) throw new DomainException($"Unknown role: {string.Join(", ", bad)}.");
        if (clean.Count == 0) clean.Add(Roles.Employee);   // everyone keeps at least the base Employee role
        else if (!clean.Contains(Roles.Employee)) clean.Add(Roles.Employee);
        emp.Roles.Clear();
        emp.Roles.AddRange(clean.Select(c => new EmployeeRole { RoleId = RoleIdFor(c) }));
    }

    static byte RoleIdFor(string code) => code switch
    {
        Roles.Employee => 1, Roles.Manager => 2, Roles.DeptHead => 3, Roles.DivHead => 4,
        Roles.HrHead => 5, Roles.Hr => 6, Roles.Interviewer => 7, Roles.Admin => 8, _ => 1
    };

    // ---------- Departments, divisions, locations, skills ----------

    public async Task<List<DivisionAdminDto>> DivisionsAsync(CancellationToken ct)
    {
        await me.RequireAsync(Roles.Admin, ct);
        return await db.Divisions.AsNoTracking()
            .Select(d => new DivisionAdminDto(d.DivisionId, d.Name,
                db.Employees.Where(e => e.EmployeeId == d.DivisionHeadEmployeeId).Select(e => e.DisplayName).FirstOrDefault() ?? "",
                db.Departments.Count(x => x.DivisionId == d.DivisionId)))
            .ToListAsync(ct);
    }

    public async Task<int> CreateDivisionAsync(UpsertDivisionDto d, CancellationToken ct)
    {
        await me.RequireAsync(Roles.Admin, ct);
        await ValidateHead(d.DivisionHeadEmployeeId, ct);
        var div = new Division { Name = Text(d.Name, 120, "the division name"), DivisionHeadEmployeeId = d.DivisionHeadEmployeeId, UpdatedOn = Clock.Now };
        db.Divisions.Add(div);
        await db.SaveChangesAsync(ct);
        return div.DivisionId;
    }

    public async Task UpdateDivisionAsync(int id, UpsertDivisionDto d, CancellationToken ct)
    {
        await me.RequireAsync(Roles.Admin, ct);
        var div = await db.Divisions.FirstOrDefaultAsync(x => x.DivisionId == id, ct) ?? throw new NotFoundException("Division not found.");
        await ValidateHead(d.DivisionHeadEmployeeId, ct);
        div.Name = Text(d.Name, 120, "the division name");
        div.DivisionHeadEmployeeId = d.DivisionHeadEmployeeId;
        div.UpdatedOn = Clock.Now;
        await db.SaveChangesAsync(ct);
    }

    public async Task<List<DepartmentAdminDto>> DepartmentsAsync(CancellationToken ct)
    {
        await me.RequireAsync(Roles.Admin, ct);
        return await db.Departments.AsNoTracking().Include(x => x.Division)
            .Select(x => new DepartmentAdminDto(x.DepartmentId, x.Name, x.Division!.Name,
                db.Employees.Where(e => e.EmployeeId == x.DepartmentHeadEmployeeId).Select(e => e.DisplayName).FirstOrDefault() ?? "",
                x.DefaultBonusAmount))
            .ToListAsync(ct);
    }

    public async Task<int> CreateDepartmentAsync(UpsertDepartmentDto d, CancellationToken ct)
    {
        await me.RequireAsync(Roles.Admin, ct);
        if (!await db.Divisions.AnyAsync(x => x.DivisionId == d.DivisionId, ct)) throw new DomainException("Choose a valid division.");
        await ValidateHead(d.DepartmentHeadEmployeeId, ct);
        var dept = new Department
        {
            Name = Text(d.Name, 120, "the department name"), DivisionId = d.DivisionId,
            DepartmentHeadEmployeeId = d.DepartmentHeadEmployeeId, DefaultBonusAmount = d.DefaultBonusAmount, UpdatedOn = Clock.Now
        };
        db.Departments.Add(dept);
        await db.SaveChangesAsync(ct);
        return dept.DepartmentId;
    }

    public async Task UpdateDepartmentAsync(int id, UpsertDepartmentDto d, CancellationToken ct)
    {
        await me.RequireAsync(Roles.Admin, ct);
        var dept = await db.Departments.FirstOrDefaultAsync(x => x.DepartmentId == id, ct) ?? throw new NotFoundException("Department not found.");
        if (!await db.Divisions.AnyAsync(x => x.DivisionId == d.DivisionId, ct)) throw new DomainException("Choose a valid division.");
        await ValidateHead(d.DepartmentHeadEmployeeId, ct);
        dept.Name = Text(d.Name, 120, "the department name");
        dept.DivisionId = d.DivisionId;
        dept.DepartmentHeadEmployeeId = d.DepartmentHeadEmployeeId;
        dept.DefaultBonusAmount = d.DefaultBonusAmount;
        dept.UpdatedOn = Clock.Now;
        await db.SaveChangesAsync(ct);
    }

    public async Task<List<LookupItem>> LocationsAsync(CancellationToken ct)
    {
        await me.RequireAsync(Roles.Admin, ct);
        return await db.Locations.AsNoTracking().OrderBy(x => x.Name).Select(x => new LookupItem(x.LocationId, x.Name)).ToListAsync(ct);
    }

    public async Task<int> CreateLocationAsync(UpsertLocationDto d, CancellationToken ct)
    {
        await me.RequireAsync(Roles.Admin, ct);
        var name = Text(d.Name, 100, "the location name");
        if (await db.Locations.AnyAsync(x => x.Name == name, ct)) throw new DomainException("This location already exists.");
        var loc = new Location { Name = name };
        db.Locations.Add(loc);
        await db.SaveChangesAsync(ct);
        return loc.LocationId;
    }

    public async Task<List<LookupItem>> SkillsAsync(CancellationToken ct)
    {
        await me.RequireAsync(Roles.Admin, ct);
        return await db.Skills.AsNoTracking().OrderBy(x => x.Name).Select(x => new LookupItem(x.SkillId, x.Name)).ToListAsync(ct);
    }

    public async Task<int> CreateSkillAsync(UpsertSkillDto d, CancellationToken ct)
    {
        await me.RequireAsync(Roles.Admin, ct);
        var name = Text(d.Name, 80, "the skill name");
        var existing = await db.Skills.FirstOrDefaultAsync(x => x.Name.ToLower() == name.ToLower(), ct);
        if (existing != null) return existing.SkillId;
        var skill = new Skill { Name = name };
        db.Skills.Add(skill);
        await db.SaveChangesAsync(ct);
        return skill.SkillId;
    }

    async Task ValidateHead(int employeeId, CancellationToken ct)
    {
        if (!await db.Employees.AnyAsync(x => x.EmployeeId == employeeId && x.IsActive, ct))
            throw new DomainException("Choose a valid, active employee as the head.");
    }

    static string Text(string? s, int max, string what)
    {
        var v = s?.Trim();
        if (string.IsNullOrEmpty(v)) throw new DomainException($"Enter {what}.");
        if (v.Length > max) throw new DomainException($"{what} is too long (maximum {max} characters).");
        return v;
    }

    static string? Opt(string? s, int max)
    {
        var v = s?.Trim();
        if (string.IsNullOrEmpty(v)) return null;
        return v.Length > max ? v[..max] : v;
    }
}
