using System.Net.Mail;
using Microsoft.EntityFrameworkCore;
using ReferralHub.Api.Data;
using ReferralHub.Api.Domain;
using ReferralHub.Api.Dtos;
using ReferralHub.Api.Infrastructure;

namespace ReferralHub.Api.Services;

/// <summary>
/// Referral life cycle (stage ids in brackets):
///   Referred [1] -> HR review [2] -> Interview 1 [3] -> Interview 2 [4] -> Interview 3 [5] -> Final approval [6] -> Selected
/// Every interview needs feedback before the next round unlocks. A "Reject" recommendation or an HR close ends the referral.
/// Final approval needs BOTH the Division head and the HR head.
/// Every action: writes a timeline row (who, what, when), queues the emails, and updates Referral.UpdatedOn
/// so the rowversion check stops two people saving over each other.
/// </summary>
public class ReferralService(AppDbContext db, CurrentUser me, Notifier notify, CalendarInviteService invites)
{
    const long MaxResumeBytes = 5 * 1024 * 1024;
    static readonly string[] ResumeExtensions = [".pdf", ".doc", ".docx"];
    static readonly int[] Durations = [30, 45, 60, 90];

    // ---------- Employee: submit and track ----------

    public async Task<int> SubmitAsync(int requisitionId, SubmitReferralDto d, CancellationToken ct)
    {
        var user = await me.GetAsync(ct);
        var req = await db.Requisitions.FirstOrDefaultAsync(x => x.RequisitionId == requisitionId, ct)
                  ?? throw new NotFoundException("Position not found.");
        if (req.Status != ReqStatus.Open || req.HireByDate < Clock.Today || req.PositionsFilled >= req.NoOfPositions)
            throw new DomainException("This position is no longer open for referrals.");

        var name = Text(d.CandidateName, 150, "the candidate's name");
        var email = Text(d.CandidateEmail, 256, "the candidate's email");
        if (!MailAddress.TryCreate(email, out _)) throw new DomainException("Enter a valid email address for the candidate.");
        var phone = Text(d.CandidatePhone, 30, "the candidate's phone number");
        if (d.TotalExperienceYears < 0 || d.TotalExperienceYears > 60) throw new DomainException("Enter the candidate's experience in years.");

        var file = d.Resume ?? throw new DomainException("Attach the candidate's resume.");
        var ext = Path.GetExtension(file.FileName ?? "").ToLowerInvariant();
        if (!ResumeExtensions.Contains(ext)) throw new DomainException("The resume must be a PDF or Word file.");
        if (file.SizeBytes < 1 || file.SizeBytes > MaxResumeBytes) throw new DomainException("The resume must be 5 MB or smaller.");
        if (!Uri.TryCreate(file.StorageUrl, UriKind.Absolute, out var uri) || uri.Scheme != Uri.UriSchemeHttps)
            throw new DomainException("The resume link is not valid. Upload the file again.");

        if (await db.Referrals.AnyAsync(r => r.RequisitionId == requisitionId && r.CandidateEmail == email, ct))
            throw new DomainException("This candidate has already been referred for this position.");

        var now = Clock.Now;
        var referral = new Referral
        {
            RequisitionId = requisitionId, ReferredByEmployeeId = user.EmployeeId,
            CandidateName = name, CandidateEmail = email, CandidatePhone = phone,
            TotalExperienceYears = d.TotalExperienceYears, CurrentCompany = Opt(d.CurrentCompany, 150),
            NoticePeriod = Opt(d.NoticePeriod, 20), Relationship = Opt(d.Relationship, 60), ReferrerNote = Opt(d.ReferrerNote, 1000),
            CurrentStageId = Stages.Referred, Outcome = Outcomes.Active, ReferredOn = now, UpdatedOn = now
        };
        referral.Documents.Add(new ReferralDocument
        {
            FileName = Path.GetFileName(file.FileName!), ContentType = Opt(file.ContentType, 100) ?? "application/octet-stream",
            SizeBytes = file.SizeBytes, StorageUrl = file.StorageUrl, UploadedOn = now
        });
        Log(referral, "Submitted", user, null, visible: true, toStage: Stages.Referred);
        db.Referrals.Add(referral);

        await using var tx = await db.Database.BeginTransactionAsync(ct);
        await db.SaveChangesAsync(ct);   // gets ReferralId

        await notify.ToRolesAsync([Roles.Hr], null, "ReferralSubmitted", $"New referral: {name}", "A new candidate was referred",
            [$"{user.DisplayName} referred {name} ({d.TotalExperienceYears} years) for {req.Title}.", "Next step: contact the candidate."],
            $"/referrals/{referral.ReferralId}", "Referral", referral.ReferralId, ct);
        notify.To(user.EmployeeId, "ReferralReceived", $"Referral received: {name}", "Thanks for your referral",
            [$"We received your referral of {name} for {req.Title}. HR will contact the candidate.", "You will get an email at every step."],
            $"/my-referrals/{referral.ReferralId}", "Referral", referral.ReferralId);
        await db.SaveChangesAsync(ct);
        await tx.CommitAsync(ct);
        return referral.ReferralId;
    }

    public async Task<List<MyReferralDto>> MineAsync(CancellationToken ct)
    {
        var user = await me.GetAsync(ct);
        return await db.Referrals.AsNoTracking()
            .Where(r => r.ReferredByEmployeeId == user.EmployeeId)
            .OrderByDescending(r => r.ReferredOn)
            .Select(r => new MyReferralDto(r.ReferralId, r.CandidateName, r.Requisition!.Title, r.ReferredOn, r.CurrentStageId, r.Outcome))
            .ToListAsync(ct);
    }

    /// <summary>
    /// Status page for the referring employee: stage progress and milestones with date and time.
    /// It never includes interview feedback, ratings, interviewer notes or rejection reasons.
    /// </summary>
    public async Task<MyReferralStatusDto> MyStatusAsync(int id, CancellationToken ct)
    {
        var user = await me.GetAsync(ct);
        var r = await db.Referrals.AsNoTracking().Include(x => x.Requisition)
                    .Include(x => x.Activities.Where(a => a.VisibleToReferrer))
                    .FirstOrDefaultAsync(x => x.ReferralId == id && x.ReferredByEmployeeId == user.EmployeeId, ct)
                ?? throw new NotFoundException("Referral not found.");

        var steps = Enumerable.Range(1, 6).Select(i =>
        {
            var state = r.Outcome == Outcomes.Selected ? "done"
                : i < r.CurrentStageId ? "done"
                : i == r.CurrentStageId ? (r.Outcome == Outcomes.Active ? "current" : "closed")
                : "todo";
            return new StatusStepDto(Stages.Name((byte)i), state);
        }).ToList();

        // Only these types carry a safe detail line (for example the interview date). All other notes stay private.
        static bool SafeDetail(string t) => t is "InterviewScheduled" or "InterviewRescheduled" or "InterviewCompleted";
        var events = r.Activities.OrderBy(a => a.CreatedOn)
            .Select(a => new StatusEventDto(a.CreatedOn, EventLabel(a.ActivityType), SafeDetail(a.ActivityType) ? a.Notes : null)).ToList();

        return new MyReferralStatusDto(r.ReferralId, r.CandidateName, r.Requisition!.Title, r.ReferredOn, r.CurrentStageId,
            Stages.Name(r.CurrentStageId), r.Outcome, NextStepText(r), steps, events);
    }

    static string EventLabel(string type) => type switch
    {
        "Submitted" => "Referral submitted",
        "Contacted" => "HR contacted the candidate",
        "Shortlisted" => "Shortlisted for interviews",
        "InterviewScheduled" => "Interview scheduled",
        "InterviewRescheduled" => "Interview rescheduled",
        "InterviewCompleted" => "Interview completed",
        "SentForFinalApproval" => "Sent for final approval",
        "Selected" => "Selected",
        "Closed" => "Referral closed",
        _ => type
    };

    static string NextStepText(Referral r) =>
        r.Outcome == Outcomes.Selected ? "Selected. HR will share the next steps."
        : r.Outcome != Outcomes.Active ? "This referral is closed."
        : r.CurrentStageId switch
        {
            Stages.Referred => "HR will contact the candidate.",
            Stages.HrReview => "HR is reviewing the profile.",
            Stages.FinalApproval => "Waiting for the final approval.",
            _ => $"{Stages.Name(r.CurrentStageId)} is being arranged or is in progress."
        };

    // ---------- HR: pipeline and stage moves ----------

    public async Task<List<PipelineRowDto>> PipelineAsync(byte? stage, string? outcome, CancellationToken ct)
    {
        await me.RequireAsync(Roles.Hr, ct);
        var q = db.Referrals.AsNoTracking().AsQueryable();
        if (stage.HasValue) q = q.Where(r => r.CurrentStageId == stage.Value);
        if (!string.IsNullOrWhiteSpace(outcome)) q = q.Where(r => r.Outcome == outcome);
        return await ProjectRows(q).ToListAsync(ct);
    }

    /// <summary>Candidates waiting for a final decision from me (Division head and/or HR head).</summary>
    public async Task<List<PipelineRowDto>> HiringInboxAsync(CancellationToken ct)
    {
        var roles = (await me.RolesAsync(ct)).Where(r => r is Roles.DivHead or Roles.HrHead).ToList();
        if (roles.Count == 0) throw new ForbiddenException("Only the division head or HR head can see final approvals.");
        var q = db.Referrals.AsNoTracking()
            .Where(r => r.Outcome == Outcomes.Active && r.CurrentStageId == Stages.FinalApproval
                        && r.FinalApprovals.Any(f => f.Decision == Decisions.Pending && roles.Contains(f.ApproverRole)));
        return await ProjectRows(q).ToListAsync(ct);
    }

    static IQueryable<PipelineRowDto> ProjectRows(IQueryable<Referral> q) => q
        .OrderByDescending(r => r.UpdatedOn)
        .Select(r => new PipelineRowDto(
            r.ReferralId, r.CandidateName, r.Requisition!.Title, r.ReferredBy!.DisplayName, r.ReferredOn,
            r.CurrentStageId, r.Outcome,
            r.Interviews.SelectMany(i => i.Feedback).Select(f => (double?)f.Rating).Average(),
            r.Interviews.Where(i => i.Status == InterviewStatuses.Scheduled).Select(i => (DateTime?)i.ScheduledAt).Min()));

    /// <summary>HR marks the first call as done: Referred -> HR review.</summary>
    public async Task ContactAsync(int id, CancellationToken ct)
    {
        await me.RequireAsync(Roles.Hr, ct);
        var user = await me.GetAsync(ct);
        var r = await LoadActive(id, ct);
        if (r.CurrentStageId != Stages.Referred) throw new DomainException("This candidate has already been contacted.");
        r.CurrentStageId = Stages.HrReview;
        r.AssignedHrEmployeeId = user.EmployeeId;
        Log(r, "Contacted", user, null, visible: true, fromStage: Stages.Referred, toStage: Stages.HrReview);
        notify.To(r.ReferredByEmployeeId, "ReferralContacted", $"HR contacted {r.CandidateName}", "Your referral is moving",
            [$"HR contacted {r.CandidateName} for {r.Requisition!.Title} on {EmailTemplate.Ist(r.UpdatedOn)}."],
            $"/my-referrals/{r.ReferralId}", "Referral", r.ReferralId);
        await db.SaveChangesAsync(ct);
    }

    /// <summary>HR review -> Interview 1 (ready to schedule).</summary>
    public async Task ShortlistAsync(int id, CancellationToken ct)
    {
        await me.RequireAsync(Roles.Hr, ct);
        var user = await me.GetAsync(ct);
        var r = await LoadActive(id, ct);
        if (r.CurrentStageId != Stages.HrReview) throw new DomainException("Mark the candidate as contacted before shortlisting.");
        r.CurrentStageId = Stages.Interview1;
        Log(r, "Shortlisted", user, null, visible: true, fromStage: Stages.HrReview, toStage: Stages.Interview1);
        notify.To(r.ReferredByEmployeeId, "ReferralShortlisted", $"{r.CandidateName} is shortlisted", "Good news",
            [$"{r.CandidateName} was shortlisted for {r.Requisition!.Title}. Interviews come next."],
            $"/my-referrals/{r.ReferralId}", "Referral", r.ReferralId);
        await db.SaveChangesAsync(ct);
    }

    /// <summary>HR closes the referral at any active stage.</summary>
    public async Task CloseAsync(int id, string reason, CancellationToken ct)
    {
        await me.RequireAsync(Roles.Hr, ct);
        if (string.IsNullOrWhiteSpace(reason)) throw new DomainException("Add a reason for closing this referral.");
        var user = await me.GetAsync(ct);
        var r = await LoadActive(id, ct);
        var fromStageId = r.CurrentStageId;
        r.Outcome = Outcomes.Rejected;
        r.ClosedReason = reason.Trim();
        Log(r, "Closed", user, reason.Trim(), visible: true, fromStage: fromStageId);
        await NotifyClosedAsync(r, user, ct);
        await db.SaveChangesAsync(ct);
    }

    // ---------- Interviews ----------

    /// <summary>Employees with the INTERVIEWER role for the dropdown. No InterviewerRound rows = any round.</summary>
    IQueryable<Employee> InterviewersFor(int round) =>
        db.Employees.Where(e => e.IsActive
            && e.Roles.Any(r => r.Role!.Code == Roles.Interviewer)
            && (!db.InterviewerRounds.Any(x => x.EmployeeId == e.EmployeeId)
                || db.InterviewerRounds.Any(x => x.EmployeeId == e.EmployeeId && x.RoundNo == round)));

    public async Task<List<InterviewerDto>> InterviewersAsync(int round, CancellationToken ct)
    {
        await me.RequireAsync(Roles.Hr, ct);
        if (round is < 1 or > 3) throw new DomainException("Interview round must be 1, 2 or 3.");
        return await InterviewersFor(round).AsNoTracking().OrderBy(e => e.DisplayName)
            .Select(e => new InterviewerDto(e.EmployeeId, e.DisplayName, e.JobTitle)).ToListAsync(ct);
    }

    /// <summary>Interviewer's own list: upcoming and past interviews assigned to me.</summary>
    public async Task<List<MyInterviewDto>> MyInterviewsAsync(CancellationToken ct)
    {
        var user = await me.GetAsync(ct);
        return await db.Interviews.AsNoTracking()
            .Where(i => i.InterviewerEmployeeId == user.EmployeeId && i.Status != InterviewStatuses.Cancelled)
            .OrderBy(i => i.ScheduledAt)
            .Select(i => new MyInterviewDto(i.InterviewId, i.ReferralId, i.Referral!.CandidateName, i.Referral.Requisition!.Title,
                i.RoundNo, i.ScheduledAt, i.DurationMinutes, i.MeetingLink, i.Status,
                i.Referral.Documents.OrderByDescending(d => d.UploadedOn).Select(d => d.StorageUrl).FirstOrDefault()))
            .ToListAsync(ct);
    }

    /// <summary>
    /// Schedule (or reschedule) round 1, 2 or 3 with an interviewer chosen from the dropdown.
    /// Round N unlocks after round N-1 has feedback. A Teams meeting invite goes to the interviewer, the candidate and HR.
    /// </summary>
    public async Task<ScheduleResultDto> ScheduleAsync(int id, int round, ScheduleDto d, CancellationToken ct)
    {
        await me.RequireAsync(Roles.Hr, ct);
        var user = await me.GetAsync(ct);
        if (round is < 1 or > 3) throw new DomainException("Interview round must be 1, 2 or 3.");
        var r = await LoadActive(id, ct, withInterviews: true);
        if (r.CurrentStageId != Stages.ForRound(round)) throw new DomainException($"Interview {round} cannot be scheduled yet.");

        var at = d.ScheduledAt.Kind == DateTimeKind.Unspecified ? DateTime.SpecifyKind(d.ScheduledAt, DateTimeKind.Utc) : d.ScheduledAt.ToUniversalTime();
        if (at <= Clock.Now) throw new DomainException("Pick a date and time in the future.");
        var minutes = d.DurationMinutes ?? 60;
        if (!Durations.Contains(minutes)) throw new DomainException("Duration must be 30, 45, 60 or 90 minutes.");

        var interviewer = await InterviewersFor(round).FirstOrDefaultAsync(e => e.EmployeeId == d.InterviewerEmployeeId, ct)
                          ?? throw new DomainException($"Choose an interviewer from the list for Interview {round}.");
        if (interviewer.EmployeeId == r.ReferredByEmployeeId)
            throw new DomainException("The person who referred the candidate cannot be the interviewer.");

        var iv = r.Interviews.FirstOrDefault(x => x.RoundNo == round);
        var isReschedule = iv != null;
        if (iv == null)
        {
            iv = new Interview { RoundNo = (byte)round, ScheduledByEmployeeId = user.EmployeeId, CreatedOn = Clock.Now };
            r.Interviews.Add(iv);
        }
        else if (iv.Status == InterviewStatuses.Completed) throw new DomainException("This interview is already completed.");

        iv.InterviewerEmployeeId = interviewer.EmployeeId;
        iv.ScheduledAt = at;
        iv.DurationMinutes = (short)minutes;
        iv.Mode = "Online";
        iv.Status = InterviewStatuses.Scheduled;
        iv.ReminderSentOn = null;

        var whenText = EmailTemplate.Ist(at);
        var kind = isReschedule ? "InterviewRescheduled" : "InterviewScheduled";
        Log(r, kind, user, $"Interview {round}: {whenText}", visible: true, round: (byte)round);

        var verb = isReschedule ? "rescheduled" : "scheduled";
        notify.To(interviewer.EmployeeId, "Interview" + (isReschedule ? "Rescheduled" : "Scheduled"), $"Interview {round} {verb}: {r.CandidateName}",
            $"You have an interview to conduct",
            [$"Candidate: {r.CandidateName}", $"Position: {r.Requisition!.Title}", $"When: {whenText} ({minutes} minutes)",
             "A calendar invite with the Teams link is sent separately. Please submit feedback right after the interview."],
            $"/interviews", "Referral", r.ReferralId);
        notify.To(r.ReferredByEmployeeId, "Interview" + (isReschedule ? "Rescheduled" : "Scheduled"), $"Interview {round} {verb} for {r.CandidateName}",
            "Your referral has an interview",
            [$"Interview {round} for {r.CandidateName} is {verb} on {whenText}."],
            $"/my-referrals/{r.ReferralId}", "Referral", r.ReferralId);
        if (r.AssignedHrEmployeeId.HasValue && r.AssignedHrEmployeeId != user.EmployeeId)
            notify.To(r.AssignedHrEmployeeId.Value, "Interview" + (isReschedule ? "Rescheduled" : "Scheduled"), $"Interview {round} {verb}: {r.CandidateName}",
                $"{user.DisplayName} {verb} an interview", [$"Interviewer: {interviewer.DisplayName}", $"When: {whenText}"],
                $"/referrals/{r.ReferralId}", "Referral", r.ReferralId);
        await db.SaveChangesAsync(ct);

        // Calendar invite after the data is saved, so a Graph problem never loses the schedule
        string? warning = null;
        if (d.SendInvite ?? true)
        {
            var res = await invites.UpsertAsync(iv, r, interviewer, user, ct);
            ApplyInvite(iv, res);
            await db.SaveChangesAsync(ct);
            if (res.Status != InviteStatuses.Sent) warning = "The interview is saved but the meeting invite was not sent. Use resend invite.";
        }
        return new ScheduleResultDto(iv.InterviewId, iv.InviteStatus, iv.MeetingLink, warning);
    }

    /// <summary>HR resends (or fixes) the calendar invite for an interview.</summary>
    public async Task<ScheduleResultDto> ResendInviteAsync(int interviewId, CancellationToken ct)
    {
        await me.RequireAsync(Roles.Hr, ct);
        var user = await me.GetAsync(ct);
        var iv = await db.Interviews.Include(x => x.Interviewer)
                     .Include(x => x.Referral).ThenInclude(r => r!.Requisition)
                     .FirstOrDefaultAsync(x => x.InterviewId == interviewId, ct)
                 ?? throw new NotFoundException("Interview not found.");
        if (iv.Status != InterviewStatuses.Scheduled) throw new DomainException("Only a scheduled interview can get an invite.");
        var res = await invites.UpsertAsync(iv, iv.Referral!, iv.Interviewer!, user, ct);
        ApplyInvite(iv, res);
        await db.SaveChangesAsync(ct);
        return new ScheduleResultDto(iv.InterviewId, iv.InviteStatus, iv.MeetingLink, res.Error);
    }

    static void ApplyInvite(Interview iv, InviteResult res)
    {
        iv.InviteStatus = res.Status;
        iv.InviteError = res.Error is { Length: > 500 } e ? e[..500] : res.Error;
        iv.CalendarEventId = res.EventId ?? iv.CalendarEventId;
        iv.MeetingLink = res.JoinUrl ?? iv.MeetingLink;
        if (res.Status == InviteStatuses.Sent) iv.InviteSentOn = Clock.Now;
    }

    /// <summary>
    /// Feedback closes the round. Proceed unlocks the next round (or final approval after round 3).
    /// Reject ends the referral. Allowed for the assigned interviewer or HR.
    /// </summary>
    public async Task SubmitFeedbackAsync(int interviewId, FeedbackDto d, CancellationToken ct)
    {
        var user = await me.GetAsync(ct);
        var iv = await db.Interviews.Include(x => x.Feedback)
                     .Include(x => x.Referral).ThenInclude(r => r!.Requisition)
                     .FirstOrDefaultAsync(x => x.InterviewId == interviewId, ct)
                 ?? throw new NotFoundException("Interview not found.");
        var r = iv.Referral!;

        var isHr = await me.HasAsync(Roles.Hr, ct);
        if (iv.InterviewerEmployeeId != user.EmployeeId && !isHr)
            throw new ForbiddenException("Only the assigned interviewer or HR can submit feedback.");
        if (r.Outcome != Outcomes.Active) throw new DomainException("This referral is already closed.");
        if (iv.Status != InterviewStatuses.Scheduled) throw new DomainException("Feedback was already submitted for this interview.");
        if (r.CurrentStageId != Stages.ForRound(iv.RoundNo)) throw new DomainException("This round is not the current interview.");

        if (d.Rating < 1 || d.Rating > 5) throw new DomainException("Rating must be between 1 and 5.");
        if (d.Recommendation is not ("Proceed" or "Reject")) throw new DomainException("Choose Proceed or Reject.");
        var comments = Text(d.Comments, 2000, "your feedback");

        iv.Feedback.Add(new InterviewFeedback
        {
            SubmittedByEmployeeId = user.EmployeeId, Rating = d.Rating, Recommendation = d.Recommendation,
            Comments = comments, SubmittedOn = Clock.Now
        });
        iv.Status = InterviewStatuses.Completed;

        var round = iv.RoundNo;
        var fromStage = r.CurrentStageId;
        var title = r.Requisition!.Title;

        // Two timeline rows: a neutral one the referrer can see, and the private one with the result
        Log(r, "InterviewCompleted", user, $"Interview {round} completed", visible: true, round: round);
        Log(r, "FeedbackSubmitted", user, $"Interview {round}: {d.Recommendation} ({d.Rating}/5)", visible: false, round: round);

        notify.To(r.ReferredByEmployeeId, "InterviewCompleted", $"Interview {round} completed: {r.CandidateName}", "Your referral had an interview",
            [$"Interview {round} for {r.CandidateName} ({title}) is complete. HR will share the next step."],
            $"/my-referrals/{r.ReferralId}", "Referral", r.ReferralId);

        if (d.Recommendation == "Reject")
        {
            r.Outcome = Outcomes.Rejected;
            r.ClosedReason = $"Not moving forward after interview {round}";
            Log(r, "Closed", user, r.ClosedReason, visible: true, fromStage: fromStage, round: round);
            await NotifyHrAsync(r, user, "FeedbackSubmitted", $"Feedback: {r.CandidateName} (Interview {round})", $"{user.DisplayName} recommends rejecting",
                [$"Interview {round}: Reject, rating {d.Rating}/5.", "The referral is closed."], ct);
            notify.To(r.ReferredByEmployeeId, "ReferralClosed", $"Update on {r.CandidateName}", "Your referral is closed",
                [$"The referral of {r.CandidateName} for {title} is closed. Thank you for referring."], $"/my-referrals/{r.ReferralId}", "Referral", r.ReferralId);
        }
        else if (round < 3)
        {
            r.CurrentStageId = Stages.ForRound(round + 1);    // next round is now ready to schedule
            await NotifyHrAsync(r, user, "FeedbackSubmitted", $"Feedback: {r.CandidateName} (Interview {round})", $"{user.DisplayName} recommends proceeding",
                [$"Interview {round}: Proceed, rating {d.Rating}/5.", $"Next: schedule Interview {round + 1}."], ct);
        }
        else
        {
            // All three rounds done: open the final approval for Division head and HR head
            r.CurrentStageId = Stages.FinalApproval;
            r.FinalApprovals.Add(new FinalApproval { ApproverRole = Roles.DivHead });
            r.FinalApprovals.Add(new FinalApproval { ApproverRole = Roles.HrHead });
            Log(r, "SentForFinalApproval", user, null, visible: true, fromStage: fromStage, toStage: Stages.FinalApproval);
            await notify.ToRolesAsync([Roles.DivHead, Roles.HrHead, Roles.Hr], user.EmployeeId, "FinalApprovalNeeded",
                $"Final approval: {r.CandidateName}", "A candidate needs your final decision",
                [$"{r.CandidateName} completed all three interviews for {title}.", "The division head and the HR head both need to approve."],
                $"/approvals", "Referral", r.ReferralId, ct);
        }
        await db.SaveChangesAsync(ct);
    }

    // ---------- Final approval ----------

    /// <summary>
    /// The division head and the HR head each record a decision. One rejection closes the referral.
    /// When both approve, the candidate is Selected and the requisition's filled count goes up.
    /// If one person holds both roles, both rows are recorded with one click.
    /// </summary>
    public async Task FinalDecisionAsync(int id, bool approve, string? comments, CancellationToken ct)
    {
        var user = await me.GetAsync(ct);
        var myRoles = (await me.RolesAsync(ct)).Where(x => x is Roles.DivHead or Roles.HrHead).ToList();
        if (myRoles.Count == 0) throw new ForbiddenException("Only the division head or HR head can give final approval.");

        var r = await db.Referrals.Include(x => x.FinalApprovals).Include(x => x.Requisition)
                    .FirstOrDefaultAsync(x => x.ReferralId == id, ct)
                ?? throw new NotFoundException("Referral not found.");
        if (r.Outcome != Outcomes.Active || r.CurrentStageId != Stages.FinalApproval)
            throw new DomainException("This candidate is not waiting for final approval.");

        var mine = r.FinalApprovals.Where(f => f.Decision == Decisions.Pending && myRoles.Contains(f.ApproverRole)).ToList();
        if (mine.Count == 0) throw new DomainException("You have already recorded your decision.");
        if (!approve && string.IsNullOrWhiteSpace(comments)) throw new DomainException("Add a reason when you reject.");

        var now = Clock.Now;
        var roleText = string.Join(" and ", mine.Select(f => Roles.Label(f.ApproverRole).ToLowerInvariant()));
        foreach (var f in mine)
        {
            f.Decision = approve ? Decisions.Approved : Decisions.Rejected;
            f.DecidedByEmployeeId = user.EmployeeId;
            f.DecidedOn = now;
            f.Comments = comments?.Trim();
        }
        var title = r.Requisition!.Title;

        if (!approve)
        {
            r.Outcome = Outcomes.Rejected;
            r.ClosedReason = $"Not approved at final stage: {comments!.Trim()}";
            Log(r, "FinalRejected", user, $"Rejected as {roleText}: {comments.Trim()}", visible: false, fromStage: Stages.FinalApproval);
            Log(r, "Closed", user, null, visible: true, fromStage: Stages.FinalApproval);
            await NotifyClosedAsync(r, user, ct, $"{user.DisplayName} ({roleText}) rejected: {comments.Trim()}");
        }
        else if (r.FinalApprovals.All(f => f.Decision == Decisions.Approved))
        {
            r.Outcome = Outcomes.Selected;
            var req = r.Requisition!;
            req.PositionsFilled++;
            if (req.PositionsFilled >= req.NoOfPositions) req.Status = ReqStatus.Filled;
            req.UpdatedOn = now;
            Log(r, "FinalApproved", user, $"Approved as {roleText}", visible: false, fromStage: Stages.FinalApproval);
            Log(r, "Selected", user, null, visible: true, fromStage: Stages.FinalApproval);
            notify.To(r.ReferredByEmployeeId, "CandidateSelected", $"{r.CandidateName} is selected", "Your referral is selected",
                [$"{r.CandidateName} was approved for {title}. Thank you for the referral."], $"/my-referrals/{r.ReferralId}", "Referral", r.ReferralId);
            await notify.ToRolesAsync([Roles.Hr], user.EmployeeId, "CandidateSelected", $"Selected: {r.CandidateName}", "Both final approvals are in",
                [$"{r.CandidateName} is approved for {title}. Proceed with the offer."], $"/referrals/{r.ReferralId}", "Referral", r.ReferralId, ct);
            notify.To(req.RequestedByEmployeeId, "CandidateSelected", $"Selected for {title}: {r.CandidateName}", "A candidate is selected for your position",
                [$"{r.CandidateName} is approved for {title}."], $"/requisitions", "Referral", r.ReferralId);
        }
        else
        {
            Log(r, "FinalApproved", user, $"Approved as {roleText}", visible: false, fromStage: Stages.FinalApproval);
            await NotifyHrAsync(r, user, "FinalApproved", $"Final approval: {r.CandidateName}", $"{user.DisplayName} approved",
                [$"Approved by {roleText} on {EmailTemplate.Ist(now)}. Waiting for the other head."], ct);
        }
        await db.SaveChangesAsync(ct);
    }

    // ---------- Joining (unlocks the bonus request) ----------

    /// <summary>HR records the candidate's joining date once they have actually joined. Selected candidates only.</summary>
    public async Task MarkJoinedAsync(int id, MarkJoinedDto d, CancellationToken ct)
    {
        await me.RequireAsync(Roles.Hr, ct);
        var user = await me.GetAsync(ct);
        var r = await db.Referrals.Include(x => x.Requisition).FirstOrDefaultAsync(x => x.ReferralId == id, ct)
                ?? throw new NotFoundException("Referral not found.");
        if (r.Outcome != Outcomes.Selected) throw new DomainException("Only a selected candidate can be marked as joined.");
        if (d.JoinedOn > DateOnly.FromDateTime(Clock.Now.AddDays(1))) throw new DomainException("The joining date cannot be in the future.");

        r.JoinedOn = d.JoinedOn;
        r.JoinedConfirmedByEmployeeId = user.EmployeeId;
        Log(r, "Joined", user, d.JoinedOn.ToString("dd MMM yyyy"), visible: true);
        notify.To(r.ReferredByEmployeeId, "CandidateJoined", $"{r.CandidateName} has joined", "Your referral joined",
            [$"{r.CandidateName} joined for {r.Requisition!.Title} on {d.JoinedOn:dd MMM yyyy}.",
             "You can now submit your referral bonus request."], $"/my-referrals/{r.ReferralId}", "Referral", r.ReferralId);
        await db.SaveChangesAsync(ct);
    }

    // ---------- Detail ----------

    /// <summary>Full detail with interview feedback: HR, Division head, HR head, or an interviewer on this referral.</summary>
    public async Task<ReferralDetailDto> GetAsync(int id, CancellationToken ct)
    {
        var user = await me.GetAsync(ct);
        var r = await db.Referrals.AsNoTracking().AsSplitQuery()
                    .Include(x => x.Requisition).Include(x => x.ReferredBy).Include(x => x.Documents)
                    .Include(x => x.Interviews).ThenInclude(i => i.Interviewer)
                    .Include(x => x.Interviews).ThenInclude(i => i.Feedback).ThenInclude(f => f.SubmittedBy)
                    .Include(x => x.FinalApprovals).ThenInclude(f => f.DecidedBy)
                    .Include(x => x.Activities).ThenInclude(a => a.Actor)
                    .FirstOrDefaultAsync(x => x.ReferralId == id, ct)
                ?? throw new NotFoundException("Referral not found.");

        var roles = await me.RolesAsync(ct);
        var allowed = roles.Any(x => x is Roles.Hr or Roles.DivHead or Roles.HrHead)
                      || r.Interviews.Any(i => i.InterviewerEmployeeId == user.EmployeeId);
        if (!allowed) throw new ForbiddenException("You do not have access to this candidate.");

        var doc = r.Documents.OrderByDescending(x => x.UploadedOn).FirstOrDefault();
        return new ReferralDetailDto(
            r.ReferralId, r.CandidateName, r.CandidateEmail, r.CandidatePhone, r.TotalExperienceYears, r.CurrentCompany,
            r.NoticePeriod, r.Relationship, r.ReferrerNote, r.RequisitionId, r.Requisition!.Title,
            r.ReferredBy!.DisplayName, r.ReferredOn, r.CurrentStageId, Stages.Name(r.CurrentStageId), r.Outcome, r.ClosedReason,
            r.JoinedOn, doc == null ? null : new ResumeInfo(doc.FileName, doc.StorageUrl),
            r.Interviews.OrderBy(i => i.RoundNo).Select(i =>
            {
                var f = i.Feedback.FirstOrDefault();
                return new InterviewView(i.InterviewId, i.RoundNo, i.InterviewerEmployeeId, i.Interviewer!.DisplayName,
                    i.ScheduledAt, i.DurationMinutes, i.Mode, i.MeetingLink, i.Status, i.InviteStatus, i.InviteSentOn,
                    f == null ? null : new FeedbackView(f.Rating, f.Recommendation, f.Comments, f.SubmittedBy!.DisplayName, f.SubmittedOn));
            }).ToList(),
            r.FinalApprovals.OrderBy(f => f.ApproverRole).Select(f => new FinalView(f.ApproverRole, f.Decision, f.DecidedBy?.DisplayName, f.DecidedOn, f.Comments)).ToList(),
            r.Activities.OrderBy(a => a.CreatedOn).ThenBy(a => a.ActivityId)
                .Select(a => new TimelineItem(a.ActivityType, a.Actor!.DisplayName, a.Notes, a.CreatedOn, a.FromStageId, a.ToStageId, a.RoundNo)).ToList());
    }

    // ---------- Helpers ----------

    async Task<Referral> LoadActive(int id, CancellationToken ct, bool withInterviews = false)
    {
        IQueryable<Referral> q = db.Referrals.Include(x => x.Requisition);
        if (withInterviews) q = q.Include(x => x.Interviews);
        var r = await q.FirstOrDefaultAsync(x => x.ReferralId == id, ct) ?? throw new NotFoundException("Referral not found.");
        if (r.Outcome != Outcomes.Active) throw new DomainException("This referral is already closed.");
        return r;
    }

    /// <summary>Adds a timeline row and bumps UpdatedOn (which also bumps the rowversion).</summary>
    static void Log(Referral r, string type, Employee actor, string? notes, bool visible,
                    byte? fromStage = null, byte? toStage = null, byte? round = null)
    {
        r.UpdatedOn = Clock.Now;
        r.Activities.Add(new ReferralActivity
        {
            ActivityType = type, ActorEmployeeId = actor.EmployeeId, Notes = notes, VisibleToReferrer = visible,
            FromStageId = fromStage, ToStageId = toStage, RoundNo = round, CreatedOn = r.UpdatedOn
        });
    }

    /// <summary>Tells the assigned HR person, or every HR user when nobody is assigned yet. Never the person who acted.</summary>
    async Task NotifyHrAsync(Referral r, Employee actor, string category, string subject, string headline, string[] lines, CancellationToken ct)
    {
        if (r.AssignedHrEmployeeId.HasValue)
        {
            if (r.AssignedHrEmployeeId != actor.EmployeeId)
                notify.To(r.AssignedHrEmployeeId.Value, category, subject, headline, lines, $"/referrals/{r.ReferralId}", "Referral", r.ReferralId);
        }
        else
            await notify.ToRolesAsync([Roles.Hr], actor.EmployeeId, category, subject, headline, lines, $"/referrals/{r.ReferralId}", "Referral", r.ReferralId, ct);
    }

    async Task NotifyClosedAsync(Referral r, Employee actor, CancellationToken ct, string? hrDetail = null)
    {
        var title = r.Requisition!.Title;
        notify.To(r.ReferredByEmployeeId, "ReferralClosed", $"Update on {r.CandidateName}", "Your referral is closed",
            [$"The referral of {r.CandidateName} for {title} is closed. Thank you for referring."], $"/my-referrals/{r.ReferralId}", "Referral", r.ReferralId);
        await NotifyHrAsync(r, actor, "ReferralClosed", $"Closed: {r.CandidateName}", "A referral was closed",
            [hrDetail ?? $"{actor.DisplayName} closed the referral of {r.CandidateName} for {title}."], ct);
    }

    static string Text(string? s, int max, string what)
    {
        var v = s?.Trim();
        if (string.IsNullOrEmpty(v)) throw new DomainException($"Enter {what}.");
        if (v.Length > max) throw new DomainException($"{what} is too long (maximum {max} characters).");
        return v;
    }

    static string? Opt(string? s, int max)
    {
        var v = s?.Trim();
        if (string.IsNullOrEmpty(v)) return null;
        return v.Length > max ? v[..max] : v;
    }
}
