using Microsoft.EntityFrameworkCore;
using ReferralHub.Api.Data;
using ReferralHub.Api.Domain;
using ReferralHub.Api.Infrastructure;

namespace ReferralHub.Api.Services;

/// <summary>
/// Every 30 seconds:
///   1. queues a reminder for interviews starting within 24 hours (once per interview)
///   2. sends queued emails through Microsoft Graph (up to 5 attempts each, then marks them Failed)
/// </summary>
public class NotificationWorker(IServiceScopeFactory scopes, GraphClient graph, IConfiguration cfg, ILogger<NotificationWorker> log)
    : BackgroundService
{
    protected override async Task ExecuteAsync(CancellationToken stop)
    {
        while (!stop.IsCancellationRequested)
        {
            try
            {
                using var scope = scopes.CreateScope();
                var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
                var notifier = scope.ServiceProvider.GetRequiredService<Notifier>();
                await QueueReminders(db, notifier, stop);
                await SendQueued(db, stop);
            }
            catch (OperationCanceledException) { break; }
            catch (Exception ex) { log.LogError(ex, "Notification worker error"); }

            try { await Task.Delay(TimeSpan.FromSeconds(30), stop); }
            catch (OperationCanceledException) { break; }
        }
    }

    static async Task QueueReminders(AppDbContext db, Notifier notifier, CancellationToken ct)
    {
        var now = Clock.Now;
        var soon = now.AddHours(24);
        var due = await db.Interviews.Include(i => i.Referral).ThenInclude(r => r!.Requisition)
            .Where(i => i.Status == InterviewStatuses.Scheduled && i.ReminderSentOn == null
                        && i.ScheduledAt > now && i.ScheduledAt <= soon)
            .ToListAsync(ct);
        foreach (var i in due)
        {
            var r = i.Referral!;
            notifier.To(i.InterviewerEmployeeId, "InterviewReminder", $"Reminder: interview with {r.CandidateName}",
                $"Interview {i.RoundNo} is coming up",
                [$"Candidate: {r.CandidateName}", $"Position: {r.Requisition!.Title}", $"When: {EmailTemplate.Ist(i.ScheduledAt)}",
                 "Please review the resume before the interview and submit feedback right after."],
                $"/referrals/{r.ReferralId}", "Referral", r.ReferralId);
            i.ReminderSentOn = now;
        }
        if (due.Count > 0) await db.SaveChangesAsync(ct);
    }

    async Task SendQueued(AppDbContext db, CancellationToken ct)
    {
        var sender = cfg["Graph:SenderUpn"];
        if (!graph.IsConfigured || string.IsNullOrWhiteSpace(sender)) return;   // rows stay Queued until Graph is configured

        var batch = await db.Notifications.Include(n => n.Recipient)
            .Where(n => n.Status == "Queued" && n.Attempts < 5)
            .OrderBy(n => n.CreatedOn).Take(20).ToListAsync(ct);

        foreach (var n in batch)
        {
            var to = n.RecipientEmail ?? n.Recipient?.Email;
            if (string.IsNullOrWhiteSpace(to)) { n.Status = "Failed"; n.LastError = "No recipient email."; continue; }
            try
            {
                var message = new
                {
                    message = new
                    {
                        subject = n.Subject,
                        body = new { contentType = "HTML", content = n.Body },
                        toRecipients = new[] { new { emailAddress = new { address = to } } }
                    },
                    saveToSentItems = false
                };
                var res = await graph.SendAsync(HttpMethod.Post, $"/users/{sender}/sendMail", message, ct);
                if (res.IsSuccessStatusCode) { n.Status = "Sent"; n.SentOn = Clock.Now; n.LastError = null; }
                else Fail(n, await graph.ErrorAsync(res, ct));
            }
            catch (Exception ex) when (ex is not OperationCanceledException) { Fail(n, ex.Message); }
        }
        if (batch.Count > 0) await db.SaveChangesAsync(ct);
    }

    static void Fail(Notification n, string error)
    {
        n.Attempts++;
        n.LastError = error.Length > 500 ? error[..500] : error;
        if (n.Attempts >= 5) n.Status = "Failed";
    }
}
