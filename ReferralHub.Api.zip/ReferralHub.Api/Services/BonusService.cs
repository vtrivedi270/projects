using Microsoft.EntityFrameworkCore;
using ReferralHub.Api.Data;
using ReferralHub.Api.Domain;
using ReferralHub.Api.Dtos;
using ReferralHub.Api.Infrastructure;

namespace ReferralHub.Api.Services;

/// <summary>
/// Referral bonus life cycle: Requested -> Approved -> Paid, or Rejected at any point before Paid.
/// Only the employee who made the referral can request it, only once the candidate has joined.
/// One bonus request per referral (rp.ReferralBonus has a unique constraint on ReferralId).
/// Every step writes rp.ReferralBonusHistory and emails the people involved.
/// </summary>
public class BonusService(AppDbContext db, CurrentUser me, Notifier notify)
{
    static readonly Func<ReferralBonus, string, string?, DateTime, ReferralBonusHistory> Row =
        (b, type, comments, on) => new ReferralBonusHistory { BonusId = b.BonusId, EventType = type, Comments = comments, CreatedOn = on };

    /// <summary>Employee submits the request. The department's default amount (if any) is shown as a guide only.</summary>
    public async Task<int> RequestAsync(int referralId, BonusRequestDto d, CancellationToken ct)
    {
        var user = await me.GetAsync(ct);
        var r = await db.Referrals.Include(x => x.Requisition).ThenInclude(j => j!.Department)
                    .FirstOrDefaultAsync(x => x.ReferralId == referralId, ct)
                ?? throw new NotFoundException("Referral not found.");

        if (r.ReferredByEmployeeId != user.EmployeeId) throw new ForbiddenException("Only the person who made this referral can request the bonus.");
        if (r.Outcome != Outcomes.Selected) throw new DomainException("The referral bonus can be requested only after the candidate is selected.");
        if (r.JoinedOn == null) throw new DomainException("The referral bonus can be requested only after the candidate has joined.");
        if (await db.ReferralBonuses.AnyAsync(b => b.ReferralId == referralId, ct))
            throw new DomainException("A bonus request already exists for this referral.");

        var now = Clock.Now;
        var bonus = new ReferralBonus
        {
            ReferralId = referralId, RequestedByEmployeeId = user.EmployeeId,
            RequestedAmount = r.Requisition!.Department!.DefaultBonusAmount,
            Status = BonusStatus.Requested, Comments = Opt(d.Comments, 500), RequestedOn = now
        };
        bonus.History.Add(new ReferralBonusHistory { EventType = "Requested", ActorEmployeeId = user.EmployeeId, CreatedOn = now, Comments = bonus.Comments });
        db.ReferralBonuses.Add(bonus);

        await using var tx = await db.Database.BeginTransactionAsync(ct);
        await db.SaveChangesAsync(ct);
        await notify.ToRolesAsync([Roles.Hr], null, "BonusRequested", $"Bonus request: {r.CandidateName}", "A referral bonus request needs review",
            [$"{user.DisplayName} requested the referral bonus for {r.CandidateName} ({r.Requisition.Title}).",
             bonus.RequestedAmount.HasValue ? $"Department default: {bonus.RequestedAmount:N0}." : "No department default is set; enter an amount when you approve."],
            $"/bonuses/{bonus.BonusId}", "Bonus", bonus.BonusId, ct);
        notify.To(user.EmployeeId, "BonusRequested", "Bonus request submitted", "Your bonus request is submitted",
            [$"We received your referral bonus request for {r.CandidateName}. HR will review and update you."], $"/my-bonuses", "Bonus", bonus.BonusId);
        await db.SaveChangesAsync(ct);
        await tx.CommitAsync(ct);
        return bonus.BonusId;
    }

    public async Task DecideAsync(int bonusId, bool approve, BonusDecisionDto d, CancellationToken ct)
    {
        await me.RequireAsync(Roles.Hr, ct);
        var user = await me.GetAsync(ct);
        var b = await Load(bonusId, ct);
        if (b.Status != BonusStatus.Requested) throw new DomainException("This request has already been decided.");
        if (!approve && string.IsNullOrWhiteSpace(d.Comments)) throw new DomainException("Add a reason for rejecting the request.");
        if (approve && d.Amount is not > 0) throw new DomainException("Enter the bonus amount to approve.");

        var now = Clock.Now;
        b.DecidedByEmployeeId = user.EmployeeId;
        b.DecidedOn = now;
        b.Comments = Opt(d.Comments, 500);
        if (approve)
        {
            b.Status = BonusStatus.Approved;
            b.ApprovedAmount = d.Amount;
            b.History.Add(Row(b, "Approved", b.Comments, now));
            notify.To(b.RequestedByEmployeeId, "BonusApproved", "Referral bonus approved", "Good news",
                [$"Your referral bonus of {d.Amount:N0} for {b.Referral!.CandidateName} is approved.", "HR will process the payout."],
                "/my-bonuses", "Bonus", b.BonusId);
        }
        else
        {
            b.Status = BonusStatus.Rejected;
            b.History.Add(Row(b, "Rejected", b.Comments, now));
            notify.To(b.RequestedByEmployeeId, "BonusRejected", "Referral bonus request update", "Your bonus request was not approved",
                [$"Reason: {d.Comments!.Trim()}"], "/my-bonuses", "Bonus", b.BonusId);
        }
        await db.SaveChangesAsync(ct);
    }

    public async Task PayAsync(int bonusId, BonusPayDto d, CancellationToken ct)
    {
        await me.RequireAsync(Roles.Hr, ct);
        var user = await me.GetAsync(ct);
        var b = await Load(bonusId, ct);
        if (b.Status != BonusStatus.Approved) throw new DomainException("Only an approved bonus can be marked as paid.");

        var now = Clock.Now;
        b.Status = BonusStatus.Paid;
        b.PaidByEmployeeId = user.EmployeeId;
        b.PaidOn = now;
        b.PayoutReference = Opt(d.PayoutReference, 100);
        if (!string.IsNullOrWhiteSpace(d.Comments)) b.Comments = Opt(d.Comments, 500);
        b.History.Add(Row(b, "Paid", b.PayoutReference, now));
        notify.To(b.RequestedByEmployeeId, "BonusPaid", "Referral bonus paid", "Your referral bonus is paid",
            [$"Your bonus of {b.ApprovedAmount:N0} for {b.Referral!.CandidateName} has been paid.",
             b.PayoutReference != null ? $"Reference: {b.PayoutReference}" : ""].Where(x => x.Length > 0).ToArray(),
            "/my-bonuses", "Bonus", b.BonusId);
        await db.SaveChangesAsync(ct);
    }

    public async Task<List<BonusDto>> MineAsync(CancellationToken ct)
    {
        var user = await me.GetAsync(ct);
        return await ToDto(db.ReferralBonuses.Where(b => b.RequestedByEmployeeId == user.EmployeeId)).ToListAsync(ct);
    }

    public async Task<List<BonusDto>> AllAsync(string? status, CancellationToken ct)
    {
        await me.RequireAsync(Roles.Hr, ct);
        var q = db.ReferralBonuses.AsQueryable();
        if (!string.IsNullOrWhiteSpace(status)) q = q.Where(b => b.Status == status);
        return await ToDto(q).ToListAsync(ct);
    }

    public async Task<BonusDto> GetAsync(int id, CancellationToken ct)
    {
        var user = await me.GetAsync(ct);
        var b = await ToDto(db.ReferralBonuses.Where(x => x.BonusId == id)).FirstOrDefaultAsync(ct)
                ?? throw new NotFoundException("Bonus request not found.");
        var isHr = await me.HasAsync(Roles.Hr, ct);
        var mine = await db.ReferralBonuses.AnyAsync(x => x.BonusId == id && x.RequestedByEmployeeId == user.EmployeeId, ct);
        if (!isHr && !mine) throw new ForbiddenException("You do not have access to this bonus request.");
        return b;
    }

    async Task<ReferralBonus> Load(int id, CancellationToken ct) =>
        await db.ReferralBonuses.Include(x => x.Referral).FirstOrDefaultAsync(x => x.BonusId == id, ct)
        ?? throw new NotFoundException("Bonus request not found.");

    static IQueryable<BonusDto> ToDto(IQueryable<ReferralBonus> q) => q
        .OrderByDescending(b => b.RequestedOn)
        .Select(b => new BonusDto(
            b.BonusId, b.ReferralId, b.Referral!.CandidateName, b.Referral.Requisition!.Title, b.RequestedBy!.DisplayName,
            b.RequestedOn, b.RequestedAmount, b.ApprovedAmount, b.Status, b.DecidedBy?.DisplayName, b.DecidedOn,
            b.PaidBy?.DisplayName, b.PaidOn, b.PayoutReference, b.Comments,
            b.History.OrderBy(h => h.CreatedOn).Select(h => new BonusHistoryItemDto(h.CreatedOn, h.EventType, h.Actor!.DisplayName, h.Comments)).ToList()));

    static string? Opt(string? s, int max)
    {
        var v = s?.Trim();
        if (string.IsNullOrEmpty(v)) return null;
        return v.Length > max ? v[..max] : v;
    }
}
